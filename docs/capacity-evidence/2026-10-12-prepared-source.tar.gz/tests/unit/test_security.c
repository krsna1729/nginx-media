/*
 * Behavioral parser, framing and storage regressions through production code.
 * Native routing/API scenarios live in tests/integration; HTTP/TLS and reader
 * cancellation are exercised by test_http. No source-text checks or copied
 * validators stand in for those runtime behaviors.
 */

#define _DEFAULT_SOURCE 1
#define _POSIX_C_SOURCE 200809L

#include "ngx_media_test.h"

#include "ngx_media_rtmp_wire.h"
#include "ngx_media_ts_demux.h"
#include "ngx_media_owner.h"
#include "ngx_media_hls_segmenter.h"
#include "ngx_media_nal.h"
#include "ngx_media_record.h"
#include "ngx_media_ipc.h"
#include "ngx_media_srt_transport.h"

#include <arpa/inet.h>
#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>

/* Never write a core file: a regression test that proves a pre-fix crash
 * must report FAIL, not dump core.  Called first in main(); children
 * inherit the limit, so an expected crash in a forked probe also leaves
 * no core behind. */
static void
disable_coredumps(void)
{
    struct rlimit  rl;

    rl.rlim_cur = 0;
    rl.rlim_max = 0;
    (void) setrlimit(RLIMIT_CORE, &rl);
}

#define CHECK(cond, fmt, ...)                                                 \
    do {                                                                      \
        ngx_media_test_checks++;                                              \
        if (!(cond)) {                                                        \
            ngx_media_test_failures++;                                        \
            printf("FAIL %s:%d: " fmt "\n", __FILE__, __LINE__,               \
                   ##__VA_ARGS__);                                            \
        }                                                                     \
    } while (0)

/* ------------------------------------------------------------------ */
/* 1. RTMP: fmt0 length change must drop the stale payload.            */
/*                                                                     */
/* Pre-fix: cs->payload from the previous (smaller) message is reused, */
/* so a later larger message writes past the old buffer (heap overflow */
/* under ASan, heap corruption otherwise).  This test never feeds the  */
/* overflowing payload: after feeding only the second header it checks */
/* that the reader dropped the stale buffer (new capacity, new pointer)*/
/* so it fails on pre-fix code without crashing or dumping core.       */
/* ------------------------------------------------------------------ */

typedef struct {
    ngx_uint_t  count;
    size_t      len[4];
    u_char      data[4][256];
} rtmp_sink_t;

static ngx_int_t
rtmp_collect(void *ctx, ngx_uint_t type, ngx_uint_t stream_id,
    uint32_t timestamp, ngx_media_buf_t *payload)
{
    rtmp_sink_t  *s = ctx;
    size_t        n;

    (void) type;
    (void) stream_id;
    (void) timestamp;

    if (s->count < 4) {
        n = ngx_media_buf_size(payload);
        s->len[s->count] = n;
        if (n <= sizeof(s->data[0])) {
            memcpy(s->data[s->count], ngx_media_buf_data(payload), n);
        }
        s->count++;
    }

    return NGX_OK;
}

static void
build_fmt0(u_char *out, ngx_uint_t csid, uint32_t ts, size_t len,
    ngx_uint_t type, ngx_uint_t stream_id)
{
    out[0] = (u_char) (csid & 0x3F);
    out[1] = (u_char) ((ts >> 16) & 0xFF);
    out[2] = (u_char) ((ts >> 8) & 0xFF);
    out[3] = (u_char) (ts & 0xFF);
    out[4] = (u_char) ((len >> 16) & 0xFF);
    out[5] = (u_char) ((len >> 8) & 0xFF);
    out[6] = (u_char) (len & 0xFF);
    out[7] = (u_char) type;
    out[8] = (u_char) ((stream_id >> 24) & 0xFF);
    out[9] = (u_char) ((stream_id >> 16) & 0xFF);
    out[10] = (u_char) ((stream_id >> 8) & 0xFF);
    out[11] = (u_char) (stream_id & 0xFF);
}

static void
test_rtmp_length_change(void)
{
    ngx_media_rtmp_reader_t  r;
    rtmp_sink_t              sink;
    u_char                   wire1[12 + 128];
    u_char                   hdr2[12];
    size_t                   consumed;
    ngx_uint_t               i;
    ngx_media_rtmp_cs_t     *cs;
    ngx_media_buf_t         *old_payload;
    size_t                   old_cap;

    TEST_CASE("rtmp: fmt0 length change drops the stale payload "
              "(no crash)");

    memset(&sink, 0, sizeof(sink));
    ngx_media_rtmp_reader_init(&r);
    /* default chunking: one full 128-byte chunk leaves a 200-byte message
     * incomplete with pending_remaining == 0, so the next header is parsed
     * as a header -- the path the fix guards. */
    r.chunk_size = 128;
    r.max_message = NGX_MEDIA_RTMP_MAX_MESSAGE;

    /* first message: 200 bytes declared, one full 128-byte chunk delivered */
    build_fmt0(wire1, 4, 0, 200, NGX_MEDIA_RTMP_MSG_AUDIO, 1);
    memset(wire1 + 12, 0xAA, 128);

    CHECK(ngx_media_rtmp_reader_feed(&r, wire1, sizeof(wire1), &consumed,
                                     rtmp_collect, &sink) == NGX_OK,
          "partial first message accepted");
    CHECK(sink.count == 0, "no complete message yet: %lu", sink.count);
    CHECK(consumed == sizeof(wire1), "all partial bytes consumed");

    /* locate the chunk stream and remember its payload buffer */
    cs = NULL;
    for (i = 0; i < NGX_MEDIA_RTMP_MAX_CSID; i++) {
        if (r.chunks[i].used && r.chunks[i].csid == 4) {
            cs = &r.chunks[i];
            break;
        }
    }
    CHECK(cs != NULL, "chunk stream 4 exists");
    CHECK(cs != NULL && cs->payload != NULL, "stale payload present");
    if (cs == NULL || cs->payload == NULL) {
        ngx_media_rtmp_reader_reset(&r);
        return;
    }
    old_payload = cs->payload;
    old_cap = ngx_media_buf_capacity(old_payload);
    CHECK(old_cap == 200, "stale capacity is 200: %lu", old_cap);

    /*
     * Feed only the second header (256 bytes declared, no payload bytes).
     * Fixed code unrefs the 200-byte buffer and allocates 256; pre-fix code
     * keeps the 200-byte buffer.  No payload is copied, so neither version
     * can overflow, abort, or dump core here.
     */
    build_fmt0(hdr2, 4, 0, 256, NGX_MEDIA_RTMP_MSG_AUDIO, 1);

    CHECK(ngx_media_rtmp_reader_feed(&r, hdr2, sizeof(hdr2), &consumed,
                                     rtmp_collect, &sink) == NGX_OK,
          "second header accepted");
    CHECK(consumed == sizeof(hdr2), "header consumed");
    CHECK(sink.count == 0, "still no complete message: %lu", sink.count);

    cs = NULL;
    for (i = 0; i < NGX_MEDIA_RTMP_MAX_CSID; i++) {
        if (r.chunks[i].used && r.chunks[i].csid == 4) {
            cs = &r.chunks[i];
            break;
        }
    }
    CHECK(cs != NULL && cs->payload != NULL, "new payload allocated");
    if (cs != NULL && cs->payload != NULL) {
        CHECK(cs->payload != old_payload,
              "stale buffer was dropped (pointer changed)");
        CHECK(ngx_media_buf_capacity(cs->payload) == 256,
              "new capacity is 256: %lu",
              ngx_media_buf_capacity(cs->payload));
        CHECK(cs->length == 256, "new length recorded: %lu", cs->length);
    }

    /*
     * Health check on a fresh reader: single-chunk delivery with a large
     * chunk size is safe on every version and proves the reader still
     * works after the length change above.  The pre-fix overflow is never
     * fed, so this test cannot crash or dump core on any version; the
     * capacity assertions above are what fail pre-fix.
     */
    {
        u_char  health[12 + 256];

        ngx_media_rtmp_reader_reset(&r);
        memset(&sink, 0, sizeof(sink));
        ngx_media_rtmp_reader_init(&r);
        r.chunk_size = 256;
        r.max_message = NGX_MEDIA_RTMP_MAX_MESSAGE;
        build_fmt0(health, 5, 0, 256, NGX_MEDIA_RTMP_MSG_AUDIO, 1);
        for (i = 0; i < 256; i++) {
            health[12 + i] = (u_char) (0xBB + (i & 0x0F));
        }
        CHECK(ngx_media_rtmp_reader_feed(&r, health, sizeof(health),
                                         &consumed, rtmp_collect, &sink)
              == NGX_OK,
              "fresh message accepted after length change");
        CHECK(sink.count == 1, "one message delivered: %lu", sink.count);
        if (sink.count == 1) {
            CHECK(sink.len[0] == 256,
                  "delivered length is the new length: %lu", sink.len[0]);
        }
    }

    ngx_media_rtmp_reader_reset(&r);
}

/* ------------------------------------------------------------------ */
/* 2. AMF0: skip-path member name length must be bounds checked.       */
/*                                                                     */
/* Pre-fix: `pos += 2 + nlen` without verifying `pos + 2 + nlen <= len`*/
/* makes `len - pos` wrap to a huge size_t and the recursive read runs */
/* out of bounds (crash/OOB).  Fixed code returns NGX_AGAIN.  The evil  */
/* input below runs in a forked child with core dumps disabled, so a   */
/* pre-fix crash becomes a FAIL, never a core file; the source check   */
/* pins the fix even when the child crashes.                           */
/* ------------------------------------------------------------------ */

/* exit codes for the forked evil-input probe */
#define SEC_AMF_PROBE_OK     0   /* returned NGX_AGAIN, consumed in bounds */
#define SEC_AMF_PROBE_WRONG  1   /* returned something else (pre-fix logic) */

static void
test_amf_skip_oob(void)
{
    ngx_media_amf_value_t  value;
    size_t                 consumed = 0;
    ngx_int_t              rc;

    /*
     * Top-level object { "a": <nested object> }, where the nested object
     * claims a 255-byte member name but only 5 bytes remain.
     *
     *   03 | 00 01 'a' | 03 | 00 FF 41 41 41 41 41
     */
    u_char  evil[] = {
        0x03,
        0x00, 0x01, 'a',
        0x03,
        0x00, 0xFF, 'A', 'A', 'A', 'A', 'A',
    };

    TEST_CASE("amf0: nested name length past the buffer asks for more "
              "(OOB read)");

    /*
     * Forked probe: the child feeds the evil input and exits
     * SEC_AMF_PROBE_OK only when the fixed behaviour (NGX_AGAIN, consumed
     * in bounds) is observed.  Any crash (signal death) or wrong result
     * makes the parent report FAIL.  Core dumps are already disabled
     * process-wide, and the child inherits that, so no core file appears
     * on any path.
     */
    {
        pid_t  pid;
        int    status = 0;

        fflush(stdout);
        pid = fork();

        if (pid == -1) {
            CHECK(0, "fork for amf probe failed");
        } else if (pid == 0) {
            /* child: no test counters here, just probe and exit */
            ngx_media_amf_value_t  cval;
            size_t                 cused = 0xDEAD;
            ngx_int_t              crc;

            crc = ngx_media_amf_read(evil, sizeof(evil), &cval, &cused);

            if (crc == NGX_AGAIN && cused <= sizeof(evil)) {
                _exit(SEC_AMF_PROBE_OK);
            }
            _exit(SEC_AMF_PROBE_WRONG);
        } else {
            while (waitpid(pid, &status, 0) < 0) {
                /* retry on EINTR */
            }

            if (WIFEXITED(status) && WEXITSTATUS(status) == SEC_AMF_PROBE_OK) {
                CHECK(1, "forked probe: truncated nested name asks for more");
            } else if (WIFSIGNALED(status)) {
                CHECK(0, "truncated nested name crashed child (signal %d, "
                      "no core): pre-fix OOB", WTERMSIG(status));
            } else {
                CHECK(0, "truncated nested name returns AGAIN, got child "
                      "exit %d", WIFEXITED(status) ? WEXITSTATUS(status)
                                                   : -1);
            }
        }
    }

    consumed = 0xDEAD;
    rc = 0;

    /* a well-formed nested object still decodes */
    {
        /* { "a": { "b": 1.0 } } with correct 9-byte AMF0 number */
        u_char  good[] = {
            0x03,
            0x00, 0x01, 'a',
            0x03,
            0x00, 0x01, 'b',
            0x00, 0x3F, 0xF0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x09,
            0x00, 0x00, 0x09,
        };

        rc = ngx_media_amf_read(good, sizeof(good), &value, &consumed);
        CHECK(rc == NGX_OK, "well-formed nested object still decodes: %ld",
              (long) rc);
    }
}

/* ------------------------------------------------------------------ */
/* 8. MPEG-TS: PSI section header split across packet boundaries.      */
/*                                                                     */
/* Pre-fix: when only 1-2 bytes of the 3-byte section header arrived at*/
/* the end of a packet, psi->expected stayed 0, so `expected - len`    */
/* underflowed and the section never completed.  Fixed code accumulates*/
/* the 3-byte header explicitly.                                       */
/* ------------------------------------------------------------------ */

static uint32_t
ts_crc32(const u_char *p, size_t len)
{
    uint32_t  crc = 0xFFFFFFFFu;
    size_t    i;
    int       b;

    for (i = 0; i < len; i++) {
        crc ^= (uint32_t) p[i] << 24;
        for (b = 0; b < 8; b++) {
            crc = (crc & 0x80000000u) ? (crc << 1) ^ 0x04C11DB7u
                                      : (crc << 1);
        }
    }
    return crc;
}

typedef struct {
    ngx_uint_t  track_notes;
    ngx_uint_t  frames;
} ts_sink_ctx_t;

static void
ts_sink_tracks(void *ctx, const ngx_media_trackset_t *tracks)
{
    ts_sink_ctx_t  *s = ctx;

    (void) tracks;
    s->track_notes++;
}

static void
ts_sink_frame(void *ctx, const ngx_media_frame_t *frame)
{
    ts_sink_ctx_t  *s = ctx;

    (void) frame;
    s->frames++;
}

static void
ts_write_packet(u_char *out, ngx_uint_t pid, ngx_uint_t pusi, ngx_uint_t cc,
    const u_char *payload, size_t len)
{
    u_char  *p = out;
    size_t   af = 0;

    memset(p, 0xFF, 188);
    p[0] = 0x47;
    p[1] = (u_char) ((pusi ? 0x40 : 0x00) | ((pid >> 8) & 0x1F));
    p[2] = (u_char) (pid & 0xFF);

    if (len < 184) {
        size_t  stuff = 184 - len - 1;

        af = 1 + stuff;
        p[3] = (u_char) ((0x03 << 4) | (cc & 0x0F));
        p[4] = (u_char) stuff;
        if (stuff > 0) {
            p[5] = 0x00;
        }
    } else {
        p[3] = (u_char) ((0x01 << 4) | (cc & 0x0F));
    }

    if (len > 184 - af) {
        len = 184 - af;
    }
    if (len > 0) {
        memcpy(p + 4 + af, payload, len);
    }
}

static void
test_ts_psi_split(void)
{
    ngx_media_ts_demux_t       demux;
    ngx_media_ts_demux_conf_t  conf;
    ngx_media_ts_sink_t        sink;
    ts_sink_ctx_t              ctx;
    u_char                     section[16];
    u_char                     pkt1[188], pkt2[188];
    u_char                     pay1[2], pay2[15];
    uint32_t                   crc;

    TEST_CASE("mpegts: PSI section header split 1+15 across packets");

    /* minimal PAT: table 0x00, section_length 13, program 1 -> PID 0x1000 */
    section[0] = 0x00;
    section[1] = 0xB0;
    section[2] = 0x0D;
    section[3] = 0x00;
    section[4] = 0x01;
    section[5] = 0xC1;
    section[6] = 0x00;
    section[7] = 0x00;
    section[8] = 0x00;
    section[9] = 0x01;
    section[10] = 0xF0;   /* 0xE0 | ((0x1000 >> 8) & 0x1F) */
    section[11] = 0x00;
    crc = ts_crc32(section, 12);
    section[12] = (u_char) (crc >> 24);
    section[13] = (u_char) (crc >> 16);
    section[14] = (u_char) (crc >> 8);
    section[15] = (u_char) crc;

    memset(&ctx, 0, sizeof(ctx));
    conf.max_tracks = 8;
    conf.max_au_bytes = 0;
    sink.tracks = ts_sink_tracks;
    sink.frame = ts_sink_frame;

    CHECK(ngx_media_ts_demux_init(&demux, &conf, &sink, &ctx, NULL) == NGX_OK,
          "demux init");

    /*
     * Packet 1 (PUSI): pointer 0x00 + first 1 byte of the section.
     * Packet 2 (!PUSI): remaining 15 bytes.  The 3-byte section header is
     * therefore split 1/2 across the packet boundary.
     */
    pay1[0] = 0x00;
    pay1[1] = section[0];
    ts_write_packet(pkt1, 0x0000, 1, 0, pay1, sizeof(pay1));

    memcpy(pay2, section + 1, 15);
    ts_write_packet(pkt2, 0x0000, 0, 1, pay2, sizeof(pay2));

    CHECK(ngx_media_ts_demux_feed(&demux, pkt1, sizeof(pkt1)) == NGX_OK,
          "first fragment accepted");
    CHECK(ngx_media_ts_demux_feed(&demux, pkt2, sizeof(pkt2)) == NGX_OK,
          "second fragment accepted");

    CHECK(demux.pmt_pid == 0x1000, "split PAT reassembled, pmt_pid=%lu",
          (unsigned long) demux.pmt_pid);
    {
        ngx_media_ts_demux_stats_t  stats;

        ngx_media_ts_demux_stats(&demux, &stats);
        CHECK(stats.psi_errors == 0, "no psi error on split header: %llu",
              (unsigned long long) stats.psi_errors);
    }

    /* 2-byte split as well: 2 bytes then 14 bytes */
    {
        ngx_media_ts_demux_t  d2;
        ts_sink_ctx_t         c2;
        u_char                q1[188], q2[188];
        u_char                r1[3], r2[14];

        memset(&c2, 0, sizeof(c2));
        CHECK(ngx_media_ts_demux_init(&d2, &conf, &sink, &c2, NULL) == NGX_OK,
              "demux re-init for 2-byte split");

        r1[0] = 0x00;
        r1[1] = section[0];
        r1[2] = section[1];
        ts_write_packet(q1, 0x0000, 1, 0, r1, sizeof(r1));

        memcpy(r2, section + 2, 14);
        ts_write_packet(q2, 0x0000, 0, 1, r2, sizeof(r2));

        CHECK(ngx_media_ts_demux_feed(&d2, q1, sizeof(q1)) == NGX_OK,
              "2-byte first fragment accepted");
        CHECK(ngx_media_ts_demux_feed(&d2, q2, sizeof(q2)) == NGX_OK,
              "2-byte second fragment accepted");
        CHECK(d2.pmt_pid == 0x1000, "2-byte split reassembled: %lu",
              (unsigned long) d2.pmt_pid);

        ngx_media_ts_demux_destroy(&d2);
    }

    ngx_media_ts_demux_destroy(&demux);
}


static void
test_hls_segmenter_psi_bytes(void)
{
    ngx_media_hls_t       hls;
    ngx_media_hls_conf_t  conf;
    ngx_media_buf_t      *backing;
    ngx_media_ts_burst_t  burst;

    TEST_CASE("hls segmenter: new segments start with PAT/PMT, bytes "
              "counted once");

    ngx_media_hls_conf_default(&conf);
    conf.path.data = (u_char *) ".build/sec-seg";
    conf.path.len = sizeof(".build/sec-seg") - 1;
    conf.target_duration = 1000;
    conf.min_duration = 1000;
    conf.max_duration = 1000;
    conf.max_segment_bytes = 1 << 20;
    conf.max_segments = 4;
    conf.max_retained_bytes = 1 << 20;

    CHECK(ngx_media_hls_init(&hls, &conf, NULL) == NGX_OK, "segmenter init");

    backing = ngx_media_buf_alloc(1024);
    CHECK(backing != NULL, "backing allocated");
    memset(ngx_media_buf_data(backing), 0x47, 1024);
    (void) ngx_media_buf_freeze(backing, 1024);

    memset(&burst, 0, sizeof(burst));
    burst.backing = backing;
    burst.psi_len = 100;
    burst.nslices = 1;
    burst.slices[0].offset = 100;
    burst.slices[0].len = 400;
    burst.slices[0].media_type = NGX_MEDIA_TYPE_VIDEO;
    burst.slices[0].codec = NGX_MEDIA_CODEC_H264;
    burst.slices[0].keyframe = 1;
    burst.slices[0].dts = 90000;
    burst.slices[0].pts = 90000;

    CHECK(ngx_media_hls_add_burst(&hls, &burst) == NGX_OK, "burst added");

    /*
     * Fixed: pieces = [PSI(100), slice(400)], bytes = 500 counted once by
     * hls_piece().  Buggy: bytes = 100 + 400 + 400 = 900 (explicit
     * `hls->bytes += slice->len` double-counts) and PSI handling differs.
     */
    CHECK(hls.npieces == 2, "psi + slice pieces: %lu", hls.npieces);
    if (hls.npieces == 2) {
        CHECK(hls.pieces[0].len == 100 && hls.pieces[0].offset == 0,
              "first piece is the PAT/PMT prefix");
        CHECK(hls.pieces[1].len == 400 && hls.pieces[1].offset == 100,
              "second piece is the media slice");
    }
    CHECK(hls.bytes == 500, "bytes counted once: %lu", (unsigned long) hls.bytes);

    ngx_media_buf_unref(backing);
    ngx_media_hls_destroy(&hls);

}

/* Player footprint, NAL progress and bounded recording names. */

/* mirrors the reservation in ngx_media_rtmp_queue_message */
#define SEC_RTMP_OUT_CHUNK  4096
#define SEC_RTMP_MAX_QUEUE  64

static void
test_rtmp_player_reserve(void)
{
    ngx_media_rtmp_writer_t    writer;
    ngx_media_rtmp_footprint_t footprint;
    size_t                     len = 300 * 1024;
    size_t                     chunks = (len + SEC_RTMP_OUT_CHUNK - 1)
                                         / SEC_RTMP_OUT_CHUNK;
    size_t                     small = (100 * 1024 + SEC_RTMP_OUT_CHUNK - 1)
                                         / SEC_RTMP_OUT_CHUNK;

    TEST_CASE("rtmp: player queue reserves per-chunk, not per-message");

    ngx_media_rtmp_writer_init(&writer, SEC_RTMP_OUT_CHUNK, 1024 * 1024);

    CHECK(chunks == 75, "300 KiB is 75 chunks: %lu", chunks);
    CHECK(ngx_media_rtmp_message_footprint(&writer, len, &footprint)
          == NGX_OK,
          "writer computes a footprint for a bounded message");
    CHECK(footprint.parts == chunks * 2 && footprint.refs == chunks,
          "footprint counts every chunk (parts %lu, refs %lu)",
          (size_t) footprint.parts, (size_t) footprint.refs);
    CHECK(footprint.parts > SEC_RTMP_MAX_QUEUE
          || footprint.refs > SEC_RTMP_MAX_QUEUE,
          "the 300 KiB message cannot fit the 64-slot queue");

    CHECK(ngx_media_rtmp_message_footprint(&writer, 100 * 1024,
                                           &footprint) == NGX_OK,
          "a bounded message still has a footprint");
    CHECK(footprint.parts == small * 2 && footprint.refs == small,
          "the smaller message is admitted by the same per-chunk contract");
}



#define SEC_NAL_EMPTIES  200000

static void
test_nal_no_recursion(void)
{
    u_char                *buf;
    size_t                 i;

    TEST_CASE("nal: a run of empty units terminates without recursion");

    buf = malloc((size_t) SEC_NAL_EMPTIES * 3);
    CHECK(buf != NULL, "fuzz buffer allocated");

    if (buf == NULL) {
        return;
    }

    for (i = 0; i < SEC_NAL_EMPTIES; i++) {
        buf[i * 3] = 0x00;
        buf[i * 3 + 1] = 0x00;
        buf[i * 3 + 2] = 0x01;
    }

    /*
     * Forked probe like the AMF one: 200k nested frames would smash the
     * 8 MB stack on pre-fix code (each level keeps a frame).  The child
     * inherits the no-core limit, so a pre-fix crash is a FAIL, not a
     * core file.
     */
    {
        pid_t  pid;
        int    status = 0;

        fflush(stdout);
        pid = fork();

        if (pid == -1) {
            CHECK(0, "fork for nal probe failed");
        } else if (pid == 0) {
            ngx_media_nal_iter_t  cit;
            ngx_media_nal_t        cnal;
            size_t                 cn = 0;

            ngx_media_nal_iter_init(&cit, buf, (size_t) SEC_NAL_EMPTIES * 3);

            while (ngx_media_nal_iter_next(&cit, &cnal)) {
                cn++;
            }

            _exit((cn == 0) ? 0 : 1);
        } else {
            while (waitpid(pid, &status, 0) < 0) {
                /* retry on EINTR */
            }

            if (WIFEXITED(status) && WEXITSTATUS(status) == 0) {
                CHECK(1, "forked probe: empty units terminate with no NALs");
            } else if (WIFSIGNALED(status)) {
                CHECK(0, "empty units crashed child (signal %d, no core): "
                      "pre-fix recursion", WTERMSIG(status));
            } else {
                CHECK(0, "empty units yielded NALs (child exit %d)",
                      WIFEXITED(status) ? WEXITSTATUS(status) : -1);
            }
        }
    }

    /* the same input in-process on a shallow run: safe at any depth the
     * fixed loop handles, and shallow enough that even pre-fix recursion
     * cannot overflow the stack, so the main process never crashes */
    {
        u_char                small[64 * 3];
        ngx_media_nal_iter_t  sit;
        ngx_media_nal_t        snal;
        size_t                 sn = 0, si;

        for (si = 0; si < 64; si++) {
            small[si * 3] = 0x00;
            small[si * 3 + 1] = 0x00;
            small[si * 3 + 2] = 0x01;
        }

        ngx_media_nal_iter_init(&sit, small, sizeof(small));

        while (ngx_media_nal_iter_next(&sit, &snal)) {
            sn++;
        }

        CHECK(sn == 0, "no NALs from empty units: %lu", sn);
    }

    free(buf);

}

static void
test_record_suffix(void)
{
    ngx_media_record_t       rec;
    ngx_media_record_conf_t  conf;
    ngx_media_buf_t         *buf;
    u_char                  *raw;
    char                     expect[256];
    struct stat              st;
    ngx_uint_t               i;

    TEST_CASE("record: part suffix never reads past path.len");

    (void) mkdir(".build", 0755);
    (void) mkdir(".build/sec-record", 0755);

    /*
     * A path slice with no NUL at path.len: pre-fix %s keeps reading into
     * the 'Q' fill, so part 2 lands in a garbage filename and the expected
     * file is missing (FAIL, no crash).  Fixed code uses %.*s.
     */
    raw = malloc(64);
    CHECK(raw != NULL, "path buffer allocated");

    if (raw == NULL) {
        return;
    }

    memcpy(raw, ".build/sec-record/r.ts", 23);
    memset(raw + 23, 'Q', 64 - 23 - 1);
    raw[63] = '\0';

    snprintf(expect, sizeof(expect), ".build/sec-record/r-0002.ts");
    (void) unlink(expect);

    ngx_media_record_conf_default(&conf);
    conf.path.data = raw;
    conf.path.len = 23;
    conf.tap = NGX_MEDIA_RECORD_PROGRAM;
    conf.max_part_bytes = 512;
    conf.max_pending_bytes = 64 * 1024;
    conf.max_jobs = 256;

    CHECK(ngx_media_record_init(&rec, &conf, NULL) == NGX_OK, "record init");

    for (i = 0; i < 16; i++) {
        buf = ngx_media_buf_alloc(256);

        if (buf == NULL) {
            break;
        }

        memset(ngx_media_buf_data(buf), (int) i, 256);
        (void) ngx_media_buf_freeze(buf, 256);
        (void) ngx_media_record_append(&rec, buf, 0, 256);
        ngx_media_buf_unref(buf);
    }

    ngx_media_record_stop(&rec);
    free(raw);

    CHECK(stat(expect, &st) == 0, "part 2 has the exact bounded name");
    (void) unlink(expect);

}

int
main(void)
{
    disable_coredumps();
    printf("== security hardening regressions\n");

    test_rtmp_length_change();
    test_amf_skip_oob();
    test_ts_psi_split();

    test_hls_segmenter_psi_bytes();

    test_rtmp_player_reserve();
    test_nal_no_recursion();
    test_record_suffix();

    TEST_LEAKS();
    TEST_MAIN_END();
}
