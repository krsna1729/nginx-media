#!/usr/bin/env bash
#
# Ingest and egress under extreme fanout: where each side saturates, on whose
# thread, and what placing a publisher on a worker that does not own its
# program costs.
#
# Four things, measured rather than reasoned about:
#
#   floor    a worker with no media at all, so the CPU a worker burns before
#            any publisher arrives is a number, not a target: after the
#            idle-wait fix the sender pool sleeps with every slot unused; the
#            pre-fix run recorded the defect as roughly one core per worker.
#
#   ingest   libsrt runs the receive path itself, one thread per bound UDP
#            port, and this module's ingest thread only copies out of the
#            session buffer.  So the ceiling on one endpoint should be one
#            core and not one worker - which means publishers scale by
#            *endpoint* and not by worker count.  This ramps publishers onto
#            an endpoint and attributes CPU per thread, because "the ceiling
#            is one core" is a claim about `SRT:RcvQ`, not about a process.
#
#   egress   one program has one owner worker.  HLS is served from the shared
#            segment store, so the kernel spreads readers over every worker
#            (`listen ... reuseport`), while live destinations are prepared
#            and fed by the owner in process and cannot be spread at all.
#            Both are measured per worker count, so "does adding workers
#            help" is a number for each rather than a principle.
#
#   placed   a publisher that lands on a worker which does not own its
#   vs       program has its frames carried to the owner over the bounded
#   routed   SOCK_SEQPACKET transport.  The same load is run both ways - on
#            its owners' endpoint and on another worker's - and the difference
#            in CPU, throughput and owner queue is reported, so the escape
#            hatch has a price instead of a description.  Ownership is
#            deterministic (FNV-1a over application/stream, hash % workers)
#            and the graph reports the owner, so streams can be named to own
#            a chosen slot and placed on a chosen endpoint.
#
#   topology a four-worker owner-balanced matrix: all-local, all-routed,
#            alternating, and one-program local/routed controls.  Every row
#            includes input/program frames, feed pressure, preroll causes and
#            route failures from the owning worker.
#   capacity a fixed-worker offered-load curve: add programs, bitrate, and an
#            exact single-program output ladder over SRT and RTMP, followed by
#            a stalled-reader isolation case, saturated 4x250 SRT fanout, and
#            sustained multi-program fairness.  Reports receiver bytes,
#            sender-shard counters/CPU, per-worker resources, and fairness.
#
#
# Publishers stream a pre-encoded file with -c copy, so what is measured is
# the receiver's cost and not ffmpeg's encoder.  `media_srt_listen` is given
# once per worker, so worker i binds the i-th endpoint, and a publisher is
# placed by choosing the endpoint it connects to.
#
# Thread identification: the fixed SRT egress shards name themselves
# `srt-egress-00` through `srt-egress-15`; libsrt names its threads
# `SRT:RcvQ:wN`, `SRT:SndQ:wN`, `SRT:TsbPd`, and `SRT:GC`.  The sampler reads
# the comm field from each TID's `stat` record in the same pass as CPU ticks.
# The worker's own threads are labelled once per instance from a stack
# backtrace, because a detached thread is otherwise indistinguishable from
# the worker's event loop; if that is unavailable the labels fall back to
# comm and the conditions say so.
#
# CPU is per thread from /proc/<pid>/task/<tid>/stat.  One sampler takes both
# snapshots; CPU percentages use the wall time between their sample midpoints.
#
# Conditions are printed with the numbers.  One host, no netem, nothing else
# running.
#
#   make bench-ingest-egress-fanout
#   PHASES=misplace make bench-ingest-egress-fanout     one phase
#   PHASES=topology make bench-ingest-egress-fanout    owner matrix
#   HI_BITRATE=45M PHASES=ingest ...                    more aggressive
#   make bench-capacity-curve
#   PHASES=capacity-saturated ...                  only 4x250 SRT fanout
#   PHASES=capacity-slow-reader ...               only SRT slow-reader case
#   PHASES=capacity-sustained ...                  only sustained case

set -uo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
source "$ROOT/tests/integration/ingest_test_helpers.sh"
NGINX="${CAPACITY_NGINX:-$ROOT/.build/nginx-install/sbin/nginx}"
RUN="${CAPACITY_RUN:-$ROOT/.build/ingest-egress-fanout}"

# Each run owns a 512-wide port block: HTTP +0, RTMP sink +1, SRT endpoints
# +2..+17, HLS push receiver +30, the SRT receiver's listeners +64..+127,
# RTMP listeners +128..+191, private APIs +192..+255 and SSH forwards +256..+319.
# CAPACITY_BASE may select another block when the PID-derived block is occupied.
# The blocks sit below the kernel's ephemeral range (32768 and up by
# default): an outgoing socket - the SRT destinations of the previous run
# while libsrt tears them down, for one - is given ports from that range, and
# a listener placed there can find its port briefly taken ("Address already
# in use" on a run that follows another).  The blocks also stay clear of the
# fixed ports the integration suites use (18000 and up).
BASE="${CAPACITY_BASE:-$(( 10240 + ($$ % 15) * 512 ))}"
HTTP_PORT="$BASE"
RTMP_PORT="$(( BASE + 1 ))"
RTMP_SINK_RUN="$RUN/rtmp-sink"
# The measuring RTMP receiver is one or more single-worker nginx instances.
# One instance ingesting a large fanout stalls its own event loop (624 ms at
# 192 destinations on a 4-vCPU host), and that reads as a delivery stall, so
# a case starts one instance per CAPACITY_RTMP_RECEIVER_PEERS destinations.
CAPACITY_RTMP_RECEIVER_PEERS="${CAPACITY_RTMP_RECEIVER_PEERS:-48}"
RTMP_SINK_COUNT=1
RTMP_SINK_PIDS=()
RTMP_REMOTE_MASTERS=()
RTMP_SINK_WORKER_PID=""

PHASES="${PHASES:-floor ingest egress misplace}"
WINDOW="${WINDOW:-6}"
FLOOR_WINDOW="${FLOOR_WINDOW:-4}"

# ingest ceiling: sixteen publishers is the per-worker session ceiling, so the
# offered packet rate is what has to be raised to reach one core on one port.
# -muxrate pads each publisher's transport stream to the chosen rate, so the
# receive path sees a packet rate that is a parameter and not whatever the
# content happened to encode to.
HI_PUBS="${HI_PUBS:-16}"
HI_RATES="${HI_RATES:-20M 40M 80M 120M}"

# ingest, publisher growth on one endpoint
PUB_STEPS="${PUB_STEPS:-4 8 12 16}"

# ingest, endpoint scaling: the same per-publisher rate at every worker count,
# so the only thing that changes is how many endpoints carry the load and how
# many receive threads exist
LO_BITRATE="${LO_BITRATE:-6M}"
LO_PER_PORT="${LO_PER_PORT:-12}"
LO_WORKERS="${LO_WORKERS:-1 2 4}"

# egress
EGRESS_WORKERS="${EGRESS_WORKERS:-1 2 4}"
HLS_READERS="${HLS_READERS:-48}"
HLS_SECONDS="${HLS_SECONDS:-12}"
SRT_DESTS="${SRT_DESTS:-8}"
LIVE_SECONDS="${LIVE_SECONDS:-12}"

# placement
MP_WORKERS="${MP_WORKERS:-2}"
MP_PUBS="${MP_PUBS:-12}"
MP_BITRATE="${MP_BITRATE:-20M}"
# capacity curve (fixed worker count; each axis varies offered work)
CAPACITY_WORKERS="${CAPACITY_WORKERS:-4}"
CAPACITY_WINDOW="${CAPACITY_WINDOW:-8}"
CAPACITY_PROGRAM_STEPS="${CAPACITY_PROGRAM_STEPS:-1 2 4 8}"
CAPACITY_PROGRAM_RATE="${CAPACITY_PROGRAM_RATE:-6M}"
CAPACITY_PROGRAM_DESTS="${CAPACITY_PROGRAM_DESTS:-1}"
CAPACITY_BITRATE_STEPS="${CAPACITY_BITRATE_STEPS:-2M 6M 12M 20M}"
CAPACITY_BITRATE_PROGRAMS="${CAPACITY_BITRATE_PROGRAMS:-4}"
CAPACITY_BITRATE_DESTS="${CAPACITY_BITRATE_DESTS:-1}"
CAPACITY_DEST_STEPS="${CAPACITY_DEST_STEPS:-1 8 32 64 128 256 512 1000}"
CAPACITY_DEST_RATE="${CAPACITY_DEST_RATE:-6M}"
CAPACITY_SLOW_RATE="${CAPACITY_SLOW_RATE:-20M}"
CAPACITY_SLOW_SECONDS="${CAPACITY_SLOW_SECONDS:-30}"
CAPACITY_SUSTAINED_SECONDS="${CAPACITY_SUSTAINED_SECONDS:-60}"
CAPACITY_SUSTAINED_PROGRAMS="${CAPACITY_SUSTAINED_PROGRAMS:-4}"
CAPACITY_SUSTAINED_RATE="${CAPACITY_SUSTAINED_RATE:-6M}"
CAPACITY_SUSTAINED_DESTS="${CAPACITY_SUSTAINED_DESTS:-4}"
CAPACITY_SATURATED_SECONDS="${CAPACITY_SATURATED_SECONDS:-15}"
CAPACITY_QUALITY_RATE="${CAPACITY_QUALITY_RATE:-8M}"
CAPACITY_QUALITY_SECONDS="${CAPACITY_QUALITY_SECONDS:-120}"
CAPACITY_QUALITY_STEPS="${CAPACITY_QUALITY_STEPS:-1 2 4 8 16 32 64 128 256 512 1000}"
CAPACITY_FIXED_SRT_WORKERS="${CAPACITY_FIXED_SRT_WORKERS:-adaptive}"
CAPACITY_FIXED_HLS_PUSH_WORKERS="${CAPACITY_FIXED_HLS_PUSH_WORKERS:-adaptive}"
CAPACITY_SRT_HLS="${CAPACITY_SRT_HLS:-yes}"
# The measuring receiver, not the system under test: its SRT listeners are
# spread so no single receiver UDP socket (and libsrt receive thread) carries
# more than this many destinations.  The per-rung diagnostics report receiver
# socket drops separately, so a receiver limit is never read as a sender one.
CAPACITY_SRT_RECEIVER_PEERS="${CAPACITY_SRT_RECEIVER_PEERS:-16}"
CAPACITY_CURRENT_MIX=""
# Optional CPU placement (taskset lists, e.g. "0-3" / "4-7").  Unset means
# no pinning.  On a host where the system under test and the measuring
# receivers share cores, pinning them apart turns "the host saturated" into
# an attributable "the sender (or the receiver) saturated"; the diagnostics
# bundle records the placement either way.
CAPACITY_NGINX_CPUS="${CAPACITY_NGINX_CPUS:-}"
CAPACITY_RECEIVER_CPUS="${CAPACITY_RECEIVER_CPUS:-}"
CAPACITY_PUBLISHER_CPUS="${CAPACITY_PUBLISHER_CPUS:-}"

# Where the measuring receivers are, and how to start them there.  Unset
# keeps them on this host's loopback, which is the default for every tier
# that runs on a shared runner.  Two other topologies are supported:
#
#   CAPACITY_RECEIVER_EXEC="ip netns exec nmrecv"
#   CAPACITY_RECEIVER_ADDR="10.200.0.2"
#       the receivers run in their own network namespace and their own
#       address, so the traffic crosses a veth pair - a real device path,
#       MTU and kernel UDP stack - instead of loopback.  Sender and receiver
#       still share the CPU, so the CPU attribution stays valid but a
#       capacity number from this topology is a number about the software,
#       not about a NIC.
#
#   tests/bench/capacity_distributed.sh --receiver user@host --addr 10.10.0.2
#       builds native receivers in a fresh isolated remote root and supplies
#       CAPACITY_RECEIVER_CONFIG. SSH client PIDs are never receiver PIDs.
CAPACITY_RECEIVER_EXEC="${CAPACITY_RECEIVER_EXEC:-}"
CAPACITY_RECEIVER_ADDR="${CAPACITY_RECEIVER_ADDR:-127.0.0.1}"

# The preflight.  auto (the default) fingerprints the hosts and measures the
# path before a rung at or above CAPACITY_PREFLIGHT_MIN_DESTINATIONS; yes
# does it for every rung; no skips it.  A rung the environment cannot carry
# is recorded as infrastructure-limited instead of being measured, so a
# small runner never reports a host limit as a software limit.  The optional
# CPU-per-Gbit/s figures come from a measured rung (diagnostics.json
# "efficiency"), and without them CPU is reported as unknown rather than
# guessed.
CAPACITY_PREFLIGHT="${CAPACITY_PREFLIGHT:-auto}"
CAPACITY_PREFLIGHT_MIN_DESTINATIONS="${CAPACITY_PREFLIGHT_MIN_DESTINATIONS:-128}"
CAPACITY_PREFLIGHT_SECONDS="${CAPACITY_PREFLIGHT_SECONDS:-5}"
CAPACITY_PREFLIGHT_THREADS="${CAPACITY_PREFLIGHT_THREADS:-4}"
CAPACITY_PREFLIGHT_SENDER_CPU_PER_GBPS="${CAPACITY_PREFLIGHT_SENDER_CPU_PER_GBPS:-}"
CAPACITY_PREFLIGHT_RECEIVER_CPU_PER_GBPS="${CAPACITY_PREFLIGHT_RECEIVER_CPU_PER_GBPS:-}"
# a command that copies receiver-side artifacts back from a remote receiver
# host; unset when the receivers share this filesystem
CAPACITY_RECEIVER_COLLECT="${CAPACITY_RECEIVER_COLLECT:-}"
CAPACITY_RECEIVER_KILL="${CAPACITY_RECEIVER_KILL:-}"
# a shell snippet that tests a receiver-written file where the receivers run,
# and one that copies one back; both receive the path as $1.  Unset means the
# receivers share this filesystem.
CAPACITY_RECEIVER_FILE_TEST="${CAPACITY_RECEIVER_FILE_TEST:-}"
CAPACITY_RECEIVER_FETCH="${CAPACITY_RECEIVER_FETCH:-}"
CAPACITY_RECEIVER_MKDIR="${CAPACITY_RECEIVER_MKDIR:-}"
# Distributed transport uses a JSON configuration, not interpolated shell argv.
CAPACITY_RECEIVER_CONFIG="${CAPACITY_RECEIVER_CONFIG:-}"
CAPACITY_SENDER_ADDR="${CAPACITY_SENDER_ADDR:-127.0.0.1}"
declare -A RECEIVER_IDENTITIES=() RECEIVER_CLIENTS=()
RECEIVER_PID=""
RECEIVER_TUNNELS=()
case "$CAPACITY_RECEIVER_EXEC" in
    ssh*|*" ssh "*)
        echo "SSH receivers require capacity_distributed.sh (owned PIDs and remote paths)" >&2
        exit 1 ;;
esac
# How many programs the quality ladder runs, each owned by a different
# worker: 1 for every published tier, more for the contention repeats where
# the question is whether one program's SRT load starves another program's
# RTMP or HLS work.  The harness prints the placement it achieved, and the
# bundle records it.
# One program for a quality ladder, by construction: each rung's reference is
# a single program's rate, so a multi-program rung has nothing to be compared
# against and capacity_case refuses it rather than reporting a ratio that
# means nothing.  Multi-program behaviour is measured by the saturated case.
CAPACITY_QUALITY_PROGRAMS="${CAPACITY_QUALITY_PROGRAMS:-1}"
CAPACITY_QUALITY_MIXES="${CAPACITY_QUALITY_MIXES:-all}"
CAPACITY_QUALITY_MIN_DELIVERY_RATIO="${CAPACITY_QUALITY_MIN_DELIVERY_RATIO:-0.95}"
CAPACITY_QUALITY_INTERVAL_FLOOR="${CAPACITY_QUALITY_INTERVAL_FLOOR:-0.80}"
CAPACITY_QUALITY_MAX_LOW_SECONDS="${CAPACITY_QUALITY_MAX_LOW_SECONDS:-2}"
CAPACITY_QUALITY_QUEUE_PRESSURE="${CAPACITY_QUALITY_QUEUE_PRESSURE:-0.90}"
CAPACITY_QUALITY_PRESSURE_SAMPLES="${CAPACITY_QUALITY_PRESSURE_SAMPLES:-3}"
CAPACITY_QUALITY_BLOCKED_SAMPLES="${CAPACITY_QUALITY_BLOCKED_SAMPLES:-3}"
# Stop a workload's ladder after this many consecutive quality failures (0:
# run every rung).  The rungs above are then reported as unmeasured, never as
# failures, so a CI tier can find a boundary without spending its time budget
# on rungs past it.
CAPACITY_QUALITY_STOP_AFTER_FAILURES="${CAPACITY_QUALITY_STOP_AFTER_FAILURES:-0}"
# -muxrate makes the offered rate a parameter, so the placed and routed runs
# carry the same media and the CPU comparison is per unit carried
MP_RATE="${MP_RATE:-20M}"

# live egress: the program's own rate.  The source file is encoded at this
# target, because the destinations carry the program and not the padding: a
# transport stream padded with null packets costs the receive path and is
# dropped by the demuxer, so it does not reach an output.
LIVE_BITRATE="${LIVE_BITRATE:-20M}"
LIVE_RATE="${LIVE_RATE:-}"

PUBS=()
SINKS=()
QUALITY_MONITORS=()
STORM=0

SRT_PORTS=()
declare -A ENDPOINT_INDEX=()
declare -A SLOT=()
declare -A ROLE=()
declare -A TID_PID=()
LABELLED=1
W_BEFORE=""
W_AFTER=""
W_DUR=0
W_CPU_BEFORE_MS=0
W_CPU_AFTER_MS=0

cleanup() {
    local p
    capacity_quality_stop_monitors || true


    for p in ${PUBS[@]+"${PUBS[@]}"}; do
        kill -KILL "$p" 2>/dev/null
    done
    for p in "${!RECEIVER_IDENTITIES[@]}" ${SINKS[@]+"${SINKS[@]}"}; do
        if [[ "$p" == r* ]]; then
            receiver_stop_owner "$p"
        else
            receiver_kill -KILL "$p" 2>/dev/null || true
        fi
    done

    [ "$STORM" != "0" ] && kill -KILL "$STORM" 2>/dev/null

    stop_instance
    stop_rtmp_sink_instance

    return 0
}
trap cleanup EXIT

[ -x "$NGINX" ] || { echo "nginx is not built; run: make nginx" >&2; exit 1; }

# --- process bookkeeping ----------------------------------------------------
#
# nginx overwrites the worker's argv with its process title ("nginx: worker
# process"), so `pgrep -f <prefix>` matches nothing - an earlier version of
# this bench reported zero CPU for exactly that reason.  The workers are the
# children of the master the pid file names, which survives the retitling.

master_pid() {
    cat "$RUN/logs/nginx.pid" 2>/dev/null || true
}

worker_pids() {
    local m

    m="$(master_pid)"
    [ -n "$m" ] || return 0

    pgrep -P "$m" 2>/dev/null || true
}

pid_of() {   # <log> <ere> → the pid on the last matching line
    grep -E "$2" "$1" 2>/dev/null \
        | sed -n 's/.*\[[a-z]*\] \([0-9][0-9]*\)#.*/\1/p' | tail -1
}

# worker i binds the i-th endpoint and the log line naming the endpoint
# carries the pid that bound it, so a worker's slot is a lookup
map_slots() {
    local p i

    SLOT=()

    for p in $(worker_pids); do
        for i in "${SRT_PORTS[@]}"; do
            [ "$(pid_of "$RUN/logs/error.log" \
                  "srt listener ready on 127.0.0.1:$i\$")" = "$p" ] \
                && SLOT["$p"]="${ENDPOINT_INDEX[$i]}"
        done
    done

    return 0
}

# taskset prefix for a placement list, or nothing
pin() {   # <cpu list>
    if [ -n "$1" ]; then
        printf 'taskset\n-c\n%s\n' "$1"
    fi
}

# Local and network-namespace receivers share PIDs/files; SSH does not.
receiver_run() {
    local -a prefix=()
    if [ -n "$CAPACITY_RECEIVER_CONFIG" ]; then
        receiver_transport exec "$@"
    else
        read -r -a prefix <<< "$CAPACITY_RECEIVER_EXEC"
        "${prefix[@]}" "$@"
    fi
}

receiver_transport() {
    python3 "$ROOT/tests/bench/capacity_receiver.py" \
        --config "$CAPACITY_RECEIVER_CONFIG" "$@"
}

# Prepared captures expose the transport client's PID, not a shell wrapper.
# Only the transport publishes READY after the native capture is prepared.
receiver_capture() {
    (
        local client="" status=0
        local -a gate=()
        if [ -n "${CAPTURE_READY_FILE:-}" ]; then
            gate=( --capture-ready-file "$CAPTURE_READY_FILE"
                   --capture-release-file "$CPU_CAPTURE_RELEASE_FILE" )
        fi
        trap '[ -z "$client" ] || { kill "$client" 2>/dev/null || true; wait "$client" 2>/dev/null || true; }' EXIT
        trap 'exit 1' TERM INT
        python3 "$ROOT/tests/bench/capacity_receiver.py" \
            --config "$CAPACITY_RECEIVER_CONFIG" "${gate[@]}" "$@" &
        client="$!"
        if [ -n "${CAPTURE_READY_FILE:-}" ]; then
            printf '%s\n' "$client" >"$CAPTURE_READY_FILE.pid" || exit 1
        fi
        wait "$client" || status=$?
        client=""
        exit "$status"
    )
}

# Local and namespace captures use the same release as the prepared RPCs.
capacity_capture_gate() {
    local attempt pid
    [ -n "${CAPTURE_READY_FILE:-}" ] || return 0
    printf '%s\n' "$BASHPID" >"$CAPTURE_READY_FILE.pid" || return 1
    : >"$CAPTURE_READY_FILE" || return 1
    for (( attempt=0; attempt<60000; attempt++ )); do
        for pid in "$@"; do
            kill -0 "$pid" 2>/dev/null || return 1
        done
        [ ! -f "$CPU_CAPTURE_RELEASE_FILE" ] || return 0
        sleep 0.001
    done
    echo "controller did not release $CAPTURE_READY_FILE" >&2
    return 1
}

receiver_path() {
    if [ -n "$CAPACITY_RECEIVER_CONFIG" ]; then
        receiver_transport path "$1"
    else
        printf '%s' "$1"
    fi
}

# Keep host-qualified PID tokens: remote PID 123 must not alias local PID 123.
receiver_start() {   # <identity file> <log> <argv...>; sets RECEIVER_PID
    local identity="$1" log="$2" client pid attempt
    shift 2
    if [ -z "$CAPACITY_RECEIVER_CONFIG" ]; then
        local -a prefix=()
        read -r -a prefix <<< "$CAPACITY_RECEIVER_EXEC"
        "${prefix[@]}" "$@" >"$log" 2>&1 &
        RECEIVER_PID="$!"
        return 0
    fi
    receiver_mkdir "$(dirname "$identity")" || return 1
    python3 "$ROOT/tests/bench/capacity_receiver.py" --config "$CAPACITY_RECEIVER_CONFIG" \
        --owner-pid "$$" start "$identity" "$@" >"$log" 2>&1 &
    client="$!"
    for attempt in $(seq 1 100); do
        if receiver_file_ready "$identity"; then
            if ! receiver_fetch "$identity"; then
                kill -KILL "$client" 2>/dev/null || true
                wait "$client" 2>/dev/null || true
                return 1
            fi
            if ! pid="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["pid"])' "$identity")"; then
                kill -KILL "$client" 2>/dev/null || true
                wait "$client" 2>/dev/null || true
                return 1
            fi
            RECEIVER_PID="r$pid"
            RECEIVER_IDENTITIES["$RECEIVER_PID"]="$identity"
            RECEIVER_CLIENTS["$RECEIVER_PID"]="$client"
            if ! receiver_alive "$RECEIVER_PID"; then
                receiver_stop_owner "$RECEIVER_PID"
                return 1
            fi
            return 0
        fi
        kill -0 "$client" 2>/dev/null || { wait "$client" || true; cat "$log" >&2; return 1; }
        sleep 0.05
    done
    kill -KILL "$client" 2>/dev/null || true
    wait "$client" 2>/dev/null || true
    echo "receiver did not publish its process identity" >&2
    return 1
}

receiver_kill() {   # -SIGNAL PID
    if [[ "${2:-}" == r* ]]; then
        local status=0 client
        [ -n "${RECEIVER_IDENTITIES[$2]:-}" ] || return 1
        receiver_transport signal "${RECEIVER_IDENTITIES[$2]}" "$1" || status=$?
        if [ "$status" -ne 0 ]; then
            case "$1" in
                -KILL|-TERM|-QUIT)
                    client="${RECEIVER_CLIENTS[$2]:-}"
                    [ -z "$client" ] || kill -KILL "$client" 2>/dev/null || true
                    ;;
            esac
        fi
        return "$status"
    elif [ -n "$CAPACITY_RECEIVER_KILL" ]; then
        $CAPACITY_RECEIVER_KILL "$@"
    else
        kill "$@"
    fi
}

receiver_alive() { receiver_kill -0 "$1" 2>/dev/null; }

receiver_wait() {
    local pid="$1" client status=0
    if [[ "$pid" == r* ]]; then
        client="${RECEIVER_CLIENTS[$pid]:-}"
        [ -n "$client" ] || return 127
        wait "$client" || status=$?
        unset "RECEIVER_CLIENTS[$pid]" "RECEIVER_IDENTITIES[$pid]"
        return "$status"
    else
        wait "$pid"
    fi
}

receiver_stop_owner() {   # <host-qualified PID>; close its owned SSH pipe
    local pid="$1" client
    [[ "$pid" == r* ]] || return 0
    client="${RECEIVER_CLIENTS[$pid]:-}"
    [ -n "$client" ] || return 0
    kill -KILL "$client" 2>/dev/null || true
    wait "$client" 2>/dev/null || true
    unset "RECEIVER_CLIENTS[$pid]" "RECEIVER_IDENTITIES[$pid]"
}

receiver_remove() {
    rm -f "$1" || return 1
    [ -z "$CAPACITY_RECEIVER_CONFIG" ] || receiver_transport remove "$1"
}

slot_name() {   # <pid>
    if [ -n "${SLOT[$1]:-}" ]; then
        printf 'w%s' "${SLOT[$1]}"
    else
        printf 'pid%s' "$1"
    fi
}

stop_instance() {
    local m p

    m="$(master_pid)"
    [ -n "$m" ] || return 0

    # workers first: killing the master outright orphans them, and an orphaned
    # worker still holds its SRT port and its routing sockets
    for p in $(pgrep -P "$m" 2>/dev/null); do
        kill -KILL "$p" 2>/dev/null
    done

    kill -QUIT "$m" 2>/dev/null
    sleep 1
    kill -KILL "$m" 2>/dev/null

    rm -f "$RUN/logs/nginx.pid"

    return 0
}

rtmp_sink_port() {   # <sink index>
    printf '%s' "$(( BASE + 128 + $1 ))"
}

rtmp_sink_http_port() {   # <sink index>
    printf '%s' "$(( BASE + 192 + $1 ))"
}

stop_rtmp_sink_instance() {
    local m p dir
    if [ -n "$CAPACITY_RECEIVER_CONFIG" ]; then
        for m in "${RTMP_REMOTE_MASTERS[@]:-}"; do
            [ -n "$m" ] || continue
            receiver_kill -QUIT "$m" 2>/dev/null || true
            receiver_stop_owner "$m"
        done
        RTMP_REMOTE_MASTERS=()
        for p in "${RECEIVER_TUNNELS[@]:-}"; do
            [ -n "$p" ] || continue
            kill -KILL "$p" 2>/dev/null || true
            wait "$p" 2>/dev/null || true
        done
        RECEIVER_TUNNELS=()
    else
        for dir in "$RTMP_SINK_RUN"-*; do
            [ -d "$dir" ] || continue
            m="$(cat "$dir/logs/nginx.pid" 2>/dev/null || true)"
            [ -n "$m" ] || continue
            for p in $(pgrep -P "$m" 2>/dev/null); do
                kill -KILL "$p" 2>/dev/null
                unset "ROLE[$p]" "SLOT[$p]"
            done
            kill -QUIT "$m" 2>/dev/null
            sleep 0.2
            kill -KILL "$m" 2>/dev/null
            rm -f "$dir/logs/nginx.pid"
        done
    fi
    RTMP_SINK_PIDS=()
    RTMP_SINK_WORKER_PID=""
}

start_rtmp_sink_instance() {   # [count]
    local i k m dir pid count="${1:-1}"

    stop_rtmp_sink_instance
    [ "$count" -ge 1 ] && [ "$count" -le 64 ] \
        || { echo "RTMP sink count must be 1..64" >&2; return 1; }
    local receiver_nginx="$NGINX" api_bind="$CAPACITY_RECEIVER_ADDR" daemon=on
    if [ -n "$CAPACITY_RECEIVER_CONFIG" ]; then
        receiver_nginx="$(receiver_path "$ROOT/.build/nginx-install/sbin/nginx")"
        api_bind=127.0.0.1
        daemon=off
    fi
    RTMP_SINK_COUNT="$count"

    for (( k = 0; k < count; k++ )); do
        dir="$RTMP_SINK_RUN-$k"
        rm -rf "$dir/logs"
        mkdir -p "$dir/conf" "$dir/logs"
        [ ! -f "$RUN/active-capacity-case" ] \
            || cp "$RUN/active-capacity-case" "$dir/active-case"
        cat > "$dir/conf/nginx.conf" <<EOF
worker_processes 1;
daemon $daemon;
error_log logs/error.log info;
pid logs/nginx.pid;

events { worker_connections 8192; }

media_rtmp_listen $CAPACITY_RECEIVER_ADDR:$(rtmp_sink_port "$k");

http {
    server {
        listen $api_bind:$(rtmp_sink_http_port "$k");
        location /media/api/ { media_api; }
    }
}
EOF
        if [ -n "$CAPACITY_RECEIVER_CONFIG" ]; then
            receiver_mkdir "$dir/conf" || return 1
            receiver_mkdir "$dir/logs" || return 1
            receiver_transport push "$dir/conf/nginx.conf" || return 1
            receiver_run "$receiver_nginx" -p "$(receiver_path "$dir")" \
                -c conf/nginx.conf -t >"$dir/conf.log" 2>&1 \
                || { cat "$dir/conf.log" >&2; return 1; }
            receiver_start "$dir/identity.json" "$dir/receiver.log" \
                $(pin "$CAPACITY_RECEIVER_CPUS") "$receiver_nginx" \
                -p "$(receiver_path "$dir")" -c conf/nginx.conf || return 1
            RTMP_REMOTE_MASTERS+=( "$RECEIVER_PID" )
            python3 - "$(( BASE + 256 + k ))" <<'PY' || return 1
import socket, sys
with socket.socket() as listener:
    listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    listener.bind(("127.0.0.1", int(sys.argv[1])))
PY
            python3 "$ROOT/tests/bench/capacity_receiver.py" --config "$CAPACITY_RECEIVER_CONFIG" \
                --owner-pid "$$" tunnel "$(( BASE + 256 + k ))" "$(rtmp_sink_http_port "$k")" \
                >"$dir/tunnel.log" 2>&1 &
            RECEIVER_TUNNELS+=( "$!" )
        else
            "$NGINX" -p "$dir" -c conf/nginx.conf -t >"$dir/conf.log" 2>&1 \
                || { cat "$dir/conf.log" >&2; return 1; }
            receiver_run $(pin "$CAPACITY_RECEIVER_CPUS") \
                "$NGINX" -p "$dir" -c conf/nginx.conf || return 1
        fi
    done

    for (( k = 0; k < count; k++ )); do
        dir="$RTMP_SINK_RUN-$k"
        for i in $(seq 1 200); do
            curl -fsS "$(rtmp_sink_api "$k")/metrics" >/dev/null 2>&1 && break
            sleep 0.05
        done
        if ! curl -fsS "$(rtmp_sink_api "$k")/metrics" >/dev/null 2>&1; then
            echo "RTMP sink $k did not become ready" >&2
            stop_rtmp_sink_instance
            return 1
        fi
        if [ -n "$CAPACITY_RECEIVER_CONFIG" ]; then
            m="${RTMP_REMOTE_MASTERS[$k]}"
            pid="$(receiver_transport children "${RECEIVER_IDENTITIES[$m]}" | sort -n | cut -d ' ' -f 1)"
            [[ "$pid" =~ ^[0-9]+$ ]] || { echo "invalid remote RTMP worker PID" >&2; return 1; }
            pid="r$pid"
            RECEIVER_IDENTITIES["$pid"]="${RECEIVER_IDENTITIES[$m]}"
        else
            m="$(cat "$dir/logs/nginx.pid" 2>/dev/null || true)"
            pid="$(pgrep -P "$m" 2>/dev/null | sed -n '1p')"
        fi
        if [ -z "$pid" ]; then
            echo "RTMP sink $k worker did not start" >&2
            stop_rtmp_sink_instance
            return 1
        fi
        RTMP_SINK_PIDS+=( "$pid" )
        ROLE["$pid"]="worker"
        SLOT["$pid"]="rtmp-sink-$k"
    done
    # set whenever at least one sink runs
    RTMP_SINK_WORKER_PID="${RTMP_SINK_PIDS[0]}"
}

# --- thread labelling -------------------------------------------------------

label_worker() {   # <pid> → 0 when a backtrace with symbols was read
    local pid="$1" out tid role

    out="$(sudo -n gdb -p "$pid" -batch -ex 'thread apply all bt 14' 2>/dev/null)"
    [ -n "$out" ] || return 1

    out="$(printf '%s\n' "$out" | awk '
        /^Thread [0-9]+ \(Thread/ {
            if (tid != "") { print tid, (role == "" ? "unlabelled" : role) }
            match($0, /LWP [0-9]+/)
            tid = substr($0, RSTART + 4, RLENGTH - 4)
            role = ""
            next
        }
        /ngx_media_srt_thread/       { role = "ingest" }
        /ngx_media_srt_out_thread/   { if (role == "") role = "srt-send" }
        /ngx_media_hls_push_thread/  { if (role == "") role = "hls-push" }
        /ngx_worker_process_cycle/   { if (role == "") role = "worker" }
        /CRcvQueue::worker/          { if (role == "") role = "SRT:RcvQ" }
        /CSndQueue::worker/          { if (role == "") role = "SRT:SndQ" }
        /CUDT::tsbpd/                { if (role == "") role = "SRT:TsbPd" }
        /garbageCollect/             { if (role == "") role = "SRT:GC" }
        END { if (tid != "") print tid, (role == "" ? "unlabelled" : role) }
    ')"

    [ -n "$out" ] || return 1

    while read -r tid role; do
        ROLE["$tid"]="$role"
    done <<< "$out"

    return 0
}

label_all() {
    local p

    LABELLED=1
    ROLE=()

    for p in $(worker_pids); do
        label_worker "$p" || LABELLED=0
    done
}

write_cpu_roles() {
    local tid

    : > "$RUN/roles" || return 1
    for tid in "${!ROLE[@]}"; do
        printf '%s\t%s\n' "$tid" "${ROLE[$tid]}" >> "$RUN/roles" \
            || return 1
    done
}

# One Python process takes both snapshots and enumerates every sampled task
# directory once per sample. Optional extra PIDs expose receiver-side CPU.
# CPU_SNAPSHOT_DIR, when set (a capacity case sets it to its own directory),
# keeps the raw snapshots with the case instead of in shared $RUN files that
# the next window overwrites. Extended host/network captures keep their own
# collection brackets outside the synchronized CPU accounting boundaries.
cpu_window() {   # <seconds> [extra PID ...]
    local result extra dir="${CPU_SNAPSHOT_DIR:-$RUN}" local_sampler remote_sampler=""
    local remote_request="" callback_pid="" boundary attempt status=0 action gate_dir ready_file capture_pid
    local -a pids=() remote_pids=() extended=() boundaries=()
    W_BEFORE="$dir/cpu.before"
    W_AFTER="$dir/cpu.after"
    write_cpu_roles || return 1
    cp "$RUN/roles" "$dir/cpu.roles" || return 1
    mapfile -t pids < <(worker_pids)
    for extra in "${@:2}"; do
        [ -n "$extra" ] || continue
        if [[ "$extra" == r* ]]; then
            remote_pids+=( "${extra#r}" )
        else
            pids+=( "$extra" )
        fi
    done
    [ "${#pids[@]}" -gt 0 ] || return 1
    if [ -n "${CPU_SNAPSHOT_DIR:-}" ]; then
        extended=( --extended-before "$dir/host.before.json"
                   --extended-after "$dir/host.after.json" )
    fi
    if [ -n "${CPU_BOUNDARY_CALLBACK:-}" ] || [ "${#remote_pids[@]}" -gt 0 ]; then
        boundaries=( --boundary-dir "$dir" )
        rm -f "$dir"/cpu.ready.* "$dir"/cpu.release.* "$dir"/cpu.captured.*
        rm -rf "$dir/capture.before" "$dir/capture.after"
    fi
    if [ "${#remote_pids[@]}" -gt 0 ]; then
        mkdir -p "$dir/receiver-boundary" || return 1
        receiver_mkdir "$dir/receiver-boundary" || return 1
        for boundary in before after; do
            receiver_remove "$dir/receiver-boundary/cpu.ready.$boundary" || return 1
            receiver_remove "$dir/receiver-boundary/cpu.release.$boundary" || return 1
            receiver_remove "$dir/receiver-boundary/cpu.captured.$boundary.json" || return 1
        done
        python3 - "$dir/cpu.roles" "$dir/receiver.roles" <<'PY'
import sys
with open(sys.argv[2], "w") as output:
    for line in open(sys.argv[1]):
        pid, role = line.rstrip().split("\t", 1)
        if pid.startswith("r"):
            output.write(pid[1:] + "\t" + role + "\n")
PY
        receiver_transport push "$dir/receiver.roles" || return 1
        receiver_start "$dir/receiver-cpu.identity.json" "$dir/receiver-cpu.log" \
            python3 "$ROOT/tests/bench/proc_cpu_sampler.py" sample \
            --sleep "$1" --roles "$dir/receiver.roles" \
            --before "$dir/receiver.cpu.before" --after "$dir/receiver.cpu.after" \
            --extended-before "$dir/receiver.host.before.json" \
            --extended-after "$dir/receiver.host.after.json" \
            --boundary-dir "$dir/receiver-boundary" "${remote_pids[@]}" || return 1
        remote_sampler="$RECEIVER_PID"
    fi
    python3 "$ROOT/tests/bench/proc_cpu_sampler.py" sample \
        --sleep "$1" --roles "$RUN/roles" --before "$W_BEFORE" --after "$W_AFTER" \
        "${extended[@]}" "${boundaries[@]}" "${pids[@]}" >"$dir/cpu.window.log" &
    local_sampler="$!"
    if [ "${#boundaries[@]}" -gt 0 ]; then
        for boundary in before after; do
            # Local readiness ends the requested sleep. Receiver RPC startup,
            # native preparation and sampler quiescence precede shared release.
            for attempt in $(seq 1 1200); do
                [ ! -f "$dir/cpu.ready.$boundary" ] || break
                kill -0 "$local_sampler" 2>/dev/null || { status=1; break; }
                sleep 0.05
            done
            [ -f "$dir/cpu.ready.$boundary" ] || status=1
            [ "$status" -eq 0 ] || break
            action=start
            [ "$boundary" = before ] || action=stop
            gate_dir="$dir/capture.$boundary"
            mkdir -p "$gate_dir" || { status=1; break; }
            remote_request=""
            callback_pid=""
            if [ -n "$remote_sampler" ]; then
                python3 "$ROOT/tests/bench/capacity_receiver.py" \
                    --config "$CAPACITY_RECEIVER_CONFIG" \
                    --capture-ready-file "$gate_dir/cpu.ready" \
                    --capture-release-file "$dir/cpu.release.$boundary" \
                    cpu-boundary "${RECEIVER_IDENTITIES[$remote_sampler]}" \
                    "$dir/receiver-boundary" "$boundary" \
                    "$dir/receiver.cpu.$boundary.capture.json" \
                    >"$dir/receiver.cpu.$boundary.boundary.log" 2>&1 &
                remote_request="$!"
            fi
            if [ -n "${CPU_BOUNDARY_CALLBACK:-}" ]; then
                CPU_CAPTURE_READY_DIR="$gate_dir" \
                    CPU_CAPTURE_RELEASE_FILE="$dir/cpu.release.$boundary" \
                    "$CPU_BOUNDARY_CALLBACK" "$action" &
                callback_pid="$!"
            fi
            for attempt in $(seq 1 1200); do
                [ -z "$remote_request" ] || kill -0 "$remote_request" 2>/dev/null \
                    || { status=1; break; }
                [ -z "$callback_pid" ] || kill -0 "$callback_pid" 2>/dev/null \
                    || { status=1; break; }
                if { [ -z "$remote_request" ] || [ -f "$gate_dir/cpu.ready" ]; } \
                    && { [ -z "$callback_pid" ] || [ -f "$gate_dir/protocols.ready" ]; }; then
                    break
                fi
                kill -0 "$local_sampler" 2>/dev/null || { status=1; break; }
                sleep 0.005
            done
            [ -z "$remote_request" ] || [ -f "$gate_dir/cpu.ready" ] || status=1
            [ -z "$callback_pid" ] || [ -f "$gate_dir/protocols.ready" ] || status=1
            for ready_file in "$gate_dir"/*.ready.pid; do
                [ -f "$ready_file" ] || continue
                read -r capture_pid <"$ready_file" || { status=1; break; }
                kill -0 "$capture_pid" 2>/dev/null || { status=1; break; }
            done
            [ "$status" -eq 0 ] || break
            : >"$dir/cpu.release.$boundary"
            [ -z "$callback_pid" ] || wait "$callback_pid" || status=1
            [ -z "$remote_request" ] || wait "$remote_request" || status=1
            [ "$status" -eq 0 ] || break
        done
    fi
    if [ "$status" -ne 0 ]; then
        [ -z "$callback_pid" ] || kill "$callback_pid" 2>/dev/null || true
        [ -z "$remote_request" ] || kill "$remote_request" 2>/dev/null || true
        [ -z "$callback_pid" ] || wait "$callback_pid" 2>/dev/null || true
        [ -z "$remote_request" ] || wait "$remote_request" 2>/dev/null || true
        kill "$local_sampler" 2>/dev/null || true
        [ -z "$remote_sampler" ] || receiver_kill -KILL "$remote_sampler" 2>/dev/null || true
    fi
    wait "$local_sampler" || status=1
    if [ -n "$remote_sampler" ]; then
        receiver_wait "$remote_sampler" || status=1
        [ "$status" -eq 0 ] || return 1
        for extra in receiver.cpu.before receiver.cpu.after receiver.host.before.json receiver.host.after.json; do
            receiver_fetch "$dir/$extra" || status=1
        done
        python3 - "$dir/receiver.cpu.window" "$dir" <<'PY' || return 1
import json, pathlib, sys
window = {"clock_domain": "controller-monotonic"}
for boundary, phase in (("before", "start"), ("after", "end")):
    path = pathlib.Path(sys.argv[2]) / f"receiver.cpu.{boundary}.capture.json"
    native = json.loads(path.read_text())
    bracket = json.loads(path.with_name(path.name + ".request.json").read_text())
    begin, end = bracket["request_ns"], bracket["reply_ns"]
    window[phase + "_ns"] = (begin + end) // 2
    window[phase + "_uncertainty_ns"] = (end - begin) // 2
    window[phase + "_request_ns"] = begin
    window[phase + "_reply_ns"] = end
    window["native_" + phase + "_ns"] = (
        native["capture_start_ns"] + native["capture_end_ns"]) // 2
    window["native_" + phase + "_capture_start_ns"] = native["capture_start_ns"]
    window["native_" + phase + "_capture_end_ns"] = native["capture_end_ns"]
pathlib.Path(sys.argv[1]).write_text(json.dumps(window))
PY
    fi
    [ "$status" -eq 0 ] || return 1
    read -r W_DUR W_CPU_BEFORE_MS W_CPU_AFTER_MS <"$dir/cpu.window.log"
    [ -n "$W_DUR" ] && [ -n "$W_CPU_BEFORE_MS" ] && [ -n "$W_CPU_AFTER_MS" ]
}

# per (worker, role) percent of one core between two samples; the sampler's
# report accounts for thread churn, TID reuse and the kernel's real tick rate
report_cpu() {   # <before> <after> <seconds>
    local pid role pct

    python3 "$ROOT/tests/bench/proc_cpu_sampler.py" report "$1" "$2" \
        --window "$3" | sort -k2,2 -k1,1 | while read -r pid role pct; do
        printf '%s %s %s\n' "$(slot_name "$pid")" "$role" "$pct"
    done
}

# the roles worth a line of their own
detail_cpu() {   # <before> <after> <seconds>
    report_cpu "$1" "$2" "$3" | awk '
        $2 == "SRT:RcvQ" || $2 == "SRT:SndQ" || $2 == "SRT:TsbPd" \
        || $2 == "ingest" || $2 == "worker" || $2 == "srt-send" \
        || $2 == "SRT:GC" || $2 == "hls-push" || $2 ~ /^srt-egress-/ \
        { print; next }
        { other[$1] += $3 }
        END { for (w in other) printf "%s other %d\n", w, other[w] }
    ' | sort
}

cpu_total() {   # <before> <after> <seconds>
    report_cpu "$1" "$2" "$3" \
        | awk '{ c[$1] += $3 } END { for (w in c) printf "%s=%d%% ", w, c[w] }'
}

# --- API helpers ------------------------------------------------------------
#
# The control API answers from the worker that accepts the request.  With more
# than one worker a request can land on a replica, where a mutation is refused
# with not_owner and where the program's fanout histogram is empty - the feed
# is the owner's.  Two URLs in one curl invocation share the connection, so
# they land on the same worker: reading the stream document first says whether
# the worker that will answer the metrics is the owner.

api() { printf 'http://127.0.0.1:%s/media/api/v1' "$HTTP_PORT"; }

rtmp_sink_api() {   # [sink index]
    local address="$CAPACITY_RECEIVER_ADDR" port
    port="$(rtmp_sink_http_port "${1:-0}")"
    if [ -n "$CAPACITY_RECEIVER_CONFIG" ]; then
        address=127.0.0.1
        port=$(( BASE + 256 + ${1:-0} ))
    fi
    printf 'http://%s:%s/media/api/v1' "$address" "$port"
}

# every sink's metrics URL, comma separated, for the RTMP quality tools
rtmp_sink_metric_urls() {
    local k urls=""

    for (( k = 0; k < RTMP_SINK_COUNT; k++ )); do
        urls+="${urls:+,}$(rtmp_sink_api "$k")/metrics"
    done
    printf '%s' "$urls"
}

stream_field() {   # <name> <field>
    curl -fsS "$(api)/streams/live/$1" 2>/dev/null \
        | sed -n "s/.*\"$2\":\([0-9]*\).*/\1/p" | head -1
}

# A read can land on a worker that has no copy of a stream a publisher
# created, and answers 404.  Retrying is how the owner is reached; the value
# itself is the owner's either way, because program progress is published in
# the shared directory.
field_any() {   # <name> <field> [tries]
    local i v

    for i in $(seq 1 "${3:-12}"); do
        v="$(stream_field "$1" "$2")"
        [ -n "$v" ] && { printf '%s' "$v"; return 0; }
        sleep 0.2
    done

    return 1
}

owner_of() {   # <name> → the owner the graph reports
    local i v

    for i in $(seq 1 40); do
        v="$(stream_field "$1" owner)"
        [ -n "$v" ] && { printf '%s' "$v"; return 0; }
        sleep 0.25
    done

    return 1
}

owner_metrics() {   # <name> → the owner's own metrics, on one connection
    local i out

    for i in $(seq 1 40); do
        out="$(curl -fsS "$(api)/streams/live/$1" "$(api)/metrics" 2>/dev/null)" \
            || continue

        case "$out" in
            *'"observed_here":true'*) printf '%s' "$out"; return 0 ;;
        esac
    done

    return 1
}

owner_metric() {   # <name> <metric>
    owner_metrics "$1" 2>/dev/null \
        | grep "^$2{application=\"live\",name=\"$1\"" | awk '{print $2}' | head -1
}
blob_label_metric() {   # <metrics> <metric> <stream>
    printf '%s\n' "$1" \
        | grep "^$2{application=\"live\",name=\"$3\"" \
        | awk '{print $2}' | head -1 || true
}

blob_source_metric() {   # <metrics> <metric> <stream>
    printf '%s\n' "$1" \
        | grep "^$2{application=\"live\",name=\"$3\",source=\"enc-$3\"" \
        | awk '{print $2}' | head -1 || true
}

blob_global_metric() {   # <metrics> <metric>
    printf '%s\n' "$1" \
        | sed -n "/^$2 /{s/^$2 //;p;q;}" || true
}

endpoint_worker() {   # <port> → the worker that logged the listener
    local pid

    pid="$(pid_of "$RUN/logs/error.log" \
        "srt listener ready on 127.0.0.1:$1\$")"

    if [ -n "$pid" ]; then
        slot_name "$pid"
    else
        printf 'unknown'
    fi
}


owner_percentile() {   # <name> <percentile>
    owner_metrics "$1" 2>/dev/null \
        | grep "fanout_delay_ms{application=\"live\",name=\"$1\"" \
        | grep "percentile=\"$2\"" | awk '{print $2}' | head -1
}

post_owner() {   # <path> <json> ; retried until the owner answers it
    local i code

    for i in $(seq 1 60); do
        code="$(curl -sS -o /dev/null -w '%{http_code}' -X POST \
            -H 'Content-Type: application/json' -d "$2" "$(api)$1" 2>/dev/null)"

        case "$code" in
            2*) return 0 ;;
            # 409 not_owner and 404 both mean "this worker cannot answer for
            # that stream": with more than one worker the request lands on a
            # replica, so the next attempt is the point, not an error
            409|404) sleep 0.2 ;;
            *)  echo "   POST $1 answered $code" >&2; return 1 ;;
        esac
    done

    echo "   POST $1 never reached the owner" >&2
    return 1
}

# --- the owner hash ---------------------------------------------------------
#
# FNV-1a over application/stream, the arithmetic in src/core/ngx_media_owner.c,
# so streams whose owner is a chosen slot can be named on purpose.

owner_names() {   # <slot> <workers> <count> <prefix> → names, one per line
    python3 - "$1" "$2" "$3" "$4" <<'PY'
import sys

want, workers, count, prefix = (int(sys.argv[1]), int(sys.argv[2]),
                                int(sys.argv[3]), sys.argv[4])
found = 0

for i in range(1, 20000):
    name = "%s%d" % (prefix, i)
    h = 14695981039346656037
    for b in b"live/" + name.encode():
        h ^= b
        h = (h * 1099511628211) & ((1 << 64) - 1)
    if h % workers == want:
        print(name)
        found += 1
        if found == count:
            break
PY
}

# --- the instance -----------------------------------------------------------

make_source() {   # <path> <bitrate>
    ffmpeg -hide_banner -loglevel error -f lavfi \
        -i "testsrc2=size=1280x720:rate=25" \
        -c:v libx264 -preset ultrafast -g 50 -pix_fmt yuv420p \
        -b:v "$2" -maxrate "$2" -minrate "$2" -bufsize 60M \
        -t 30 -f mpegts "$1" 2>/dev/null

    [ -s "$1" ] || { echo "could not build the $2 source" >&2; exit 1; }

    printf '   source %s: %s KiB over 30s (%.1f Mbit/s)\n' \
        "$2" "$(( $(stat -c %s "$1") / 1024 ))" \
        "$(awk -v b="$(stat -c %s "$1")" 'BEGIN { printf "%.1f", b * 8 / 30 / 1000000 }')"
}

write_config() {   # <workers> <hls yes|no> <rtmp yes|no>
    local w="$1" i

    SRT_PORTS=()
    ENDPOINT_INDEX=()

    for i in $(seq 0 $(( w - 1 ))); do
        SRT_PORTS+=( "$(( BASE + 2 + i ))" )
        ENDPOINT_INDEX[$(( BASE + 2 + i ))]="$i"
    done

    {
        echo "worker_processes $w;"
        echo "daemon on;"
        echo "error_log logs/error.log info;"
        echo "pid logs/nginx.pid;"
        [ "$CAPACITY_FIXED_SRT_WORKERS" = adaptive ] \
            || echo "media_egress_workers srt $CAPACITY_FIXED_SRT_WORKERS;"
        [ "$CAPACITY_FIXED_HLS_PUSH_WORKERS" = adaptive ] \
            || echo "media_egress_workers hls_push $CAPACITY_FIXED_HLS_PUSH_WORKERS;"
        echo
        echo "events { worker_connections 8192; }"
        echo
        echo "media_ingest_secret $RUN/ingest.secret;"

        [ "$2" = yes ] && echo "media_hls $RUN/hls;"

        for i in "${SRT_PORTS[@]}"; do
            echo "media_srt_listen 127.0.0.1:$i;"
        done

        [ "$3" = yes ] && echo "media_rtmp_listen 127.0.0.1:$RTMP_PORT;"

        echo
        echo "http {"

        if [ "$2" = yes ]; then
            echo "    log_format media_pid \"\$pid \$bytes_sent\";"
            echo "    access_log logs/access.log media_pid;"
        else
            echo "    access_log off;"
        fi

        echo
        echo "    server {"
        echo "        listen 127.0.0.1:$HTTP_PORT reuseport;"
        echo
        echo "        location /media/api/ { media_api; }"
        echo "        location /hls/       { alias $RUN/hls/; }"
        echo "    }"
        if [ "$2" = yes ] && [ "$CAPACITY_SENDER_ADDR" != 127.0.0.1 ]; then
            # Media only: never expose the unauthenticated administration API.
            echo "    server {"
            echo "        listen $CAPACITY_SENDER_ADDR:$(( HTTP_PORT + 31 ));"
            echo "        location /hls/ { alias $RUN/hls/; }"
            echo "        location / { return 404; }"
            echo "    }"
        fi
        echo "}"
    } > "$RUN/conf/nginx.conf"
}

start_instance() {   # <workers> <hls> <rtmp>
    local i want

    stop_instance
    rm -rf "$RUN/hls" "$RUN/logs"
    mkdir -p "$RUN/logs" "$RUN/hls"

    write_config "$1" "$2" "$3"

    "$NGINX" -p "$RUN" -c conf/nginx.conf -t >"$RUN/conf.log" 2>&1 \
        || { cat "$RUN/conf.log" >&2; echo "configuration rejected" >&2; exit 1; }

    $(pin "$CAPACITY_NGINX_CPUS" | tr '\n' ' ') "$NGINX" -p "$RUN" -c conf/nginx.conf

    for i in $(seq 1 400); do
        want="$(grep -c 'srt listener ready' "$RUN/logs/error.log" 2>/dev/null || true)"
        [ "${want:-0}" -ge "$1" ] && break
        sleep 0.05
    done

    want="$(grep -c 'srt listener ready' "$RUN/logs/error.log" 2>/dev/null || true)"
    [ "${want:-0}" -ge "$1" ] \
        || { echo "not every endpoint was bound ($want of $1)" >&2
             tail -5 "$RUN/logs/error.log" >&2; exit 1; }

    if [ "$3" = yes ]; then
        for i in $(seq 1 200); do
            grep -q 'rtmp listener ready' "$RUN/logs/error.log" 2>/dev/null && break
            sleep 0.05
        done
    fi

    map_slots
    label_all

    # the placement every number below depends on: which worker bound which
    # endpoint, read back from the log
    PLACEMENT=""
    for i in $(seq 0 $(( $1 - 1 ))); do
        PLACEMENT="$PLACEMENT ${SRT_PORTS[$i]}->$(slot_name "$(pid_of "$RUN/logs/error.log" "srt listener ready on 127.0.0.1:${SRT_PORTS[$i]}\$")")"
    done

    return 0
}

publish() {   # <endpoint port> <name> <source> [muxrate]
    local rate=()

    # -muxrate pads the transport stream to a chosen rate, so the packet rate
    # a publisher offers is a parameter rather than whatever the content
    # happens to encode to
    [ -n "${4:-}" ] && rate=( -muxrate "$4" )

    $(pin "$CAPACITY_PUBLISHER_CPUS" | tr '\n' ' ') ffmpeg -hide_banner -loglevel error -re -stream_loop -1 -i "$3" -c copy \
        "${rate[@]}" -f mpegts \
        "$(media_test_srt_publisher_url "$(api)" 127.0.0.1 "$1" live "$2" "enc-$2" 0)" \
        >/dev/null 2>&1 &
}

kill_pubs() {
    local p

    for p in ${PUBS[@]+"${PUBS[@]}"}; do
        kill -KILL "$p" 2>/dev/null
    done

    # reaped, so the shell does not print a "Killed" line per publisher
    for p in ${PUBS[@]+"${PUBS[@]}"}; do
        wait "$p" 2>/dev/null
    done

    PUBS=()
    return 0
}

kill_one() {   # <pid> ; the same, for a single publisher or receiver
    [ -n "${1:-}" ] || return 0
    receiver_kill -KILL "$1" 2>/dev/null || true
    if [[ "$1" == r* ]]; then
        receiver_stop_owner "$1"
    else
        receiver_wait "$1" 2>/dev/null || true
    fi
    return 0
}

# --- ingest throughput, per worker ------------------------------------------
#
# Every worker's own main thread logs what its ingest thread drained, so the
# line is per-worker evidence of how much arrived and how much of it the raw
# queue dropped.  The counters are cumulative, so the window is a delta.

drained_last() {   # <pid> <field>
    grep "^.*\[[a-z]*\] $1#" "$RUN/logs/error.log" 2>/dev/null \
        | grep 'srt ingest drained' | tail -1 \
        | sed -n "s/.* $2=\([0-9]*\).*/\1/p"
}

ingest_totals() {   # sums the last drained line of every worker
    local p b c d s any=0

    BYTES=0; CHUNKS=0; DROPPED=0; SESSIONS=0

    for p in $(worker_pids); do
        b="$(drained_last "$p" bytes)"
        [ -n "$b" ] || continue

        any=1
        c="$(drained_last "$p" chunks)"
        d="$(drained_last "$p" dropped_chunks)"
        s="$(drained_last "$p" sessions)"

        BYTES=$(( BYTES + b )); CHUNKS=$(( CHUNKS + c ))
        DROPPED=$(( DROPPED + d )); SESSIONS=$(( SESSIONS + s ))
    done

    [ "$any" = 1 ]
}

row() {   # <workers> <publishers> <delivered> <chunks/s> <MiB/s>
    printf '%-8s %-6s %-11s %-11s %-9s %s\n' "$1" "$2" "$3" "$4" "$5" \
        "$(cpu_total "$W_BEFORE" "$W_AFTER" "$W_DUR")"
}

detail_rows() {   # <publishers>
    detail_cpu "$W_BEFORE" "$W_AFTER" "$W_DUR" \
        | awk -v p="$1" '{ printf "   %-4s %-10s %-6s %s%%\n", p, $2, $1, $3 }'
}

mibps() {   # <bytes> ; bytes/s over the window, in MiB
    awk -v b="$1" -v w="$W_DUR" 'BEGIN { printf "%.1f", b / 1048576 / w }'
}

# --- phases -----------------------------------------------------------------

phase_floor() {
    local w

    echo
    echo "== floor: what a worker burns with no publisher and no destination"
    echo
    printf '%-8s %-10s %s\n' workers 'idle CPU' 'per-thread'

    for w in $LO_WORKERS; do

        start_instance "$w" no no
        cpu_window "$FLOOR_WINDOW"

        printf '%-8s %-10s %s\n' "$w" \
            "$(cpu_total "$W_BEFORE" "$W_AFTER" "$W_DUR")" \
            "$(report_cpu "$W_BEFORE" "$W_AFTER" "$W_DUR" \
               | awk '$2 == "srt-send" { printf "%s=%d%% ", $1, $3 }')"
    done

    echo "   (no media has been published at this point in the run)"
    return 0
}

phase_ingest_high() {
    local rate i delivered b0 c0 d0 db dc dd late noroom

    echo
    echo "== ingest: $HI_PUBS publishers on one endpoint, one worker, with the"
    echo "   offered rate raised ($HI_RATES per publisher, -muxrate)"
    echo "   $HI_PUBS is the per-worker session ceiling, so the only thing that"
    echo "   rises here is the packet rate one port has to carry"
    echo
    printf '%-8s %-10s %-11s %-9s %-8s %s\n' rate chunks/s MiB/s dropped \
        seqno-late 'CPU per worker (total)'

    make_source "$RUN/media/hi.ts" "$LO_BITRATE"

    for rate in $HI_RATES; do

        start_instance 1 no no

        PUBS=()
        for i in $(seq 1 "$HI_PUBS"); do
            publish "${SRT_PORTS[0]}" "hi$i" "$RUN/media/hi.ts" "$rate"
            PUBS+=( $! )
        done

        sleep "$WINDOW"

        delivered=0
        for i in $(seq 1 "$HI_PUBS"); do
            [ -n "$(field_any "hi$i" program_frames 6)" ] \
                && delivered=$(( delivered + 1 ))
        done

        # the drained counters are sampled around the window only: reading
        # them across the delivered loop above would divide a longer interval
        # by the window and report a rate nobody carried
        ingest_totals; b0=$BYTES; c0=$CHUNKS; d0=$DROPPED
        cpu_window "$WINDOW"
        ingest_totals || true

        db=$(( BYTES - b0 )); dc=$(( CHUNKS - c0 )); dd=$(( DROPPED - d0 ))

        # the library's own two drop sites, which are not module counters
        late="$(grep -c 'RCV-DROPPED' "$RUN/logs/error.log" 2>/dev/null)"
        noroom="$(grep -c 'No room to store incoming packet' \
                  "$RUN/logs/error.log" 2>/dev/null)"
        late="${late:-0}"
        noroom="${noroom:-0}"

        printf '%-8s %-10s %-11s %-9s %-8s %s\n' "$rate" \
            "$(awk -v c="$dc" -v w="$W_DUR" 'BEGIN { printf "%d", c / w }')" \
            "$(mibps "$db")" "$dd" "$(( late + noroom ))" \
            "$(cpu_total "$W_BEFORE" "$W_AFTER" "$W_DUR")"

        printf '   %-4s sessions %s  fanout-delay drops %s  receive-buffer drops %s\n' \
            "$rate" "$delivered/$HI_PUBS" "$late" "$noroom"

        detail_rows "$rate"

        kill_pubs
        sleep 1
    done

    return 0
}

phase_ingest_publishers() {
    local k i delivered b0 c0 d0 db dc dd

    echo
    echo "== ingest: publishers grown on one endpoint at ~$LO_BITRATE each"
    echo
    printf '%-8s %-6s %-11s %-11s %-9s %s\n' workers publ. delivered \
        chunks/s MiB/s 'CPU per worker (total)'

    for k in $PUB_STEPS; do

        start_instance 1 no no

        PUBS=()
        for i in $(seq 1 "$k"); do
            publish "${SRT_PORTS[0]}" "pu$i" "$RUN/media/lo.ts"
            PUBS+=( $! )
        done

        sleep "$WINDOW"

        delivered=0
        for i in $(seq 1 "$k"); do
            [ -n "$(field_any "pu$i" program_frames 6)" ] \
                && delivered=$(( delivered + 1 ))
        done

        ingest_totals; b0=$BYTES; c0=$CHUNKS; d0=$DROPPED
        cpu_window "$WINDOW"
        ingest_totals || true

        db=$(( BYTES - b0 )); dc=$(( CHUNKS - c0 )); dd=$(( DROPPED - d0 ))

        row 1 "$k" "$delivered/$k" \
            "$(awk -v c="$dc" -v w="$W_DUR" 'BEGIN { printf "%d", c / w }')" \
            "$(mibps "$db")"
        detail_rows "$k"

        [ "$dd" -gt 0 ] && echo "   dropped chunks in the window: $dd"

        kill_pubs
        sleep 1
    done

    return 0
}

phase_ingest_endpoints() {
    local w n i delivered b0 c0 db dc

    echo
    echo "== ingest: the same publishers per endpoint, across worker counts"
    echo "   ~$LO_BITRATE publishers, $LO_PER_PORT per endpoint, spread"
    echo "   round-robin over the endpoints the instance binds"
    echo
    printf '%-8s %-6s %-11s %-11s %-9s %s\n' workers publ. delivered \
        chunks/s MiB/s 'CPU per worker (total)'

    for w in $LO_WORKERS; do
        n=$(( w * LO_PER_PORT ))

        start_instance "$w" no no

        echo "   endpoints:$PLACEMENT"

        PUBS=()
        for i in $(seq 1 "$n"); do
            publish "${SRT_PORTS[$(( (i - 1) % w ))]}" "lo$i" "$RUN/media/lo.ts"
            PUBS+=( $! )
        done

        sleep "$WINDOW"

        delivered=0
        for i in $(seq 1 "$n"); do
            [ -n "$(field_any "lo$i" program_frames 6)" ] \
                && delivered=$(( delivered + 1 ))
        done

        ingest_totals; b0=$BYTES; c0=$CHUNKS
        cpu_window "$WINDOW"
        ingest_totals || true

        db=$(( BYTES - b0 )); dc=$(( CHUNKS - c0 ))

        row "$w" "$n" "$delivered/$n" \
            "$(awk -v c="$dc" -v w="$W_DUR" 'BEGIN { printf "%d", c / w }')" \
            "$(mibps "$db")"
        detail_rows "$n"

        kill_pubs
        sleep 1
    done

    return 0
}

phase_ingest_one_port() {
    local w n i delivered b0 c0 db dc

    echo
    echo "== ingest: $LO_PER_PORT publishers on one endpoint, from a single"
    echo "   worker and from an instance with four workers bound (three idle)"
    echo
    printf '%-8s %-6s %-11s %-11s %-9s %s\n' workers publ. delivered \
        chunks/s MiB/s 'CPU per worker (total)'

    for w in 1 4; do
        n="$LO_PER_PORT"

        start_instance "$w" no no

        PUBS=()
        for i in $(seq 1 "$n"); do
            publish "${SRT_PORTS[0]}" "op$i" "$RUN/media/lo.ts"
            PUBS+=( $! )
        done

        sleep "$WINDOW"

        delivered=0
        for i in $(seq 1 "$n"); do
            [ -n "$(field_any "op$i" program_frames 6)" ] \
                && delivered=$(( delivered + 1 ))
        done

        ingest_totals; b0=$BYTES; c0=$CHUNKS
        cpu_window "$WINDOW"
        ingest_totals || true

        db=$(( BYTES - b0 )); dc=$(( CHUNKS - c0 ))

        row "$w" "$n" "$delivered/$n" \
            "$(awk -v c="$dc" -v w="$W_DUR" 'BEGIN { printf "%d", c / w }')" \
            "$(mibps "$db")"
        detail_rows "$n"

        kill_pubs
        sleep 1
    done

    return 0
}

# --- egress -----------------------------------------------------------------

segments_closed() {   # the playlist's closed segments, 0 when there is none
    local n

    n="$(grep -c '^#EXTINF' "$RUN/hls/live/eg/index.m3u8" 2>/dev/null)"
    printf '%s' "${n:-0}"
}

hls_storm() {
    local list="$RUN/urls.txt" name
    while :; do
        : > "$list"

        for name in $(grep -v '^#' "$RUN/hls/live/eg/index.m3u8" 2>/dev/null \
                      | grep '\.ts$' || true); do
            printf 'url = "http://127.0.0.1:%s/hls/live/eg/%s"\noutput = "/dev/null"\n' \
                "$HTTP_PORT" "$name" >> "$list"
        done

        [ -s "$list" ] || { sleep 0.2; continue; }

        curl -fsS --parallel --parallel-max "$HLS_READERS" \
            --config "$list" >/dev/null 2>&1 || true

        sleep 0.02
    done
}

phase_egress_hls() {
    local w i served mib rps pub

    echo
    echo "== egress: $HLS_READERS concurrent HLS readers against one program"
    echo "   the segmenter runs on the owner; each reader is served by"
    echo "   whichever worker the kernel hashed it to"
    echo
    printf '%-8s %-12s %-11s %-9s %s\n' workers requests/s MiB/s \
        segments 'CPU per worker (total)'

    for w in $EGRESS_WORKERS; do

        start_instance "$w" yes no
        : > "$RUN/logs/access.log"

        publish "${SRT_PORTS[0]}" "eg" "$RUN/media/lo.ts"
        pub=$!

        for i in $(seq 1 400); do
            [ "$(segments_closed)" -ge 3 ] && break
            sleep 0.1
        done

        sleep 4

        hls_storm &
        STORM=$!

        cpu_window "$HLS_SECONDS"

        kill -KILL "$STORM" 2>/dev/null
        STORM=0
        sleep 0.5

        served="$(wc -l < "$RUN/logs/access.log" 2>/dev/null || echo 0)"
        mib="$(awk -v s="$W_DUR" \
               '{ b += $2 } END { printf "%.1f", b / 1048576 / s }' \
               "$RUN/logs/access.log" 2>/dev/null || echo 0)"
        rps="$(awk -v n="$served" -v s="$W_DUR" 'BEGIN { printf "%d", n / s }')"

        printf '%-8s %-12s %-11s %-9s %s\n' "$w" "$rps" "$mib" \
            "$(segments_closed)" \
            "$(cpu_total "$W_BEFORE" "$W_AFTER" "$W_DUR")"

        echo "   requests per worker (the access log's \$pid):"
        awk '{ c[$1]++ } END { for (p in c) print p, c[p] }' \
            "$RUN/logs/access.log" 2>/dev/null \
            | while read -r p n; do
                  printf '     %-6s %s requests\n' "$(slot_name "$p")" "$n"
              done

        detail_rows hls

        kill_one "$pub"
        sleep 1
    done

    return 0
}

phase_egress_live() {
    local w d port pub started owner dests f0 f1

    echo
    echo "== egress: $SRT_DESTS live SRT destinations on one program"
    echo "   each is pushed to an ffmpeg receiver of its own, prepared and fed"
    echo "   by the owner worker in process"
    echo
    printf '%-8s %-13s %-11s %s\n' workers started frames/s \
        'CPU per worker (total)'

    make_source "$RUN/media/lv.ts" "$LIVE_BITRATE"

    for w in $EGRESS_WORKERS; do

        start_instance "$w" no yes

        publish "${SRT_PORTS[0]}" "lv" "$RUN/media/lv.ts" "$LIVE_RATE"
        pub=$!

        for d in $(seq 1 200); do
            [ -n "$(field_any lv program_frames 8)" ] && break
            sleep 0.1
        done

        owner="$(owner_of lv)"

        # the receivers have to be listening before the destinations connect
        SINKS=()
        for d in $(seq 1 "$SRT_DESTS"); do
            port=$(( BASE + 20 + d ))
            ffmpeg -hide_banner -loglevel error \
                -i "srt://127.0.0.1:$port?mode=listener" -c copy -f null - \
                >"$RUN/sink-$d.log" 2>&1 &
            SINKS+=( $! )
        done

        sleep 2

        for d in $(seq 1 "$SRT_DESTS"); do
            post_owner "/streams/live/lv/destinations" \
                "{\"id\":\"sink$d\",\"type\":\"srt\",\"host\":\"127.0.0.1\",\"port\":$(( BASE + 20 + d )),\"streamid\":\"#!::r=live/lv,m=publish,s=sink$d\"}" \
                || true
        done

        sleep 5

        dests="$(grep -cE 'media: srt destination sink[0-9]+ started' \
                  "$RUN/logs/error.log" 2>/dev/null || true)"
        dests="${dests:-0}"
        f0="$(field_any lv program_frames 8)"; f0="${f0:-0}"

        cpu_window "$LIVE_SECONDS"

        f1="$(field_any lv program_frames 8)"; f1="${f1:-0}"

        printf '%-8s %-13s %-11s %s\n' "$w" "$dests/$SRT_DESTS" \
            "$(awk -v f="$(( f1 - f0 ))" -v s="$W_DUR" \
               'BEGIN { printf "%.1f", f / s }')" \
            "$(cpu_total "$W_BEFORE" "$W_AFTER" "$W_DUR")"

        echo "   owner reported: ${owner:-?}; destinations started: $dests"

        detail_rows live

        for d in ${SINKS[@]+"${SINKS[@]}"}; do kill_one "$d"; done
        SINKS=()
        kill_one "$pub"
        sleep 1
    done

    return 0
}

# --- placed versus routed ---------------------------------------------------

phase_misplace() {
    local w="$MP_WORKERS" i n="$MP_PUBS"
    local placed routed placed_owner routed_owner routed_log placed_routed
    local f0 f1 frames units backlog p50 p99 span t0 t1

    echo
    echo "== placement: $n publishers on their owner's endpoint, and the same"
    echo "   $n on another worker's endpoint, where every one is routed"
    echo

    make_source "$RUN/media/mp.ts" "$MP_BITRATE"

    mapfile -t PLACED < <(owner_names 0 "$w" "$n" p)
    mapfile -t ROUTED < <(owner_names 0 "$w" "$n" r)

    for i in "${!PLACED[@]}"; do
        [ -n "${PLACED[$i]}" ] && [ -n "${ROUTED[$i]}" ] \
            || { echo "could not name $n streams with owner 0" >&2; exit 1; }
    done

    for case in placed routed; do

        # HLS is on so the program has a consumer: the fanout delay histogram
        # only records a dispatch when something takes a unit out of the feed.
        # The segmenter runs on the owner in both cases, so it is common to
        # both and cancels in the comparison.
        start_instance "$w" yes no

        echo "   endpoints:$PLACEMENT"

        PUBS=()
        if [ "$case" = placed ]; then
            # accepted by the owner that drives the program: no transport
            for i in "${!PLACED[@]}"; do
                publish "${SRT_PORTS[0]}" "${PLACED[$i]}" "$RUN/media/mp.ts" \
                    "$MP_RATE"
                PUBS+=( $! )
            done
        else
            # accepted by worker 1 and routed to the owner on worker 0
            for i in "${!ROUTED[@]}"; do
                publish "${SRT_PORTS[1]}" "${ROUTED[$i]}" "$RUN/media/mp.ts" \
                    "$MP_RATE"
                PUBS+=( $! )
            done
        fi

        sleep 6

        # Everything is sampled between t0 and t1, and the rates are divided
        # by that interval rather than by the sleep: reading 12 programs'
        # counters takes long enough to matter, and it is the interval the
        # deltas actually cover.
        t0="$(date +%s.%N)"
        ingest_totals; local b0=$BYTES c0=$CHUNKS d0=$DROPPED

        f0=0
        for i in "${!PLACED[@]}"; do
            local v
            if [ "$case" = placed ]; then
                v="$(field_any "${PLACED[$i]}" program_frames 8)"
            else
                v="$(field_any "${ROUTED[$i]}" program_frames 8)"
            fi
            f0=$(( f0 + ${v:-0} ))
        done

        cpu_window "$WINDOW"

        f1=0
        for i in "${!PLACED[@]}"; do
            local v
            if [ "$case" = placed ]; then
                v="$(field_any "${PLACED[$i]}" program_frames 8)"
            else
                v="$(field_any "${ROUTED[$i]}" program_frames 8)"
            fi
            f1=$(( f1 + ${v:-0} ))
        done

        ingest_totals || true
        t1="$(date +%s.%N)"
        span="$(awk -v a="$t0" -v b="$t1" 'BEGIN { printf "%.2f", b - a }')"
        frames=$(( f1 - f0 ))

        # the owner's queue and its own dispatch delay, for the first program
        if [ "$case" = placed ]; then
            p50="$(owner_percentile "${PLACED[0]}" 50)"
            p99="$(owner_percentile "${PLACED[0]}" 99)"
        else
            p50="$(owner_percentile "${ROUTED[0]}" 50)"
            p99="$(owner_percentile "${ROUTED[0]}" 99)"
        fi

        backlog=0
        for i in "${!PLACED[@]}"; do
            local u
            if [ "$case" = placed ]; then
                u="$(owner_metric "${PLACED[$i]}" nginx_media_stream_feed_units)"
            else
                u="$(owner_metric "${ROUTED[$i]}" nginx_media_stream_feed_units)"
            fi
            backlog=$(( backlog + ${u:-0} ))
        done

        printf '   %-7s programs %s  frames/s %s  owner backlog %s units\n' \
            "$case" "$n" \
            "$(awk -v f="$frames" -v s="$span" 'BEGIN { printf "%.1f", f / s }')" \
            "$backlog"
        printf '   %-7s drained %s chunks/s  %s MiB/s  dropped %s  fanout p50 %sms p99 %sms\n' \
            "$case" \
            "$(awk -v c="$(( CHUNKS - c0 ))" -v s="$span" 'BEGIN { printf "%d", c / s }')" \
            "$(awk -v b="$(( BYTES - b0 ))" -v s="$span" 'BEGIN { printf "%.1f", b / 1048576 / s }')" \
            "$(( DROPPED - d0 ))" "${p50:-?}" "${p99:-?}"

        detail_rows "$case"

        if [ "$case" = placed ]; then
            placed_owner="$(owner_of "${PLACED[0]}")"
            placed_routed="$(grep -c 'srt publisher routed to the owner stream=live/p' \
                             "$RUN/logs/error.log" 2>/dev/null || true)"
        else
            routed_owner="$(owner_of "${ROUTED[0]}")"
            routed_log="$(grep -c 'srt publisher routed to the owner stream=live/r' \
                          "$RUN/logs/error.log" 2>/dev/null || true)"
        fi

        kill_pubs
        sleep 1
    done

    echo
    echo "   owner from the graph: placed=$placed_owner routed=$routed_owner"
    echo "   routed sessions logged: ${routed_log:-0} of $n in the routed case," \
         "${placed_routed:-0} of $n in the placed case"
    echo "   placed: endpoint ${SRT_PORTS[0]} is worker 0's, so every publisher"
    echo "           is accepted by the worker that owns its program"
    echo "   routed: endpoint ${SRT_PORTS[1]} is worker 1's, so every frame"
    echo "           crosses the SOCK_SEQPACKET transport to worker 0"

    return 0
}

# --- deterministic topology matrix ------------------------------------------
#
# This phase removes ownership luck from the worker-scaling question.  One
# stream is deliberately named for each owner slot, then the same balanced
# programs are run with all publishers local, all routed, alternating local
# and routed, and one-program local/routed controls.  Each row reports the
# source input, program/feed output, feed pressure, preroll causes and route
# failures from the program owner's own metrics response.

phase_topology() {
    local w="${TOPOLOGY_WORKERS:-4}"
    local window="${TOPOLOGY_WINDOW:-8}"
    local i case_idx name owner endpoint landing path metrics
    local input program feed_units feed_bytes feed_high_units feed_high_bytes
    local evictions overruns
    local preroll_overflows unit_overflows byte_overflows route_identity
    local route_slots route_no_slot route_no_payload route_reassembly
    local route_publish route_fail
    local -a names case_names case_endpoints found

    [ "$w" -ge 2 ] || {
        echo "topology needs at least two workers" >&2
        return 1
    }

    mapfile -t names < <(owner_names 0 "$w" 1 topology-w)
    for i in $(seq 1 $(( w - 1 ))); do
        mapfile -t found < <(owner_names "$i" "$w" 1 topology-w)
        names[$i]="${found[0]:-}"
    done

    for i in $(seq 0 $(( w - 1 ))); do
        [ -n "${names[$i]:-}" ] \
            || { echo "could not select a stream for owner $i" >&2; return 1; }
    done

    echo
    echo "== deterministic worker topology matrix"
    echo "   workers: $w, source: pre-encoded mpegts, window: ${window}s"
    echo "   names are selected by the 64-bit FNV-1a owner hash"
    for i in $(seq 0 $(( w - 1 ))); do
        echo "   owner w$i: ${names[$i]}"
    done

    for case_idx in all-local all-routed alternating one-local one-routed; do
        start_instance "$w" yes no
        case_names=()
        case_endpoints=()

        case "$case_idx" in
            all-local)
                for i in $(seq 0 $(( w - 1 ))); do
                    case_names+=("${names[$i]}")
                    case_endpoints+=("$i")
                done
                ;;
            all-routed)
                for i in $(seq 0 $(( w - 1 ))); do
                    case_names+=("${names[$i]}")
                    case_endpoints+=("$(( (i + 1) % w ))")
                done
                ;;
            alternating)
                for i in $(seq 0 $(( w - 1 ))); do
                    case_names+=("${names[$i]}")
                    if [ $(( i % 2 )) -eq 0 ]; then
                        case_endpoints+=("$i")
                    else
                        case_endpoints+=("$(( (i + 1) % w ))")
                    fi
                done
                ;;
            one-local)
                case_names=("${names[0]}")
                case_endpoints=(0)
                ;;
            one-routed)
                case_names=("${names[0]}")
                case_endpoints=(1)
                ;;
        esac

        echo
        echo "== topology case: $case_idx"
        PUBS=()
        for i in "${!case_names[@]}"; do
            publish "${SRT_PORTS[${case_endpoints[$i]}]}" \
                "${case_names[$i]}" "$RUN/media/lo.ts"
            PUBS+=( $! )
        done

        for name in "${case_names[@]}"; do
            field_any "$name" program_frames 80 >/dev/null 2>&1 || true
        done
        sleep "$window"

        printf '   %-16s %s\n' case "$case_idx"
        for i in "${!case_names[@]}"; do
            name="${case_names[$i]}"
            endpoint="${case_endpoints[$i]}"
            metrics="$(owner_metrics "$name" 2>/dev/null || true)"
            owner="$(owner_of "$name" 2>/dev/null || printf '?')"
            landing="$(endpoint_worker "${SRT_PORTS[$endpoint]}")"

            if [ "$owner" = "$endpoint" ]; then
                path=local
            else
                path=routed
            fi

            input="$(blob_source_metric "$metrics" \
                nginx_media_source_frames_in "$name")"
            program="$(blob_label_metric "$metrics" \
                nginx_media_stream_program_frames "$name")"
            feed_units="$(blob_label_metric "$metrics" \
                nginx_media_stream_feed_units "$name")"
            feed_bytes="$(blob_label_metric "$metrics" \
                nginx_media_stream_feed_bytes "$name")"
            feed_high_units="$(blob_label_metric "$metrics" \
                nginx_media_stream_feed_high_water_units "$name")"
            feed_high_bytes="$(blob_label_metric "$metrics" \
                nginx_media_stream_feed_high_water_bytes "$name")"
            evictions="$(blob_label_metric "$metrics" \
                nginx_media_stream_feed_evictions_total "$name")"
            overruns="$(blob_label_metric "$metrics" \
                nginx_media_stream_feed_overruns_total "$name")"
            generation_mismatches="$(blob_label_metric "$metrics" \
                nginx_media_stream_feed_generation_mismatches_total "$name")"
            publish_errors="$(blob_label_metric "$metrics" \
                nginx_media_stream_feed_publish_errors_total "$name")"
            preroll_units="$(blob_source_metric "$metrics" \
                nginx_media_source_preroll_high_water_units "$name")"
            preroll_bytes="$(blob_source_metric "$metrics" \
                nginx_media_source_preroll_high_water_bytes "$name")"
            preroll_overflows="$(blob_source_metric "$metrics" \
                nginx_media_source_preroll_overflows_total "$name")"
            unit_overflows="$(blob_source_metric "$metrics" \
                nginx_media_source_preroll_unit_overflows_total "$name")"
            byte_overflows="$(blob_source_metric "$metrics" \
                nginx_media_source_preroll_byte_overflows_total "$name")"
            route_identity="$(blob_global_metric "$metrics" \
                nginx_media_runtime_routed_identity_mismatches_total)"
            route_slots="$(blob_global_metric "$metrics" \
                nginx_media_runtime_routed_slot_overflows_total)"
            route_no_slot="$(blob_global_metric "$metrics" \
                nginx_media_runtime_routed_no_slot_total)"
            route_no_payload="$(blob_global_metric "$metrics" \
                nginx_media_runtime_routed_no_payload_total)"
            route_reassembly="$(blob_global_metric "$metrics" \
                nginx_media_runtime_routed_reassembly_errors_total)"
            route_publish="$(blob_global_metric "$metrics" \
                nginx_media_runtime_routed_publish_errors_total)"

            input="${input:-0}"
            program="${program:-0}"
            route_identity="${route_identity:-0}"
            route_slots="${route_slots:-0}"
            route_no_slot="${route_no_slot:-0}"
            route_no_payload="${route_no_payload:-0}"
            route_reassembly="${route_reassembly:-0}"
            route_publish="${route_publish:-0}"
            route_fail=$(( route_identity + route_slots + route_no_slot
                         + route_no_payload + route_reassembly + route_publish ))

            echo "   $name owner=$owner landing=$landing path=$path" \
                 "input_frames=$input program_frames=$program" \
                 "feed_retained=${feed_units:-0}u/${feed_bytes:-0}B" \
                 "feed_high_water=${feed_high_units:-0}u/${feed_high_bytes:-0}B" \
                 "feed_evictions=${evictions:-0}" \
                 "feed_overruns=${overruns:-0}" \
                 "feed_generation_mismatches=${generation_mismatches:-0}" \
                 "feed_publish_errors=${publish_errors:-0}" \
                 "preroll_high_water=${preroll_units:-0}u/${preroll_bytes:-0}B" \
                 "preroll_overflows=${preroll_overflows:-0}" \
                 "preroll_unit_overflows=${unit_overflows:-0}" \
                 "preroll_byte_overflows=${byte_overflows:-0}" \
                 "route_failures=$route_fail" \
                 "route_identity=$route_identity" \
                 "route_slots=$route_slots" \
                 "route_no_slot=$route_no_slot" \
                 "route_no_payload=$route_no_payload" \
                 "route_reassembly=$route_reassembly" \
                 "route_publish=$route_publish"
        done

        kill_pubs
        sleep 1
    done

    return 0
}

capacity_json_field() {   # <stream snapshot> <dot-separated field>
    python3 - "$1" "$2" <<'PY'
import json
import sys

with open(sys.argv[1], encoding="utf-8") as source:
    value = json.loads(source.read().split("# HELP", 1)[0])
for field in sys.argv[2].split("."):
    value = value[field]
if isinstance(value, list):
    print(" ".join("60000" if item is None else str(item) for item in value))
else:
    print(value)
PY
}

capacity_metric() {   # <metrics snapshot> <metric>
    awk -v metric="$2" '$1 == metric { print $2; exit }' "$1"
}

capacity_rtmp_receiver_ready() {   # <metrics file> <programs> <destinations> [offset]
    python3 - "$1" "$2" "$3" "${4:-0}" <<'PY'
import re
import sys

programs = int(sys.argv[2])
per_program = int(sys.argv[3])
offset = int(sys.argv[4])
expected = {
    (f"d{destination:04d}" if programs == 1
     else f"p{program:04d}-d{destination:04d}")
    for program in range(programs)
    for destination in range(offset, offset + per_program)
}
received = {}
with open(sys.argv[1], encoding="utf-8") as source:
    for line in source:
        match = re.match(
            r"^nginx_media_source_payload_bytes_in_total\{(.*?)\}\s+([0-9]+)\s*$",
            line,
        )
        if match is None:
            continue
        labels = dict(re.findall(
            r'([a-zA-Z_][a-zA-Z0-9_]*)="((?:\\.|[^"])*)"',
            match.group(1),
        ))
        name = labels.get("name")
        if (labels.get("application") == "live"
                and name in expected and labels.get("source") == name):
            received[name] = int(match.group(2))
raise SystemExit(
    0 if received.keys() >= expected and all(received[name] > 0 for name in expected)
    else 1
)
PY
}

capacity_rtmp_payload_report() {   # <before prefix> <after prefix> <programs> <destinations> [offset]
    python3 - "$1" "$2" "$3" "$4" "${5:-0}" <<'PY'
import glob
import re
import sys

programs = int(sys.argv[3])
per_program = int(sys.argv[4])
offset = int(sys.argv[5])
expected = {
    (f"d{destination:04d}" if programs == 1
     else f"p{program:04d}-d{destination:04d}")
    for program in range(programs)
    for destination in range(offset, offset + per_program)
}

def read(prefix):
    values = {}
    for path in glob.glob(prefix + ".*"):
        with open(path, encoding="utf-8") as source:
            for line in source:
                match = re.match(
                    r"^nginx_media_source_payload_bytes_in_total\{(.*?)\}\s+([0-9]+)\s*$",
                    line,
                )
                if match is None:
                    continue
                labels = dict(re.findall(
                    r'([a-zA-Z_][a-zA-Z0-9_]*)="((?:\\.|[^"])*)"',
                    match.group(1),
                ))
                name = labels.get("name")
                if (labels.get("application") == "live"
                        and name in expected and labels.get("source") == name):
                    values[name] = values.get(name, 0) + int(match.group(2))
    return values

before = read(sys.argv[1])
after = read(sys.argv[2])
for label, values in (("before", before), ("after", after)):
    missing = sorted(expected - values.keys())
    if missing:
        raise SystemExit(
            f"RTMP {label} metrics missing destination streams: {missing[:4]}"
        )
deltas = {name: after[name] - before[name] for name in expected}
undelivered = sorted(name for name, value in deltas.items() if value <= 0)
if undelivered:
    raise SystemExit(
        f"RTMP destinations received no measured payload: {undelivered[:4]}"
    )
print(f"receiver_delivered_rtmp_payload_bytes={sum(deltas.values())}")
print(f"rtmp_receiver_count={len(deltas)}")
for name in sorted(deltas):
    print(f"destination_{name} receiver_delivered_rtmp_payload_bytes={deltas[name]}")
PY
}


# The smallest rung a mix can form: one destination for a pure workload or a
# mix whose SRT share rounds to nothing at one, more when every protocol needs
# a destination of its own.  The rounding is the ladder's own.
capacity_mix_minimum_rung() {   # <protocol> <srt share> <hls push share>
    local protocol="$1" srt_share="${2:-0}" hls_push_share="${3:-0}"
    local n srt_count primary hls_push_count

    for (( n = 1; n <= 1000; n++ )); do
        if [ "$protocol" = srt ]; then
            srt_count="$n"
        else
            srt_count=$(( (n * srt_share + 50) / 100 ))
        fi
        primary=$(( n - srt_count ))
        [ "$primary" -ge 1 ] || continue
        case "$protocol" in
            rtmp|hls|hls-push) printf '%d' "$n"; return 0 ;;
            rtmp-hls-push)
                # The first rung that carries RTMP destinations must carry
                # exactly one: the RTMP analyzer calibrates its reference from
                # a single destination and refuses to guess from many, so a
                # ladder that starts with several RTMP destinations and no
                # reference fails as a setup error.
                hls_push_count=$(( (n * hls_push_share + 50) / 100 ))
                [ "$(( primary - hls_push_count ))" -ge 1 ] \
                    && { printf '%d' "$n"; return 0; }
                ;;
        esac
    done
    printf '1'
}

capacity_destination_id() {   # <program index> <destination index> <program count>
    if [ "$3" -eq 1 ]; then
        printf 'd%04d' "$2"
    else
        printf 'p%04d-d%04d' "$1" "$2"
    fi
}

capacity_percentile() {   # <metrics snapshot> <stream> <percentile>
    awk -v name="$2" -v percentile="$3" '
        index($1, "nginx_media_stream_fanout_delay_ms{") == 1 &&
        index($1, "name=\"" name "\"") > 0 &&
        index($1, "percentile=\"" percentile "\"") > 0 { print $2; exit }
    ' "$1"
}

capacity_worker_pid() {
    sed -n \
        's/^nginx_media_worker_info{worker="[^"]*",pid="\([0-9][0-9]*\)"} 1$/\1/p'
}

capacity_worker_metrics() {   # <file prefix>; one response from every worker
    local prefix="$1" required valid blob pid attempt
    local -A seen=()

    required="$(worker_pids | awk 'NF { n++ } END { print n + 0 }')"
    valid=" $(worker_pids | tr '\n' ' ') "

    for attempt in $(seq 1 "$(( required * 50 ))"); do
        blob="$(curl -fsS "$(api)/metrics" 2>/dev/null || true)"
        pid="$(printf '%s\n' "$blob" | capacity_worker_pid | head -1)"

        case "$valid" in
            *" $pid "*)
                if [ -z "${seen[$pid]:-}" ]; then
                    printf '%s\n' "$blob" > "$prefix.$pid"
                    seen[$pid]=1
                fi
                ;;
        esac

        [ "${#seen[@]}" -ge "$required" ] && break
    done

    if [ "${#seen[@]}" -ne "$required" ]; then
        echo "   only scraped ${#seen[@]} of $required worker metrics" >&2
        return 1
    fi
}

capacity_rtmp_sink_metrics() {   # <file prefix>
    local prefix="$1"

    local k pid status=0
    local -a requests=()

    [ -n "$RTMP_SINK_WORKER_PID" ] || return 0
    # stamped with the monotonic clock around each request, so the rate
    # divides by the interval that brackets these counters; one file per
    # sink, summed by the analyzer
    for (( k = 0; k < RTMP_SINK_COUNT; k++ )); do
        python3 "$ROOT/tests/bench/rtmp_capacity_quality.py" scrape \
            "$(rtmp_sink_api "$k")/metrics" \
            "$prefix.${RTMP_SINK_PIDS[$k]}" &
        requests+=( "$!" )
    done
    for pid in "${requests[@]}"; do
        wait "$pid" || status=1
    done
    [ "$status" -eq 0 ] || echo "could not scrape every RTMP sink" >&2
    return "$status"
}

capacity_socket_snapshot() {   # <file prefix>
    local prefix="$1" pids

    pids="$(worker_pids | tr '\n' ' ')"
    ss -t -n -a -m -p > "$prefix.tcp" || return 1
    ss -u -n -a -m -p > "$prefix.udp" || return 1
    cp /proc/net/sockstat "$prefix.sockstat" || return 1

    python3 - "$prefix" "$pids" > "$prefix" <<'PY'
import re
import sys

prefix = sys.argv[1]
pids = [pid for pid in sys.argv[2].split() if pid]
stats = {
    pid: {"tcp_sockets": 0, "tcp_bytes": 0,
          "udp_sockets": 0, "udp_bytes": 0}
    for pid in pids
}

for proto in ("tcp", "udp"):
    with open(f"{prefix}.{proto}", encoding="utf-8") as source:
        lines = source.readlines()

    for index, line in enumerate(lines):
        match = re.search(r"skmem:\(([^)]*)\)", line)
        if match is None:
            continue

        chunk = "".join(lines[max(0, index - 2):index + 1])
        owners = set(re.findall(r"pid=(\d+)", chunk)).intersection(stats)
        if not owners:
            continue

        fields = dict((key, int(value))
                      for key, value in re.findall(
                          r"([a-z]+)(\d+)", match.group(1)))
        memory = sum(fields.get(key, 0)
                     for key in ("r", "t", "f", "w", "o", "bl"))
        for pid in owners:
            stats[pid][f"{proto}_sockets"] += 1
            stats[pid][f"{proto}_bytes"] += memory

for pid in sorted(stats, key=int):
    row = stats[pid]
    sockets = row["tcp_sockets"] + row["udp_sockets"]
    memory = row["tcp_bytes"] + row["udp_bytes"]
    print(pid, row["tcp_sockets"], row["tcp_bytes"],
          row["udp_sockets"], row["udp_bytes"], sockets, memory,
          sep="\t")
PY
}

capacity_sockstat_value() {   # <snapshot> <protocol:> <field>
    awk -v proto="$2" -v field="$3" '
        $1 == proto {
            for (i = 2; i < NF; i += 2) {
                if ($i == field) {
                    print $(i + 1)
                    exit
                }
            }
        }
    ' "$1"
}

capacity_rate_bps() {
    python3 - "$1" <<'PY'
import re
import sys

match = re.fullmatch(r"(\d+(?:\.\d+)?)([kKmMgG]?)", sys.argv[1])
if match is None:
    raise SystemExit(f"invalid bitrate: {sys.argv[1]}")
scale = {"": 1, "k": 1_000, "m": 1_000_000, "g": 1_000_000_000}
bps = round(float(match.group(1)) * scale[match.group(2).lower()])
if bps <= 0 or bps > 60_000_000:
    raise SystemExit("bitrate must be positive and no higher than 60M")
print(bps)
PY
}
capacity_build_srt_sink() {
    local source="$ROOT/tests/bench/srt_fanout_sink.c"
    local binary="$RUN/srt_fanout_sink"
    local -a cflags=() libs=()

    [ -x "$binary" ] && [ "$binary" -nt "$source" ] && return 0
    command -v cc >/dev/null && command -v pkg-config >/dev/null \
        && pkg-config --exists srt \
        || { echo "cc, pkg-config, and libsrt are required for SRT capacity cases" \
                 >&2; return 1; }
    [ -f "$source" ] \
        || { echo "missing shared SRT receiver helper: $source" >&2; return 1; }
    read -r -a cflags <<< "$(pkg-config --cflags srt)"
    read -r -a libs <<< "$(pkg-config --libs srt)"
    cc -O2 -g -Wall -Wextra -Werror -std=c2x "${cflags[@]}" \
        "$source" -o "$binary" "${libs[@]}" \
        || { echo "could not build the shared SRT receiver helper" >&2; return 1; }
}

capacity_srt_csv_report() {   # <receiver CSV> <programs> <destinations> <stall ID> <before snapshot> <after snapshot>
    python3 - "$1" "$2" "$3" "${4:-}" "$5" "$6" <<'PY'
import csv
import math
import re
import sys

programs = int(sys.argv[2])
per_program = int(sys.argv[3])
expected = programs * per_program
expected_stall = sys.argv[4]
expected_ids = {
    (f"d{destination:04d}" if programs == 1
     else f"p{program:04d}-d{destination:04d}")
    for program in range(programs)
    for destination in range(per_program)
}

def snapshot(path):
    values = {}
    with open(path, newline="", encoding="utf-8") as source:
        reader = csv.DictReader(source)
        required = {"destination_id", "bytes_received"}
        if reader.fieldnames is None or not required.issubset(reader.fieldnames):
            raise SystemExit(f"SRT snapshot {path} does not match its schema")
        for row in reader:
            destination = row["destination_id"]
            try:
                received = int(row["bytes_received"])
            except (TypeError, ValueError):
                raise SystemExit(f"invalid snapshot byte count for {destination}")
            if received < 0 or destination in values:
                raise SystemExit(f"invalid or duplicate snapshot row for {destination}")
            values[destination] = received
    if set(values) != expected_ids:
        missing = sorted(expected_ids - set(values))
        unexpected = sorted(set(values) - expected_ids)
        raise SystemExit(
            f"SRT snapshot IDs mismatch; missing={missing[:4]} "
            f"unexpected={unexpected[:4]}"
        )
    return values

before = snapshot(sys.argv[5])
after = snapshot(sys.argv[6])
if any(after[name] < before[name] for name in expected_ids):
    raise SystemExit("SRT receiver byte counter decreased between snapshots")

rows = []
with open(sys.argv[1], newline="", encoding="utf-8") as source:
    reader = csv.DictReader(source)
    required = {"destination_id", "bytes_received", "first_ms", "stalled"}
    if reader.fieldnames is None or not required.issubset(reader.fieldnames):
        raise SystemExit("SRT receiver CSV does not match its documented schema")
    for row in reader:
        destination = row["destination_id"]
        try:
            total_received = int(row["bytes_received"])
        except (TypeError, ValueError):
            raise SystemExit(f"invalid receiver byte count for {destination}")
        if total_received < 0:
            raise SystemExit(f"negative receiver byte count for {destination}")
        try:
            first_ms = float(row["first_ms"]) if row["first_ms"] else 0.0
        except ValueError:
            raise SystemExit(f"invalid first_ms for {destination}")
        if not math.isfinite(first_ms):
            raise SystemExit(f"invalid first_ms for {destination}")
        stalled = row["stalled"].lower() in ("1", "true", "yes")
        match = re.search(r"(?:^|-)p([0-9]+)-d[0-9]+$", destination)
        program = int(match.group(1)) if match else 0
        rows.append((destination, after[destination] - before[destination],
                     total_received, first_ms, stalled, program))

if len(rows) != expected:
    raise SystemExit(
        f"SRT receiver CSV has {len(rows)} destinations; expected {expected}"
    )
destinations = [row[0] for row in rows]
if len(set(destinations)) != len(destinations):
    raise SystemExit("SRT receiver CSV contains duplicate destination IDs")
if set(destinations) != expected_ids:
    missing = sorted(expected_ids - set(destinations))
    unexpected = sorted(set(destinations) - expected_ids)
    raise SystemExit(
        f"SRT receiver IDs mismatch; missing={missing[:4]} "
        f"unexpected={unexpected[:4]}"
    )
undelivered = [row[0] for row in rows if not row[4] and row[1] == 0]
if undelivered:
    raise SystemExit(
        f"healthy SRT destinations received no payload in the measured window: "
        f"{undelivered[:4]}"
    )
if expected_stall:
    stalled_rows = [row for row in rows if row[0] == expected_stall]
    if len(stalled_rows) != 1 or not stalled_rows[0][4]:
        raise SystemExit(
            f"slow-reader destination {expected_stall} was not reported stalled"
        )
    if stalled_rows[0][1] != 0:
        raise SystemExit("the deliberately stalled SRT reader was consumed")
    if sum(1 for row in rows if row[4]) != 1:
        raise SystemExit("slow-reader case must report exactly one stalled destination")
    if not any(row[1] > 0 and not row[4] for row in rows):
        raise SystemExit("healthy SRT destinations received no payload in the measured window")

def jain(values):
    total = sum(values)
    squares = sum(value * value for value in values)
    return total * total / (len(values) * squares) if squares else 0.0

totals = {}
for _, received, _, _, _, program in rows:
    totals[program] = totals.get(program, 0) + received
stalled = [row for row in rows if row[4]]
healthy = [row for row in rows if not row[4]]
stalled_bytes = sum(row[1] for row in stalled)
healthy_bytes = sum(row[1] for row in healthy)
spread = max(row[3] for row in rows)
print(f"receiver_delivered_bytes={sum(row[1] for row in rows)}")
print(f"receiver_total_bytes={sum(row[2] for row in rows)}")
print(f"destination_fairness_jain={jain([row[1] for row in rows]):.4f}")
print(f"healthy_destination_fairness_jain={jain([row[1] for row in healthy]):.4f}")
print(f"healthy_receiver_delivered_bytes={healthy_bytes}")
print(f"healthy_destination_count={len(healthy)}")
print(f"stalled_destination_count={len(stalled)}")
print(f"stalled_receiver_delivered_bytes={stalled_bytes}")
print(f"first_byte_spread_ms={spread:.3f}")
print(f"program_fairness_jain={jain(list(totals.values())):.4f}")
for program, received in sorted(totals.items()):
    print(f"program_p{program:04d}_receiver_delivered_bytes={received}")
for destination, received, total_received, first_ms, stalled, _ in rows:
    print(f"destination_{destination} receiver_delivered_bytes={received} "
          f"receiver_total_bytes={total_received} first_ms={first_ms:.3f} "
          f"stalled={'yes' if stalled else 'no'}")
PY
}

capacity_srt_receiver_snapshot() {   # <receiver PID> <snapshot path> <copy path>
    local pid="$1" snapshot="$2" output="$3" attempt

    if [ -n "$CAPACITY_RECEIVER_CONFIG" ]; then
        receiver_capture snapshot "${RECEIVER_IDENTITIES[$pid]}" -USR1 \
            "$snapshot" "$output"
        return "$?"
    fi

    receiver_remove "$snapshot" || return 1
    rm -f "$output" || return 1
    capacity_capture_gate || return 1
    receiver_kill -USR1 "$pid" 2>/dev/null \
        || { echo "could not request SRT receiver snapshot" >&2; return 1; }
    for attempt in $(seq 1 100); do
        receiver_file_ready "$snapshot" && break
        receiver_alive "$pid" \
            || { echo "SRT receiver exited before writing a snapshot" >&2; return 1; }
        sleep 0.01
    done
    receiver_fetch "$snapshot" || return 1
    [ -s "$snapshot" ] \
        || { echo "SRT receiver snapshot was not written" >&2; return 1; }
    cp "$snapshot" "$output"
}

capacity_srt_measurement_snapshot() {   # <PID> <snapshot> <copy> <start|stop> <sampler or empty> <clock>
    local pid="$1" snapshot="$2" output="$3" action="$4" sampler="$5" clock="$6"
    local attempt request_ns=0 reply_ns=0 paused="$(dirname "$3")/receiver-sampler.ready.paused"
    local -a quiesce=()

    if [ -n "$CAPACITY_RECEIVER_CONFIG" ]; then
        if [ -n "$sampler" ]; then
            quiesce=( "${RECEIVER_IDENTITIES[$sampler]}" "$paused" )
        fi
        receiver_capture snapshot "${RECEIVER_IDENTITIES[$pid]}" -USR2 \
            "$snapshot" "$output" "${quiesce[@]}" || return 1
    else
        if [ -n "$sampler" ]; then
            kill -USR2 "$sampler" || return 1
            for attempt in $(seq 1 1000); do
                [ ! -f "$paused" ] || break
                sleep 0.001
            done
            [ -f "$paused" ] || return 1
        fi
        receiver_remove "$snapshot" || return 1
        rm -f "$output" || return 1
        capacity_capture_gate || return 1
        request_ns="$(python3 -c 'import time; print(time.monotonic_ns())')"
        receiver_kill -USR2 "$pid" 2>/dev/null \
            || { echo "could not toggle SRT receiver measurement $action" >&2; return 1; }
        for attempt in $(seq 1 1000); do
            receiver_file_ready "$snapshot" && break
            receiver_alive "$pid" \
                || { echo "SRT receiver exited before $action snapshot" >&2; return 1; }
            sleep 0.001
        done
        reply_ns="$(python3 -c 'import time; print(time.monotonic_ns())')"
        receiver_fetch "$snapshot" || return 1
        [ -s "$snapshot" ] \
            || { echo "SRT receiver $action snapshot was not written" >&2; return 1; }
        cp "$snapshot" "$output.tmp" && mv "$output.tmp" "$output" || return 1
    fi
    python3 - "$(dirname "$output")/receiver.measurement.window" "$action" \
        "$request_ns" "$reply_ns" "$output" "$CAPACITY_RECEIVER_CONFIG" "$clock" <<'PY'
import csv, json, pathlib, sys
path, action = pathlib.Path(sys.argv[1]), sys.argv[2]
begin, end = map(int, sys.argv[3:5])
if sys.argv[6]:
    bracket = json.loads(pathlib.Path(sys.argv[5] + ".request.json").read_text())
    begin, end = bracket["request_ns"], bracket["reply_ns"]
window = {} if action == "start" else json.loads(path.read_text())
window.update(clock_domain="controller-monotonic")
prefix = "start" if action == "start" else "end"
window[prefix + "_request_ns"] = begin
window[prefix + "_reply_ns"] = end
with open(sys.argv[5], newline="", encoding="utf-8") as source:
    stamps = {int(row["snapshot_ns"]) for row in csv.DictReader(source)}
if len(stamps) != 1:
    raise ValueError("receiver snapshot boundaries disagree")
native = stamps.pop()
window["native_" + prefix + "_ns"] = native
remote = sys.argv[7] == "receiver-monotonic"
if sys.argv[7] not in ("controller-monotonic", "receiver-monotonic"):
    raise ValueError("unknown SRT receiver clock")
window[prefix + "_ns"] = (begin + end) // 2 if remote else native
window[prefix + "_uncertainty_ns"] = (end - begin) // 2 if remote else 0
if not sys.argv[6]:
    pathlib.Path(sys.argv[5] + ".request.json").write_text(
        json.dumps({"request_ns": begin, "reply_ns": end}))
path.write_text(json.dumps(window))
PY
}

capacity_hls_reader_boundary() {   # <receiver PID> <report> <start|end>
    local pid="$1" report="$2" phase="$3" acknowledgment="$2.$3.json"
    local request_ns=0 reply_ns=0 attempt signo=-USR2
    [ "$phase" != start ] || signo=-USR1
    if [ -n "$CAPACITY_RECEIVER_CONFIG" ]; then
        receiver_capture snapshot "${RECEIVER_IDENTITIES[$pid]}" "$signo" \
            "$acknowledgment" "$acknowledgment" || return 1
    else
        capacity_capture_gate || return 1
        request_ns="$(python3 -c 'import time; print(time.monotonic_ns())')"
        receiver_kill "$signo" "$pid" || return 1
        for attempt in $(seq 1 1000); do
            receiver_file_ready "$acknowledgment" && break
            sleep 0.001
        done
        receiver_fetch "$acknowledgment" || return 1
        reply_ns="$(python3 -c 'import time; print(time.monotonic_ns())')"
    fi
    python3 - "$acknowledgment" "$(dirname "$report")/hls-readers.measurement.window" \
        "$phase" "$request_ns" "$reply_ns" <<'PY'
import json, pathlib, sys
ack = json.loads(pathlib.Path(sys.argv[1]).read_text())
path, phase = pathlib.Path(sys.argv[2]), sys.argv[3]
begin, end = map(int, sys.argv[4:])
if begin == 0 and end == 0:
    bracket = json.loads(pathlib.Path(sys.argv[1] + ".request.json").read_text())
    begin, end = bracket["request_ns"], bracket["reply_ns"]
else:
    pathlib.Path(sys.argv[1] + ".request.json").write_text(
        json.dumps({"request_ns": begin, "reply_ns": end}))
window = {} if phase == "start" else json.loads(path.read_text())
native = ack["native_ns"]
if ack["clock_domain"] == "controller-monotonic":
    at, uncertainty = native, 0
elif ack["clock_domain"] == "receiver-monotonic":
    at, uncertainty = (begin + end) // 2, (end - begin) // 2
else:
    raise ValueError("unknown HLS reader acknowledgment clock")
window.update(clock_domain="controller-monotonic")
window[phase + "_ns"] = at
window[phase + "_uncertainty_ns"] = uncertainty
window["native_" + phase + "_ns"] = native
window[phase + "_request_ns"] = begin
window[phase + "_reply_ns"] = end
path.write_text(json.dumps(window))
PY
}

capacity_hls_push_snapshot() {   # <port> <output> <start|end> <sink PID>
    local port="$1" output="$2" phase="$3" pid="$4" request_ns=0 reply_ns=0
    if [ -n "$CAPACITY_RECEIVER_CONFIG" ]; then
        receiver_capture command-capture "${RECEIVER_IDENTITIES[$pid]}" "$output" \
            curl -fsS -o "$output" "http://$CAPACITY_RECEIVER_ADDR:$port/__snapshot" || return 1
    else
        capacity_capture_gate || return 1
        request_ns="$(python3 -c 'import time; print(time.monotonic_ns())')"
        curl -fsS "http://$CAPACITY_RECEIVER_ADDR:$port/__snapshot" >"$output" || return 1
        reply_ns="$(python3 -c 'import time; print(time.monotonic_ns())')"
    fi
    python3 - "$output" "$(dirname "$output")/hls-push.measurement.window" \
        "$phase" "$request_ns" "$reply_ns" "$CAPACITY_RECEIVER_CONFIG" <<'PY'
import json, pathlib, sys
snapshot = json.loads(pathlib.Path(sys.argv[1]).read_text())
path, phase = pathlib.Path(sys.argv[2]), sys.argv[3]
begin, end = map(int, sys.argv[4:6])
if sys.argv[6]:
    bracket = json.loads(pathlib.Path(sys.argv[1] + ".request.json").read_text())
    begin, end = bracket["request_ns"], bracket["reply_ns"]
native = int(snapshot["monotonic"] * 1e9)
at, uncertainty = ((begin + end) // 2, (end - begin) // 2) if sys.argv[6] else (native, 0)
window = {} if phase == "start" else json.loads(path.read_text())
window.update(clock_domain="controller-monotonic")
window[phase + "_ns"] = at
window[phase + "_uncertainty_ns"] = uncertainty
window["native_" + phase + "_ns"] = native
window[phase + "_request_ns"] = begin
window[phase + "_reply_ns"] = end
if not sys.argv[6]:
    pathlib.Path(sys.argv[1] + ".request.json").write_text(
        json.dumps({"request_ns": begin, "reply_ns": end}))
path.write_text(json.dumps(window))
PY
}

capacity_sampler_ready() {   # <sampler PID> <acknowledgment>
    local pid="$1" acknowledgment="$2" attempt
    for attempt in $(seq 1 1200); do
        if [[ "$pid" == r* ]]; then
            receiver_file_ready "$acknowledgment" && return 0
            receiver_alive "$pid" || return 1
        else
            [ ! -f "$acknowledgment" ] || return 0
            kill -0 "$pid" 2>/dev/null || return 1
        fi
        sleep 0.01
    done
    echo "sampler did not acknowledge $acknowledgment" >&2
    return 1
}

capacity_controller_boundary() {   # <window JSON> <start|end> <begin ns> <end ns> <provenance>
    python3 - "$@" <<'PY'
import json, pathlib, sys
path, phase = pathlib.Path(sys.argv[1]), sys.argv[2]
begin, end = map(int, sys.argv[3:5])
if begin <= 0 or end < begin:
    raise ValueError("invalid controller collection bracket")
window = {} if phase == "start" else json.loads(path.read_text())
window.update(clock_domain="controller-monotonic", provenance=sys.argv[5])
window[phase + "_request_ns"] = begin
window[phase + "_reply_ns"] = end
window[phase + "_ns"] = (begin + end) // 2
window[phase + "_uncertainty_ns"] = (end - begin) // 2
if phase == "end":
    span = (window["end_ns"] - window["start_ns"]) / 1e9
    if span <= 0:
        raise ValueError("controller collection interval did not advance")
    print(f"{span:.6f}")
path.write_text(json.dumps(window))
PY
}

capacity_quality_stop_monitors() {   # [sampler PIDs]; no args stops all
    local pid status=0
    local -a selected=( "$@" ) remaining=()

    if [ "$#" -eq 0 ]; then
        selected=( ${QUALITY_MONITORS[@]+"${QUALITY_MONITORS[@]}"} )
    fi
    for pid in "${selected[@]}"; do
        receiver_kill -TERM "$pid" 2>/dev/null || true
    done
    for pid in "${selected[@]}"; do
        receiver_wait "$pid" 2>/dev/null || status=1
    done
    for pid in ${QUALITY_MONITORS[@]+"${QUALITY_MONITORS[@]}"}; do
        [[ " ${selected[*]} " == *" $pid "* ]] || remaining+=( "$pid" )
    done
    QUALITY_MONITORS=( "${remaining[@]}" )
    return "$status"
}

capacity_srt_incomplete_report() {   # <receiver snapshot> <programs> <destinations>
    python3 - "$1" "$2" "$3" <<'PY'
import csv
import sys

programs = int(sys.argv[2])
per_program = int(sys.argv[3])
expected_ids = {
    (f"d{destination:04d}" if programs == 1
     else f"p{program:04d}-d{destination:04d}")
    for program in range(programs)
    for destination in range(per_program)
}
with open(sys.argv[1], newline="", encoding="utf-8") as source:
    reader = csv.DictReader(source)
    if reader.fieldnames is None or "destination_id" not in reader.fieldnames:
        raise SystemExit(f"SRT snapshot {sys.argv[1]} does not match its schema")
    accepted = {row["destination_id"] for row in reader}
missing = sorted(expected_ids - accepted)
unexpected = sorted(accepted - expected_ids)
print(f"SRT receiver accepted {len(accepted)} of {len(expected_ids)} peers; "
      f"missing={missing[:16]} unexpected={unexpected[:4]}")
PY
}


capacity_srt_metrics_report() {   # <before worker-metrics prefix> <after prefix>
    python3 - "$1" "$2" <<'PY'
import glob
import math
import os
import re
import sys

metrics = (
    "nginx_media_srt_egress_shard_destinations",
    "nginx_media_srt_egress_shard_feed_queue_units",
    "nginx_media_srt_egress_shard_feed_queue_bytes",
    "nginx_media_srt_egress_shard_feed_queue_dropped_total",
    "nginx_media_srt_egress_shard_output_queue_units",
    "nginx_media_srt_egress_shard_output_queue_bytes",
    "nginx_media_srt_egress_shard_output_dropped_total",
    "nginx_media_srt_egress_shard_sent_bytes_total",
    "nginx_media_srt_egress_shard_sent_bursts_total",
    "nginx_media_srt_egress_shard_blocked_sends_total",
    "nginx_media_srt_egress_shard_retransmitted_packets_total",
)

def read_snapshot(prefix):
    values = {}
    for path in glob.glob(prefix + ".*"):
        if not os.path.isfile(path):
            continue
        with open(path, encoding="utf-8") as source:
            for line in source:
                match = re.match(
                    r"^([a-zA-Z_:][a-zA-Z0-9_:]*)(?:\{(.*?)\})?\s+"
                    r"([-+]?(?:[0-9]+\.?[0-9]*|\.[0-9]+)(?:[eE][-+]?[0-9]+)?)",
                    line,
                )
                if not match or match.group(1) not in metrics:
                    continue
                labels = dict(re.findall(
                    r'([a-zA-Z_][a-zA-Z0-9_]*)="((?:\\.|[^"])*)"',
                    match.group(2) or "",
                ))
                if "worker" not in labels or "shard" not in labels:
                    continue
                try:
                    value = float(match.group(3))
                except ValueError:
                    continue
                if math.isfinite(value):
                    values[(labels["worker"], labels["shard"],
                            match.group(1))] = value
    return values


def active_workers(prefix):
    values = []
    for path in glob.glob(prefix + ".*"):
        if not os.path.isfile(path):
            continue
        with open(path, encoding="utf-8") as source:
            for line in source:
                if not line.startswith("nginx_media_egress_active_workers{"):
                    continue
                labels_text, _, value_text = line.partition("}")
                labels = dict(re.findall(
                    r'([a-zA-Z_][a-zA-Z0-9_]*)="((?:\\.|[^"])*)"',
                    labels_text,
                ))
                if labels.get("engine") == "srt_shard":
                    values.append(int(float(value_text.strip())))
    return max(values) if values else "unavailable"


before_active = active_workers(sys.argv[1])
after_active = active_workers(sys.argv[2])
print(f"srt_active_senders_before={before_active}")
print(f"srt_active_senders_after={after_active}")
before = read_snapshot(sys.argv[1])
after = read_snapshot(sys.argv[2])
all_keys = {(worker, shard) for worker, shard, _ in set(before) | set(after)}
keys = sorted(
    (key for key in all_keys
     if after.get((key[0], key[1], metrics[0]), 0.0) > 0
     or before.get((key[0], key[1], metrics[0]), 0.0) > 0),
    key=lambda key: (key[0], key[1]),
)
if not all_keys:
    print("srt_shard_metrics=unavailable")
    raise SystemExit(0)
if not keys:
    print("srt_shard_metrics=no_active_destinations")
    raise SystemExit(0)

sent = []
for worker, shard in keys:
    def value(snapshot, metric):
        return snapshot.get((worker, shard, metric), 0.0)
    deltas = {
        "sent_bytes_delta": value(after, metrics[7]) - value(before, metrics[7]),
        "sent_bursts_delta": value(after, metrics[8]) - value(before, metrics[8]),
        "blocked_sends_delta": value(after, metrics[9]) - value(before, metrics[9]),
        "retransmitted_packets_delta": value(after, metrics[10]) - value(before, metrics[10]),
        "feed_drops_delta": value(after, metrics[3]) - value(before, metrics[3]),
        "output_drops_delta": value(after, metrics[6]) - value(before, metrics[6]),
    }
    sent.append(deltas["sent_bytes_delta"])
    gauge = {
        "destinations": value(after, metrics[0]),
        "feed_queue_units": value(after, metrics[1]),
        "feed_queue_bytes": value(after, metrics[2]),
        "output_queue_units": value(after, metrics[4]),
        "output_queue_bytes": value(after, metrics[5]),
    }
    fields = []
    for key, number in (*gauge.items(), *deltas.items()):
        formatted = str(int(number)) if number.is_integer() else f"{number:g}"
        fields.append(f"{key}={formatted}")
    print(f"shard worker={worker} shard={shard} " + " ".join(fields))
total = sum(sent)
squares = sum(value * value for value in sent)
jain = total * total / (len(sent) * squares) if squares else 0.0
print(f"shard_sent_bytes_spread={min(sent):.0f}..{max(sent):.0f} "
      f"range={(max(sent) - min(sent)):.0f} jain={jain:.4f}")
PY
}

capacity_memory_snapshot() {   # <file>
    local output="$1" pid
    local -a pids=()

    : > "$output" || return 1
    mapfile -t pids < <(worker_pids)
    [ -n "$RTMP_SINK_WORKER_PID" ] && [ -z "$CAPACITY_RECEIVER_CONFIG" ] \
        && pids+=( "$RTMP_SINK_WORKER_PID" )

    for pid in "${pids[@]}"; do
        awk -v pid="$pid" '
            $1 == "Rss:" { rss = $2 }
            $1 == "Pss:" { pss = $2 }
            END {
                if (rss == "" || pss == "") exit 1
                print pid, rss, pss
            }
        ' "/proc/$pid/smaps_rollup" >> "$output" \
            || { echo "could not read worker $pid smaps_rollup" >&2; return 1; }
    done
}

capacity_memory_report() {   # <before file> <after file>
    awk '
        NR == FNR { rss[$1] = $2; pss[$1] = $3; next }
        {
            br = rss[$1] + 0
            bp = pss[$1] + 0
            printf "      pid=%s rss_kb=%d->%d delta_kb=%+d pss_kb=%d->%d delta_kb=%+d\n",
                   $1, br, $2, $2 - br, bp, $3, $3 - bp
        }
    ' "$1" "$2"
}


# Which process is which, for the per-rung diagnostics bundle: every pid the
# CPU window samples, with its kind and the slot label the reports use.
capacity_write_processes() {   # <file> <SRT receiver> <HLS readers> <HLS push sink>
    local out="$1" pid

    {
        printf 'pid\tkind\tlabel\n'
        for pid in $(worker_pids); do
            printf '%s\tworker\t%s\n' "$pid" "$(slot_name "$pid")"
        done
        [ -n "$2" ] && printf '%s\tsrt-receiver\tsrt-receiver\n' "$2"
        [ -n "$3" ] && printf '%s\thls-readers\thls-readers\n' "$3"
        [ -n "$4" ] && printf '%s\thls-push-receiver\thls-push-receiver\n' "$4"
        for pid in ${RTMP_SINK_PIDS[@]+"${RTMP_SINK_PIDS[@]}"}; do
            printf '%s\trtmp-receiver\t%s\n' "$pid" "$(slot_name "$pid")"
        done
        for pid in "${PUBS[@]}"; do
            printf '%s\tpublisher\tpublisher\n' "$pid"
        done
    } > "$out"
    if [ -n "$CAPACITY_RECEIVER_CONFIG" ]; then
        python3 - "$out" <<'PY'
import csv, os, sys
path = sys.argv[1]
with open(path) as source:
    rows = list(csv.DictReader(source, delimiter="\t"))
for target, remote in ((path, False), (os.path.join(os.path.dirname(path), "receiver.processes.tsv"), True)):
    with open(target, "w") as output:
        writer = csv.DictWriter(output, fieldnames=["pid", "kind", "label"], delimiter="\t")
        writer.writeheader()
        for row in rows:
            if row["pid"].startswith("r") == remote:
                row["pid"] = row["pid"].removeprefix("r")
                writer.writerow(row)
PY
    fi
}

capacity_worker_cpu() {   # <before> <after> <seconds> <slot>
    report_cpu "$1" "$2" "$3" \
        | awk -v slot="$4" '$1 == slot { total += $3 }
            END { printf "%.1f", total }'
}

capacity_case() {   # <label> <programs> <bitrate> <destinations> <seconds> [srt|rtmp|hls|hls-push|rtmp-hls-push] [stall destination ID] [yes|no quality] [SRT share percent] [HLS push share percent]
    local label="$1" programs="$2" rate="$3" destinations="$4" seconds="$5"
    local protocol="${6:-srt}" stall_id="${7:-}" quality_mode="${8:-no}"
    local srt_share="${9:-0}"
    local hls_push_share="${10:-0}"
    local quality_failed=0 quality_status quality_report_file
    local hls_push_quality_report hls_push_reference_bps
    local quality_reference_bps rtmp_reference_bps hls_reference_bps
    local rtmp_report_file hls_report_file
    local receiver_sampler_pid queue_sampler_pid rtmp_sampler_pid
    local offer_pid="" receiver_clock=controller-monotonic
    if [ -n "$CAPACITY_RECEIVER_CONFIG" ] || [ -n "$CAPACITY_RECEIVER_FETCH" ] \
        || [ -n "$CAPACITY_RECEIVER_COLLECT" ]; then
        receiver_clock=receiver-monotonic
    fi
    local workers="$CAPACITY_WORKERS" case_id source rate_bps offered_in offered_out
    local preflight_note="" preflight_status=0
    local primary_destinations=0 srt_destinations=0 rtmp_destinations=0
    local hls_readers=0 hls_push_destinations=0 hls_enabled=yes
    local total_dest total_srt_dest total_rtmp_dest total_hls_push_dest
    local started_srt started_rtmp started_hls_push sink_id output_id owner name slot index depth owner_streams
    local receiver_api sink_index
    local connect_wait connect_attempts sink_port sink_ready sink_csv
    local sink_snapshot_before sink_snapshot_after stall_seen rtmp_ready
    local sink_pid="" publisher_pid="" receiver_pid hls_pid="" hls_ready hls_log hls_playlist
    local hls_push_sink_pid="" hls_push_sink_port hls_push_ready ready_status
    local hls_push_progress_file hls_push_progress_received
    local hls_push_progress_remaining hls_push_progress_elapsed
    local before_frames after_frames before_dispatched after_dispatched
    local fanout_max p50 p95 p99 p999 frame_rate frame_delta fairness
    local measure_start measure_end measure_seconds
    local metrics_before metrics_after feed_units feed_bytes feed_high_units
    local feed_high_bytes feed_evictions feed_evictions_before
    local feed_evictions_after feed_overruns feed_overruns_before
    local feed_overruns_after source_frames source_frames_before source_frames_after
    local worker_pid worker_slot worker_before worker_after cpu_pct worker_cpu_total
    local budget_before budget_after visits_before visits_after
    local late_before late_after max_service event_delay
    local socket_before socket_after sock_tcp_before sock_tcp_after
    local sock_udp_before sock_udp_after tcp_inuse_before tcp_inuse_after
    local udp_inuse_before udp_inuse_after socket_row slow_drops
    local -a owner_pool=() one_owner=() names=() owners=()
    local -a counts_before=() counts_after=() bounds=()
    local -a progress_frames=() quality_worker_pids=()
    local bucket_total=0 dispatched_delta=0 bin_label bins_text=""
    local low high value
    [[ "$programs" =~ ^[1-9][0-9]*$ \
       && "$destinations" =~ ^[1-9][0-9]*$ \
       && "$workers" =~ ^[1-9][0-9]*$ \
       && "$seconds" =~ ^[1-9][0-9]*$ ]] \
        || { echo "invalid capacity case: $label" >&2; return 1; }
    case "$protocol" in
        srt|rtmp|hls|hls-push|rtmp-hls-push) ;;
        *) echo "invalid capacity protocol: $protocol" >&2; return 1 ;;
    esac
    case "$quality_mode" in
        yes|no) ;;
        *) echo "invalid quality mode: $quality_mode" >&2; return 1 ;;
    esac
    [[ "$srt_share" =~ ^(0|[1-9][0-9]*)$ ]] \
        && [ "$srt_share" -le 100 ] \
        || { echo "SRT share must be an integer from 0 to 100" >&2; return 1; }
    [[ "$hls_push_share" =~ ^(0|[1-9][0-9]*)$ ]] \
        && [ "$hls_push_share" -le 100 ] \
        || { echo "HLS push share must be an integer from 0 to 100" \
                 >&2; return 1; }
    if [ "$protocol" = rtmp-hls-push ]; then
        [ "$srt_share" -gt 0 ] && [ "$hls_push_share" -gt 0 ] \
            && [ "$(( srt_share + hls_push_share ))" -lt 100 ] \
            || { echo "three-way mixes need positive SRT, HLS push, and RTMP shares" \
                     >&2; return 1; }
    elif [ "$hls_push_share" -ne 0 ]; then
        echo "HLS push share is valid only for three-way mixes" >&2
        return 1
    fi
    if [ "$protocol" = srt ]; then
        [ "$srt_share" -eq 0 ] \
            || { echo "pure SRT cases do not take a secondary SRT share" >&2; return 1; }
        srt_destinations="$destinations"
    else
        srt_destinations=$(( (destinations * srt_share + 50) / 100 ))
    fi
    primary_destinations=$(( destinations - srt_destinations ))
    case "$protocol" in
        rtmp) rtmp_destinations="$primary_destinations" ;;
        hls) hls_readers="$primary_destinations" ;;
        hls-push) hls_push_destinations="$primary_destinations" ;;
        rtmp-hls-push)
            hls_push_destinations=$(( (destinations * hls_push_share + 50) / 100 ))
            rtmp_destinations=$(( primary_destinations - hls_push_destinations ))
            ;;
    esac
    if [ "$protocol" != srt ] && [ "$primary_destinations" -eq 0 ]; then
        echo "mixed cases require at least one $protocol destination" >&2
        return 1
    fi
    if [ "$quality_mode" = yes ]; then
        [ "$programs" -eq 1 ] && [ -z "$stall_id" ] \
            || { echo "quality cases require one un-stalled program" \
                     >&2; return 1; }
    fi
    if [ "$hls_readers" -gt 0 ] && [ "$quality_mode" != yes ]; then
        echo "HLS capacity cases require quality mode" >&2
        return 1
    fi
    if [ "$hls_push_destinations" -gt 0 ] && [ "$quality_mode" != yes ]; then
        echo "HLS push capacity cases require quality mode" >&2
        return 1
    fi
    if [ "$rtmp_destinations" -gt 0 ]; then
        [ -z "$stall_id" ] \
            || { echo "RTMP capacity cases do not support a stalled SRT peer" \
                     >&2; return 1; }
        # Receiver metrics are worker-local, so keep this complete RTMP
        # quality sample on one worker.
        workers=1
    fi
    if [ -n "$stall_id" ] && [ "$protocol" != srt ]; then
        echo "only pure SRT cases support a stalled destination" >&2
        return 1
    fi
    # A rung's window is bounded so a typo cannot start a run that never
    # ends; the sustained qualification the method asks for is half an hour
    # at the configuration a production claim rests on, so the bound is an
    # hour and the samplers are the thing to watch at that length.
    [ "$seconds" -le 3600 ] \
        || { echo "capacity window must be at most 3600 seconds" \
                 >&2; return 1; }
    [ "$workers" -le 16 ] && [ "$programs" -le 32 ] \
        && [ "$destinations" -le 1000 ] \
        && [ "$(( programs * destinations ))" -le 1000 ] \
        || { echo "capacity case exceeds bounded worker/output limits" \
                 >&2; return 1; }
    owner_streams=$(( (programs + workers - 1) / workers ))
    [ "$(( owner_streams * destinations ))" -le 1000 ] \
        || { echo "capacity case exceeds per-owner output limit" >&2; return 1; }
    command -v ss >/dev/null \
        || { echo "ss is required for socket memory snapshots" >&2; return 1; }
    if [ "$srt_destinations" -gt 0 ]; then
        capacity_build_srt_sink || return 1
    fi

    rate_bps="$(capacity_rate_bps "$rate")" || return 1
    [ "$(( rate_bps * programs * destinations ))" -le 8000000000 ] \
        || { echo "capacity case nominal egress exceeds 8000 Mbit/s" \
                 >&2; return 1; }
    offered_in="$(awk -v b="$(( programs * rate_bps ))" \
        'BEGIN { printf "%.1f", b / 1000000 }')"
    offered_out="$(awk -v b="$(( programs * rate_bps * destinations ))" \
        'BEGIN { printf "%.1f", b / 1000000 }')"
    total_dest=$(( programs * destinations ))
    total_srt_dest=$(( programs * srt_destinations ))
    total_rtmp_dest=$(( programs * rtmp_destinations ))
    total_hls_push_dest=$(( programs * hls_push_destinations ))
    CAPACITY_CASE_ID=$(( ${CAPACITY_CASE_ID:-0} + 1 ))
    case_id="$CAPACITY_CASE_ID"
    source="$RUN/media/capacity-$rate.ts"
    if [ ! -s "$source" ]; then
        make_source "$source" "$rate"
    fi

    mkdir -p "$RUN/capacity"
    local case_dir="$RUN/capacity/$label"
    rm -rf "$case_dir"
    mkdir -p "$case_dir"
    receiver_mkdir "$case_dir" || return 1
    python3 "$ROOT/tests/bench/capacity_media_offer.py" prepare \
        "$source" "$case_dir/prepared-media.json" || return 1
    if [ -n "$CAPACITY_RECEIVER_CONFIG" ]; then
        python3 - "$CAPACITY_RECEIVER_CONFIG" "$case_dir" <<'PY'
import json, pathlib, shutil, sys
config = json.load(open(sys.argv[1]))
target = pathlib.Path(sys.argv[2])
shutil.copyfile(config["receiver_fingerprint"], target / "preflight.receiver.json")
nginx = config.get("native_nginx_fingerprint")
if nginx and pathlib.Path(nginx).is_file():
    shutil.copyfile(nginx, target / "receiver-nginx-fingerprint.json")
PY
        [ "$?" -eq 0 ] || return 1
    fi

    # A capacity case is a claim about the software, so it refuses to measure
    # beside a competing job on its own CPUs: the same preflight the quality
    # ladder runs, with the same env rules.
    local preflight_status=0
    capacity_preflight_rung "$case_dir" "$total_dest" "$rate" \
        || preflight_status="$?"
    case "$preflight_status" in
        0) ;;
        2)
            # Not measured, and not a failure either: the host could not carry
            # the offer.  Status 4 says so to the caller - 2 is a quality
            # failure here.
            capacity_write_diagnostics "$case_dir" infrastructure-limited \
                destinations="$total_dest" programs="$programs"
            echo "capacity_case_result case=$label result=infrastructure-limited"
            return 4
            ;;
        3)
            # The preflight reached no environmental verdict: the run is still
            # the best evidence available, but the bundle says so rather than
            # implying the host was judged fit.
            preflight_note=insufficient-evidence
            ;;
        *)
            # The preflight itself failed.  Measuring without it would publish
            # a number with no environmental verdict at all, so this is a
            # setup failure, not a result.
            capacity_write_diagnostics "$case_dir" setup-failure \
                destinations="$total_dest" programs="$programs" \
                preflight_status="$preflight_status"
            echo "capacity_case_result case=$label result=setup-error status=$preflight_status"
            return 3
            ;;
    esac

    for (( slot = 0; slot < workers; slot++ )); do
        mapfile -t one_owner < <(
            owner_names "$slot" "$workers" "$programs" "cc${case_id}-"
        )
        [ "${#one_owner[@]}" -eq "$programs" ] \
            || { echo "could not name $programs streams for worker $slot" \
                     >&2; return 1; }
        for name in "${one_owner[@]}"; do
            owner_pool+=( "$slot:$name" )
        done
    done

    depth=0
    while [ "${#names[@]}" -lt "$programs" ]; do
        for (( slot = 0; slot < workers; slot++ )); do
            index=$(( slot * programs + depth ))
            [ "$index" -lt "${#owner_pool[@]}" ] || continue
            IFS=: read -r owner name <<< "${owner_pool[$index]}"
            owners+=( "$owner" )
            names+=( "$name" )
            [ "${#names[@]}" -ge "$programs" ] && break
        done
        depth=$(( depth + 1 ))
    done

    echo
    echo "== capacity $protocol $label: workers=$workers programs=$programs"
    echo "   video_rate=$rate offered_ingress=${offered_in}Mbit/s"
    echo "   destinations_per_program=$destinations total_destinations=$total_dest"
    echo "   per_program_outputs: SRT=$srt_destinations RTMP=$rtmp_destinations HLS_readers=$hls_readers HLS_push=$hls_push_destinations"
    echo "   egress_workers: SRT=$CAPACITY_FIXED_SRT_WORKERS HLS_push=$CAPACITY_FIXED_HLS_PUSH_WORKERS"
    [ "$protocol" = srt ] && echo "   srt_hls_preparation=$CAPACITY_SRT_HLS"
    echo "   offered_egress=${offered_out}Mbit/s window=${seconds}s"

    # RTMP-only receivers need to accept and drain the stream.  Cases with
    # SRT keep HLS on by default as the regression baseline; an SRT
    # destination asks for the shared transport-stream preparation itself.
    if [ "$rtmp_destinations" -gt 0 ] \
        && [ "$srt_destinations" -eq 0 ] \
        && [ "$hls_readers" -eq 0 ] \
        && [ "$hls_push_destinations" -eq 0 ]; then
        hls_enabled=no
    fi
    # Pure SRT keeps HLS preparation on by default (the regression baseline);
    # CAPACITY_SRT_HLS=no measures the SRT path without the shared segmenter.
    if [ "$protocol" = srt ] && [ "$CAPACITY_SRT_HLS" = no ]; then
        hls_enabled=no
    fi
    printf '%s\n' "$case_dir" >"$RUN/active-capacity-case"
    start_instance "$workers" "$hls_enabled" no
    if [ "$rtmp_destinations" -gt 0 ]; then
        local rtmp_sinks=$(( (total_rtmp_dest + CAPACITY_RTMP_RECEIVER_PEERS - 1)
                             / CAPACITY_RTMP_RECEIVER_PEERS ))
        [ "$rtmp_sinks" -le 64 ] || rtmp_sinks=64
        echo "   rtmp_receivers=$rtmp_sinks (<= $CAPACITY_RTMP_RECEIVER_PEERS destinations each)"
        [ -z "$CAPACITY_RECEIVER_CONFIG" ] || RTMP_SINK_RUN="$case_dir/rtmp-sink"
        start_rtmp_sink_instance "$rtmp_sinks" || return 1
    fi
    PUBS=()
    SINKS=()
    sink_port=$(( BASE + 64 ))
    local sink_listeners=1
    if [ "$srt_destinations" -gt 0 ]; then
        sink_listeners=$(( (total_srt_dest + CAPACITY_SRT_RECEIVER_PEERS - 1)
                           / CAPACITY_SRT_RECEIVER_PEERS ))
        [ "$sink_listeners" -ge 1 ] || sink_listeners=1
        [ "$sink_listeners" -le 64 ] || sink_listeners=64
        echo "   srt_receiver_listeners=$sink_listeners (<= $CAPACITY_SRT_RECEIVER_PEERS destinations each)"
    fi
    if [ "$srt_destinations" -gt 0 ]; then
        sink_ready="$case_dir/srt.ready"
        sink_csv="$case_dir/srt.csv"
        sink_snapshot_before="$case_dir/srt.before.csv"
        sink_snapshot_after="$case_dir/srt.after.csv"
        rm -f "$sink_ready" "$sink_csv" "$sink_csv.snapshot" \
            "$sink_snapshot_before" "$sink_snapshot_after"
        local -a sink_args=()
        [ "$quality_mode" != yes ] || sink_args+=( quality )
        [ "$quality_mode" = yes ] || [ -z "$stall_id" ] || sink_args+=( "$stall_id" )
        receiver_start "$case_dir/srt.identity.json" "$case_dir/srt-receiver.log" \
            env SRT_SINK_BIND="$CAPACITY_RECEIVER_ADDR" $(pin "$CAPACITY_RECEIVER_CPUS") \
            "$RUN/srt_fanout_sink" "$sink_port:$sink_listeners" "$total_srt_dest" \
            "$sink_ready" "$sink_csv" "${sink_args[@]}" || return 1
        sink_pid="$RECEIVER_PID"
        SINKS+=( "$sink_pid" )
    fi
    if [ "$hls_push_destinations" -gt 0 ]; then
        hls_push_sink_port=$(( BASE + 30 ))
        receiver_start "$case_dir/hls-push.identity.json" "$case_dir/hls-push-sink.log" \
            $(pin "$CAPACITY_RECEIVER_CPUS") \
            python3 "$ROOT/tests/bench/hls_push_capacity.py" serve \
            --port "$hls_push_sink_port" --bind "$CAPACITY_RECEIVER_ADDR" || return 1
        hls_push_sink_pid="$RECEIVER_PID"
        SINKS+=( "$hls_push_sink_pid" )
        hls_push_ready=0
        for attempt in $(seq 1 100); do
            if curl -fsS "http://$CAPACITY_RECEIVER_ADDR:$hls_push_sink_port/__health" \
                >/dev/null 2>&1
            then
                hls_push_ready=1
                break
            fi
            receiver_alive "$hls_push_sink_pid" \
                || { cat "$case_dir/hls-push-sink.log" >&2
                     echo "HLS push sink exited during startup" >&2; return 1; }
            sleep 0.1
        done
        [ "$hls_push_ready" -eq 1 ] \
            || { echo "HLS push sink did not become ready" >&2; return 1; }
    fi

    for name in "${names[@]}"; do
        curl -fsS -X POST -H 'Content-Type: application/json' \
            -d "{\"application\":\"live\",\"name\":\"$name\"}" \
            "$(api)/streams" >/dev/null \
            || { echo "could not create capacity stream $name" >&2; return 1; }
    done

    for (( index = 0; index < programs; index++ )); do
        name="${names[$index]}"
        slot="${owners[$index]}"
        owner="$(owner_of "$name")" || {
            echo "could not read owner for $name" >&2; return 1;
        }
        [ "$owner" = "$slot" ] \
            || { echo "$name owner $owner did not match expected worker $slot" \
                     >&2; return 1; }

        for (( attempt = 0; attempt < srt_destinations; attempt++ )); do
            sink_id="$(capacity_destination_id "$index" "$attempt" "$programs")"
            post_owner "/streams/live/$name/destinations" \
                "{\"id\":\"$sink_id\",\"type\":\"srt\",\"host\":\"$CAPACITY_RECEIVER_ADDR\",\"port\":$(( sink_port + (index * srt_destinations + attempt) % sink_listeners )),\"streamid\":\"#!::r=live/$name,m=publish,s=$sink_id\"}" \
                || return 1
            [ "$sink_id" = "$stall_id" ] && stall_seen=1
        done
        if [ "$rtmp_destinations" -gt 0 ]; then
            for (( attempt = srt_destinations;
                  attempt < srt_destinations + rtmp_destinations;
                  attempt++ )); do
                output_id="$(capacity_destination_id "$index" "$attempt" "$programs")"
                sink_index=$(((index * rtmp_destinations + attempt - srt_destinations) \
                              % RTMP_SINK_COUNT))
                receiver_api="$(rtmp_sink_api "$sink_index")"
                curl -fsS -X POST -H 'Content-Type: application/json' \
                    -d "{\"application\":\"live\",\"name\":\"$output_id\"}" \
                    "$receiver_api/streams" >/dev/null \
                    || { echo "could not create RTMP receiver stream $output_id" >&2
                         return 1; }
                curl -fsS -X POST -H 'Content-Type: application/json' \
                    -d "{\"id\":\"$output_id\",\"type\":\"rtmp\",\"key\":\"$output_id\"}" \
                    "$receiver_api/streams/live/$output_id/sources" >/dev/null \
                    || { echo "could not provision RTMP receiver source $output_id" >&2
                         return 1; }
                post_owner "/streams/live/$name/destinations" \
                    "{\"id\":\"$output_id\",\"type\":\"rtmp\",\"host\":\"$CAPACITY_RECEIVER_ADDR\",\"port\":$(rtmp_sink_port "$sink_index"),\"streamid\":\"$output_id\"}" \
                    || return 1
            done
        fi
        if [ "$hls_push_destinations" -gt 0 ]; then
            for (( attempt = srt_destinations + rtmp_destinations;
                  attempt < srt_destinations + rtmp_destinations + hls_push_destinations;
                  attempt++ )); do
                output_id="$(capacity_destination_id "$index" "$attempt" "$programs")"
                post_owner "/streams/live/$name/destinations" \
                    "{\"id\":\"$output_id\",\"type\":\"hls_push\",\"host\":\"http://$CAPACITY_RECEIVER_ADDR:$hls_push_sink_port/$output_id/\",\"path\":\"$RUN/hls/live/$name\"}" \
                    || return 1
            done
        fi
    done
    if [ -n "$stall_id" ] && [ "${stall_seen:-0}" -ne 1 ]; then
        echo "slow-reader destination ID $stall_id was not configured" >&2
        return 1
    fi

    connect_wait=$(( 30 + total_dest / 10 ))
    connect_attempts=$(( connect_wait * 10 ))
    for attempt in $(seq 1 "$connect_attempts"); do
        started_srt="$(grep -cE "media: srt destination .* started" \
            "$RUN/logs/error.log" 2>/dev/null || true)"
        started_rtmp="$(grep -cE "media: rtmp destination .* started" \
            "$RUN/logs/error.log" 2>/dev/null || true)"
        started_hls_push="$(grep -cE "media: hls push destination .* started" \
            "$RUN/logs/error.log" 2>/dev/null || true)"
        if [ "$started_srt" -ge "$total_srt_dest" ] \
            && [ "$started_rtmp" -ge "$total_rtmp_dest" ] \
            && [ "$started_hls_push" -ge "$total_hls_push_dest" ]; then
            break
        fi
        sleep 0.1
    done
    [ "$started_srt" -ge "$total_srt_dest" ] \
        && [ "$started_rtmp" -ge "$total_rtmp_dest" ] \
        && [ "$started_hls_push" -ge "$total_hls_push_dest" ] \
        || { echo "only ${started_srt:-0} of $total_srt_dest SRT, ${started_rtmp:-0} of $total_rtmp_dest RTMP and ${started_hls_push:-0} of $total_hls_push_dest HLS push destinations started" \
                 >&2; return 1; }
    # Start media while nonblocking SRT handshakes settle; send errors trigger the
    # output's normal retry path for a connection that did not establish.
    if [ "$hls_push_destinations" -gt 0 ]; then
        curl -fsS "http://$CAPACITY_RECEIVER_ADDR:$hls_push_sink_port/__mark" \
            >"$case_dir/hls-push.mark.json" \
            || { echo "could not mark HLS push first-segment timing" >&2; return 1; }
    fi
    if [ "$hls_readers" -gt 0 ] || [ "$hls_push_destinations" -gt 0 ]; then
        python3 "$ROOT/tests/bench/capacity_media_offer.py" observe \
            "$RUN/hls/live/${names[0]}/index.m3u8" "$case_dir/hls-production.json" \
            >"$case_dir/hls-production.log" 2>&1 &
        offer_pid="$!"
        QUALITY_MONITORS+=( "$offer_pid" )
    fi
    for (( index = 0; index < programs; index++ )); do
        publish "${SRT_PORTS[${owners[$index]}]}" "${names[$index]}" "$source"
        PUBS+=( "$!" )
    done
    if [ "$srt_destinations" -gt 0 ]; then
        for attempt in $(seq 1 "$connect_attempts"); do
            receiver_file_ready "$sink_ready" && break
            receiver_alive "$sink_pid" \
                || { echo "shared SRT receiver exited before accepting all peers" \
                     >&2; return 1; }
            sleep 0.1
        done
        if ! receiver_file_ready "$sink_ready"; then
            if capacity_srt_receiver_snapshot "$sink_pid" \
                "$sink_csv.snapshot" "$case_dir/srt.incomplete.csv"; then
                capacity_srt_incomplete_report "$case_dir/srt.incomplete.csv" \
                    "$programs" "$srt_destinations" || return 1
            else
                echo "could not capture incomplete SRT receiver snapshot" >&2
            fi
            echo "shared SRT receiver accepted fewer than $total_srt_dest peers" >&2
            return 1
        fi
    fi


    # Exclude publisher connection and the first output burst from measurement.
    for attempt in $(seq 1 120); do
        progress_ready=1
        for name in "${names[@]}"; do
            source_frames="$(owner_metric "$name" \
                nginx_media_stream_program_frames)"
            dispatched_delta="$(owner_metric "$name" \
                nginx_media_stream_dispatched_total)"
            if [ "${source_frames:-0}" -le 0 ] \
                || [ "${dispatched_delta:-0}" -le 0 ]; then
                progress_ready=0
                break
            fi
        done
        [ "$progress_ready" -eq 1 ] && break
        sleep 0.1
    done
    [ "$progress_ready" -eq 1 ] \
        || { echo "capacity streams never reached program/output progress" \
                 >&2; return 1; }
    if [ "$rtmp_destinations" -gt 0 ]; then
        rtmp_ready=0
        for attempt in $(seq 1 "$connect_attempts"); do
            : > "$case_dir/rtmp-warmup.metrics"
            for (( sink = 0; sink < RTMP_SINK_COUNT; sink++ )); do
                curl -fsS "$(rtmp_sink_api "$sink")/metrics" \
                    >> "$case_dir/rtmp-warmup.metrics" \
                    || { echo "could not scrape RTMP receiver metrics" >&2; return 1; }
            done
            if capacity_rtmp_receiver_ready "$case_dir/rtmp-warmup.metrics" \
                "$programs" "$rtmp_destinations" "$srt_destinations"
            then
                rtmp_ready=1
                break
            fi
            sleep 0.1
        done
        [ "$rtmp_ready" -eq 1 ] \
            || { echo "RTMP capacity receivers did not all accept media" \
                 >&2; return 1; }
    fi
    if [ "$hls_readers" -gt 0 ]; then
        hls_playlist="$RUN/hls/live/${names[0]}/index.m3u8"
        echo "   waiting for first completed HLS segment"
        for attempt in $(seq 1 "$connect_attempts"); do
            [ -s "$hls_playlist" ] && break
            sleep 0.1
        done
        [ -s "$hls_playlist" ] \
            || { echo "HLS segmenter did not publish $hls_playlist" >&2; return 1; }
        hls_ready="$case_dir/hls.ready"
        hls_report_file="$case_dir/hls-readers.csv"
        hls_log="$case_dir/hls-reader.log"
        rm -f "$hls_ready" "$hls_report_file"
        receiver_start "$case_dir/hls.identity.json" "$hls_log" \
            $(pin "$CAPACITY_RECEIVER_CPUS") python3 "$ROOT/tests/bench/hls_capacity_readers.py" \
            --url "http://$CAPACITY_SENDER_ADDR:$([ "$CAPACITY_SENDER_ADDR" = 127.0.0.1 ] && echo "$HTTP_PORT" || echo "$(( HTTP_PORT + 31 ))")/hls/live/${names[0]}/index.m3u8" \
            --readers "$hls_readers" --duration "$(( seconds + 60 ))" \
            --report "$hls_report_file" --ready-file "$hls_ready" \
            --reference-bps "${CAPACITY_QUALITY_REFERENCE_HLS_BPS:-0}" \
            --clock-domain "$receiver_clock" \
            --min-delivery-ratio "$CAPACITY_QUALITY_MIN_DELIVERY_RATIO" \
            || return 1
        hls_pid="$RECEIVER_PID"
        QUALITY_MONITORS+=( "$hls_pid" )
        for attempt in $(seq 1 "$connect_attempts"); do
            receiver_file_ready "$hls_ready" && break
            receiver_alive "$hls_pid" \
                || { cat "$hls_log" >&2; echo "HLS readers exited during warmup" >&2; return 1; }
            sleep 0.1
        done
        receiver_file_ready "$hls_ready" \
            || { cat "$hls_log" >&2; echo "HLS readers did not become ready" >&2; return 1; }
    fi
    if [ "$hls_push_destinations" -gt 0 ]; then
        hls_push_ready=0
        hls_push_progress_file="$case_dir/hls-push-readiness.json"
        : > "$case_dir/hls-push-readiness.csv"
        echo "elapsed_s,received,expected,remaining" \
            > "$case_dir/hls-push-readiness.csv"
        for attempt in $(seq 1 "$connect_attempts"); do
            ready_status="$(curl -sS -o /dev/null -w '%{http_code}' \
                "http://$CAPACITY_RECEIVER_ADDR:$hls_push_sink_port/__ready?destinations=$hls_push_destinations&offset=$((srt_destinations + rtmp_destinations))" \
                2>/dev/null || true)"
            if [ $(( attempt % 10 )) -eq 0 ] || [ "$ready_status" = 200 ]; then
                curl -fsS \
                    "http://$CAPACITY_RECEIVER_ADDR:$hls_push_sink_port/__progress?destinations=$hls_push_destinations&offset=$((srt_destinations + rtmp_destinations))" \
                    > "$hls_push_progress_file" \
                    || { echo "could not query HLS push readiness progress" \
                             >&2; return 1; }
                read -r hls_push_progress_elapsed hls_push_progress_received \
                    hls_push_progress_remaining < <(python3 - \
                        "$hls_push_progress_file" "$hls_push_destinations" <<'PY'
import json
import sys

with open(sys.argv[1], encoding="utf-8") as source:
    progress = json.load(source)
print(
    f"{progress['elapsed_s'] or 0:.3f}",
    progress["received"],
    len(progress["missing_ids"]),
)
PY
                )
                printf '%s,%s,%s,%s\n' "$hls_push_progress_elapsed" \
                    "$hls_push_progress_received" "$hls_push_destinations" \
                    "$hls_push_progress_remaining" \
                    >> "$case_dir/hls-push-readiness.csv"
                if [ "$hls_push_progress_received" != \
                     "${hls_push_last_progress_received:-}" ]; then
                    echo "   HLS push first-segment readiness: elapsed=${hls_push_progress_elapsed}s received=$hls_push_progress_received/$hls_push_destinations remaining=$hls_push_progress_remaining"
                    hls_push_last_progress_received="$hls_push_progress_received"
                fi
            fi
            if [ "$ready_status" = 200 ]; then
                hls_push_ready=1
                break
            fi
            receiver_alive "$hls_push_sink_pid" \
                || { cat "$case_dir/hls-push-sink.log" >&2
                     echo "HLS push sink exited before all destinations received a segment" \
                         >&2; return 1; }
            sleep 0.1
        done
        if [ "$hls_push_ready" -ne 1 ]; then
            curl -fsS \
                "http://$CAPACITY_RECEIVER_ADDR:$hls_push_sink_port/__progress?destinations=$hls_push_destinations&offset=$((srt_destinations + rtmp_destinations))" \
                > "$hls_push_progress_file" || true
            python3 - "$hls_push_progress_file" <<'PY'
import json
import sys

with open(sys.argv[1], encoding="utf-8") as source:
    progress = json.load(source)
print(
    "HLS push readiness timed out: "
    f"received={progress['received']}/{progress['expected']} "
    "remaining_ids=" + ",".join(progress["missing_ids"])
)
PY
            if cpu_window 3 "$hls_push_sink_pid"; then
                capacity_worker_metrics "$case_dir/workers.readiness" || true
                curl -fsS \
                    "http://$CAPACITY_RECEIVER_ADDR:$hls_push_sink_port/__progress?destinations=$hls_push_destinations&offset=$((srt_destinations + rtmp_destinations))" \
                    > "$hls_push_progress_file" || true
                curl -fsS "http://$CAPACITY_RECEIVER_ADDR:$hls_push_sink_port/__snapshot" \
                    > "$case_dir/hls-push.readiness.json" || true
                python3 "$ROOT/tests/bench/hls_push_capacity.py" \
                    readiness-report \
                    --metrics-prefix "$case_dir/workers.readiness" \
                    --stream "${names[0]}" \
                    --destinations "$hls_push_destinations" \
                    --programs "$programs" \
                    --destination-offset "$((srt_destinations + rtmp_destinations))" \
                    --sink-snapshot "$case_dir/hls-push.readiness.json" \
                    --progress "$hls_push_progress_file" \
                    > "$case_dir/hls-push-readiness-report.txt" || true
                cat "$case_dir/hls-push-readiness-report.txt"
                echo "   HLS push sink CPU during timeout diagnostics:"
                report_cpu "$W_BEFORE" "$W_AFTER" "$W_DUR" \
                    | awk -v pid="pid$hls_push_sink_pid" '
                        $1 == pid {
                            printf "      thread=%s cpu=%.1f%%\n", $2, $3
                            total += $3
                            count++
                        }
                        END {
                            if (!count) print "      no HLS push sink CPU rows"
                            else printf "      aggregate_hls_push_sink_cpu=%.1f%%\n", total
                        }'
            else
                echo "could not collect timeout CPU diagnostics" >&2
            fi
            echo "HLS push sink did not receive a TS segment from all" \
                 "$hls_push_destinations destinations before timeout" \
                 "(HTTP $ready_status)" >&2
            echo "readiness_progress=$case_dir/hls-push-readiness.csv" >&2
            return 1
        fi
        python3 - "$hls_push_progress_file" <<'PY'
import json
import sys

with open(sys.argv[1], encoding="utf-8") as source:
    progress = json.load(source)
print(
    f"   HLS push all-destination first-segment latency="
    f"{progress['elapsed_s']:.3f}s ({progress['received']}/{progress['expected']})"
)
PY
        echo "   HLS push readiness progress=$case_dir/hls-push-readiness.csv"
    fi

    # Process startup and SSH ownership are setup, not accounting. Queue and
    # receiver samplers are ready and wait for their opening baseline releases.
    if [ "$rtmp_destinations" -gt 0 ] && [ "$quality_mode" = yes ]; then
        rm -f "$case_dir"/rtmp-sampler.ready* "$case_dir/rtmp-sampler.baseline"
        python3 "$ROOT/tests/bench/rtmp_capacity_quality.py" sample \
            "$(rtmp_sink_metric_urls)" "$case_dir/rtmp-receiver.before" \
            "$case_dir/rtmp-receiver-intervals.csv" --interval 1 \
            --ready-file "$case_dir/rtmp-sampler.ready" \
            --baseline-ready "$case_dir/rtmp-sampler.baseline" \
            >"$case_dir/rtmp-sampler.log" 2>&1 &
        rtmp_sampler_pid="$!"
        QUALITY_MONITORS+=( "$rtmp_sampler_pid" )
        capacity_sampler_ready "$rtmp_sampler_pid" "$case_dir/rtmp-sampler.ready" || return 1
    fi
    if [ "$srt_destinations" -gt 0 ] && [ "$quality_mode" = yes ]; then
        mapfile -t quality_worker_pids < <(worker_pids)
        rm -f "$case_dir/queue-sampler.ready" "$case_dir/queue-sampler.baseline"
        receiver_remove "$sink_snapshot_before" || return 1
        receiver_remove "$case_dir/receiver-sampler.ready" || return 1
        receiver_remove "$case_dir/receiver-sampler.ready.paused" || return 1
        python3 "$ROOT/tests/bench/srt_capacity_quality.py" \
            sample-queues "$HTTP_PORT" "$case_dir/queue-samples.csv" \
            "${quality_worker_pids[@]}" --interval 1 \
            --ready-file "$case_dir/queue-sampler.ready" \
            --baseline-ready "$case_dir/queue-sampler.baseline" \
            >"$case_dir/queue-sampler.log" 2>&1 &
        queue_sampler_pid="$!"
        QUALITY_MONITORS+=( "$queue_sampler_pid" )
        receiver_start "$case_dir/srt-sampler.identity.json" "$case_dir/receiver-sampler.log" \
            python3 "$ROOT/tests/bench/srt_capacity_quality.py" \
            sample-receivers "${sink_pid#r}" "$sink_csv.snapshot" \
            "$sink_snapshot_before" "$case_dir/receiver-intervals.csv" \
            --interval 1 --ready-file "$case_dir/receiver-sampler.ready" || return 1
        receiver_sampler_pid="$RECEIVER_PID"
        QUALITY_MONITORS+=( "$receiver_sampler_pid" )
        capacity_sampler_ready "$receiver_sampler_pid" "$case_dir/receiver-sampler.ready" || return 1
        capacity_sampler_ready "$queue_sampler_pid" "$case_dir/queue-sampler.ready" || return 1
    fi
    measure_start="$(python3 -c 'import time; print(time.monotonic_ns())')"
    for name in "${names[@]}"; do
        owner_metrics "$name" > "$case_dir/stream.$name.before" \
            || { echo "could not capture baseline for $name" >&2; return 1; }
    done
    measure_end="$(python3 -c 'import time; print(time.monotonic_ns())')"
    capacity_controller_boundary "$case_dir/stream.measurement.window" start \
        "$measure_start" "$measure_end" "controller stream-counter collection brackets" || return 1
    capacity_socket_snapshot "$case_dir/before" || return 1
    capacity_memory_snapshot "$case_dir/memory.before" || return 1
    measure_start="$(python3 -c 'import time; print(time.monotonic_ns())')"
    capacity_worker_metrics "$case_dir/workers.before" || return 1
    measure_end="$(python3 -c 'import time; print(time.monotonic_ns())')"
    capacity_controller_boundary "$case_dir/workers.measurement.window" start \
        "$measure_start" "$measure_end" "controller worker-metric collection brackets" || return 1
    capacity_window_boundary() {
        local action="$1" suffix=before phase=start job status=0 attempt ready client
        local -a captures=() ready_files=() clients=()
        trap '
            for ready in "${ready_files[@]}"; do
                if [ -s "$ready.pid" ]; then
                    read -r client <"$ready.pid"
                    kill "$client" 2>/dev/null || true
                fi
            done
            for job in "${captures[@]}"; do kill "$job" 2>/dev/null || true; done
            for job in "${captures[@]}"; do wait "$job" 2>/dev/null || true; done
        ' EXIT
        trap 'exit 1' TERM INT
        if [ "$action" = stop ]; then
            suffix=after
            phase=end
        fi
        if [ "$rtmp_destinations" -gt 0 ]; then
            (
                CAPTURE_READY_FILE="$CPU_CAPTURE_READY_DIR/rtmp.ready"
                if [ "$action" = stop ] && [ "$quality_mode" = yes ]; then
                    kill -USR2 "$rtmp_sampler_pid" || exit 1
                    capacity_sampler_ready "$rtmp_sampler_pid" \
                        "$case_dir/rtmp-sampler.ready.paused" || exit 1
                fi
                capacity_capture_gate || exit 1
                capacity_rtmp_sink_metrics "$case_dir/rtmp-receiver.$suffix" || exit 1
                if [ "$action" = start ] && [ "$quality_mode" = yes ]; then
                    : >"$case_dir/rtmp-sampler.baseline"
                fi
            ) &
            captures+=( "$!" )
            ready_files+=( "$CPU_CAPTURE_READY_DIR/rtmp.ready" )
        fi
        if [ "$srt_destinations" -gt 0 ]; then
            if [ "$quality_mode" = yes ]; then
                local sampler=""
                [ "$action" != stop ] || sampler="$receiver_sampler_pid"
                CAPTURE_READY_FILE="$CPU_CAPTURE_READY_DIR/srt.ready" \
                    capacity_srt_measurement_snapshot "$sink_pid" "$sink_csv.snapshot" \
                    "$case_dir/srt.$suffix.csv" "$action" "$sampler" "$receiver_clock" &
            else
                CAPTURE_READY_FILE="$CPU_CAPTURE_READY_DIR/srt.ready" \
                    capacity_srt_receiver_snapshot "$sink_pid" "$sink_csv.snapshot" \
                    "$case_dir/srt.$suffix.csv" &
            fi
            captures+=( "$!" )
            ready_files+=( "$CPU_CAPTURE_READY_DIR/srt.ready" )
        fi
        if [ "$hls_push_destinations" -gt 0 ]; then
            CAPTURE_READY_FILE="$CPU_CAPTURE_READY_DIR/hls_push.ready" \
                capacity_hls_push_snapshot "$hls_push_sink_port" \
                "$case_dir/hls-push.$suffix.json" "$phase" "$hls_push_sink_pid" &
            captures+=( "$!" )
            ready_files+=( "$CPU_CAPTURE_READY_DIR/hls_push.ready" )
        fi
        if [ -n "$hls_pid" ]; then
            CAPTURE_READY_FILE="$CPU_CAPTURE_READY_DIR/hls_readers.ready" \
                capacity_hls_reader_boundary "$hls_pid" "$hls_report_file" "$phase" &
            captures+=( "$!" )
            ready_files+=( "$CPU_CAPTURE_READY_DIR/hls_readers.ready" )
        fi
        for (( attempt=0; attempt<12000; attempt++ )); do
            status=0
            for job in "${captures[@]}"; do
                kill -0 "$job" 2>/dev/null || exit 1
            done
            for ready in "${ready_files[@]}"; do
                if [ -s "$ready.pid" ]; then
                    read -r client <"$ready.pid"
                    kill -0 "$client" 2>/dev/null || exit 1
                else
                    status=1
                fi
                [ -f "$ready" ] || status=1
            done
            [ "$status" -ne 0 ] || break
            sleep 0.005
        done
        [ "$status" -eq 0 ] || exit 1
        for ready in "${ready_files[@]}"; do
            read -r client <"$ready.pid" || exit 1
            clients+=( "$client" )
        done
        CAPTURE_READY_FILE="$CPU_CAPTURE_READY_DIR/protocols.ready" \
            capacity_capture_gate "${captures[@]}" "${clients[@]}" || exit 1
        if [ "$action" = start ] && [ "$srt_destinations" -gt 0 ] \
            && [ "$quality_mode" = yes ]; then
            : >"$case_dir/queue-sampler.baseline" || exit 1
        fi
        for job in "${captures[@]}"; do
            wait "$job" || status=1
        done
        captures=()
        ready_files=()
        exit "$status"
    }
    capacity_write_processes "$case_dir/processes.tsv" "$sink_pid" \
        "$hls_pid" "$hls_push_sink_pid"
    CPU_SNAPSHOT_DIR="$case_dir"
    CPU_BOUNDARY_CALLBACK=capacity_window_boundary
    cpu_window "$seconds" "$sink_pid" "$hls_pid" "$hls_push_sink_pid" \
        ${RTMP_SINK_PIDS[@]+"${RTMP_SINK_PIDS[@]}"} "${PUBS[@]}" || return 1
    CPU_SNAPSHOT_DIR=""
    CPU_BOUNDARY_CALLBACK=""
    unset -f capacity_window_boundary
    capacity_quality_stop_monitors || {
        echo "a capacity monitor failed during the measurement" >&2
        return 1
    }
    if [ "$quality_mode" = yes ]; then
        for publisher_pid in "${PUBS[@]}"; do
            kill -0 "$publisher_pid" 2>/dev/null \
                || { echo "a capacity publisher exited during the window" \
                     >&2; return 1; }
        done
        kill_pubs
    fi

    for publisher_pid in "${PUBS[@]}"; do
        kill -0 "$publisher_pid" 2>/dev/null \
            || { echo "a capacity publisher exited during the window" \
                 >&2; return 1; }
    done
    measure_start="$(python3 -c 'import time; print(time.monotonic_ns())')"
    for name in "${names[@]}"; do
        owner_metrics "$name" > "$case_dir/stream.$name.after" \
            || { echo "could not capture final metrics for $name" >&2; return 1; }
    done
    measure_end="$(python3 -c 'import time; print(time.monotonic_ns())')"
    measure_seconds="$(capacity_controller_boundary "$case_dir/stream.measurement.window" end \
        "$measure_start" "$measure_end" "controller stream-counter collection brackets")" || return 1
    measure_start="$(python3 -c 'import time; print(time.monotonic_ns())')"
    capacity_worker_metrics "$case_dir/workers.after" || return 1
    measure_end="$(python3 -c 'import time; print(time.monotonic_ns())')"
    capacity_controller_boundary "$case_dir/workers.measurement.window" end \
        "$measure_start" "$measure_end" "controller worker-metric collection brackets" >/dev/null || return 1
    capacity_socket_snapshot "$case_dir/after" || return 1
    capacity_memory_snapshot "$case_dir/memory.after" || return 1

    echo "   measurement_s=$measure_seconds requested_window_s=$seconds" \
         "stream_counter_measurement_window_s=$measure_seconds cpu_window_s=$W_DUR" \
         "cpu_sampling_before_ms=$W_CPU_BEFORE_MS" \
         "cpu_sampling_after_ms=$W_CPU_AFTER_MS"
    echo "   measurement_provenance=controller-stream-counter-collection-brackets"

    for (( index = 0; index < programs; index++ )); do
        name="${names[$index]}"
        slot="${owners[$index]}"
        before_frames="$(capacity_json_field "$case_dir/stream.$name.before" \
            program_frames)"
        after_frames="$(capacity_json_field "$case_dir/stream.$name.after" \
            program_frames)"
        before_dispatched="$(capacity_json_field \
            "$case_dir/stream.$name.before" dispatched)"
        after_dispatched="$(capacity_json_field \
            "$case_dir/stream.$name.after" dispatched)"
        dispatched_delta=$(( after_dispatched - before_dispatched ))

        read -r -a counts_before <<< "$(
            capacity_json_field "$case_dir/stream.$name.before" \
                fanout_ms.bucket_counts
        )"
        read -r -a counts_after <<< "$(
            capacity_json_field "$case_dir/stream.$name.after" \
                fanout_ms.bucket_counts
        )"
        read -r -a bounds <<< "$(
            capacity_json_field "$case_dir/stream.$name.after" \
                fanout_ms.bucket_upper_ms
        )"
        if (( ${#counts_before[@]} != 16 ||
              ${#counts_after[@]} != 16 ||
              ${#bounds[@]} != 16 )); then
            echo "$name returned an invalid fanout histogram" >&2
            return 1
        fi

        bucket_total=0
        bins_text=""
        for (( attempt = 0; attempt < 16; attempt++ )); do
            value=$(( counts_after[attempt] - counts_before[attempt] ))
            [ "$value" -ge 0 ] \
                || { echo "$name fanout bucket counter regressed" \
                         >&2; return 1; }
            bucket_total=$(( bucket_total + value ))
            high="${bounds[$attempt]}"
            if [ "$attempt" -eq 0 ]; then
                low=0
            else
                low=$(( bounds[attempt - 1] + 1 ))
            fi
            if [ "$low" -eq "$high" ]; then
                bin_label="$low"
            else
                bin_label="$low-$high"
            fi
            [ -z "$bins_text" ] || bins_text+=","
            bins_text+="$bin_label:$value"
        done
        [ "$bucket_total" -eq "$dispatched_delta" ] \
            || { echo "$name fanout histogram has $bucket_total samples, " \
                     "but dispatched delta is $dispatched_delta" >&2; return 1; }
        [ "$dispatched_delta" -gt 0 ] \
            || { echo "$name produced no fanout samples" >&2; return 1; }

        fanout_max="$(capacity_json_field "$case_dir/stream.$name.after" \
            fanout_ms.max)"
        metrics_before="$(<"$case_dir/stream.$name.before")"
        metrics_after="$(<"$case_dir/stream.$name.after")"
        p50="$(capacity_percentile "$case_dir/stream.$name.after" "$name" 50)"
        p95="$(capacity_percentile "$case_dir/stream.$name.after" "$name" 95)"
        p99="$(capacity_percentile "$case_dir/stream.$name.after" "$name" 99)"
        p999="$(capacity_percentile "$case_dir/stream.$name.after" "$name" 99.9)"
        feed_units="$(blob_label_metric "$metrics_after" \
            nginx_media_stream_feed_units "$name")"
        feed_bytes="$(blob_label_metric "$metrics_after" \
            nginx_media_stream_feed_bytes "$name")"
        feed_high_units="$(blob_label_metric "$metrics_after" \
            nginx_media_stream_feed_high_water_units "$name")"
        feed_high_bytes="$(blob_label_metric "$metrics_after" \
            nginx_media_stream_feed_high_water_bytes "$name")"
        feed_overruns_before="$(blob_label_metric "$metrics_before" \
            nginx_media_stream_feed_overruns_total "$name")"
        feed_overruns_after="$(blob_label_metric "$metrics_after" \
            nginx_media_stream_feed_overruns_total "$name")"
        feed_overruns=$(( ${feed_overruns_after:-0} \
                        - ${feed_overruns_before:-0} ))
        feed_evictions_before="$(blob_label_metric "$metrics_before" \
            nginx_media_stream_feed_evictions_total "$name")"
        feed_evictions_after="$(blob_label_metric "$metrics_after" \
            nginx_media_stream_feed_evictions_total "$name")"
        feed_evictions=$(( ${feed_evictions_after:-0} \
                         - ${feed_evictions_before:-0} ))
        source_frames_before="$(blob_source_metric "$metrics_before" \
            nginx_media_source_frames_in "$name")"
        source_frames_after="$(blob_source_metric "$metrics_after" \
            nginx_media_source_frames_in "$name")"
        source_frames=$(( ${source_frames_after:-0} \
                        - ${source_frames_before:-0} ))
        frame_delta=$(( after_frames - before_frames ))
        [ "$frame_delta" -gt 0 ] \
            || { echo "$name made no program progress" >&2; return 1; }
        progress_frames+=( "$frame_delta" )
        frame_rate="$(awk -v f="$frame_delta" -v s="$measure_seconds" \
            'BEGIN { printf "%.1f", f / s }')"

        echo "   $name owner=w$slot source_frames=$source_frames"
        echo "      program_frames=$frame_delta"
        echo "      progress_fps=$frame_rate fanout_samples=$dispatched_delta"
        echo "      fanout_p50/p95/p99/p99.9=${p50:-0}/${p95:-0}/${p99:-0}/${p999:-0}ms"
        echo "      fanout.max=$fanout_max ms buckets_ms=[$bins_text]"
        echo "      feed_retained=${feed_units:-0}u/${feed_bytes:-0}B"
        echo "      feed_high_water=${feed_high_units:-0}u/${feed_high_bytes:-0}B"
        echo "      feed_evictions_delta=$feed_evictions"
        echo "      feed_overruns_delta=$feed_overruns"
    done

    fairness="$(python3 - "${progress_frames[@]}" <<'PY'
import sys

frames = [int(value) for value in sys.argv[1:]]
total = sum(frames)
squares = sum(value * value for value in frames)
print(f"{total * total / (len(frames) * squares):.4f}" if squares else "0")
PY
)"
    echo "   program_frame_fairness_jain=$fairness (1.0 is equal progress)"
    if [ "$srt_destinations" -gt 0 ]; then
        if receiver_alive "$sink_pid"; then
            receiver_kill -TERM "$sink_pid" 2>/dev/null || true
        fi
        if ! receiver_wait "$sink_pid"; then
            echo "shared SRT receiver did not stop cleanly" >&2
            return 1
        fi
        SINKS=()
        [ -n "$hls_push_sink_pid" ] && SINKS+=( "$hls_push_sink_pid" )
        receiver_collect "$case_dir" || return 1
        [ -s "$sink_csv" ] \
            || { echo "shared SRT receiver produced no result CSV" >&2; return 1; }
        if [ "$quality_mode" = yes ]; then
            echo "   per-destination rates, MPEG-TS counters, and queue quality:"
        else
            capacity_srt_csv_report "$sink_csv" "$programs" "$srt_destinations" \
                "$stall_id" "$sink_snapshot_before" "$sink_snapshot_after" \
                > "$case_dir/receiver-report.txt" || return 1
            echo "   receiver-delivered SRT payload bytes in measured window, per destination:"
            cat "$case_dir/receiver-report.txt"
        fi
        receiver_collect "$case_dir" || return 1
        if [ "$quality_mode" = yes ]; then
            quality_report_file="$case_dir/quality-report.txt"
            quality_reference_bps="${CAPACITY_QUALITY_REFERENCE_BPS:-0}"
            python3 "$ROOT/tests/bench/srt_capacity_quality.py" report \
                --clock-domain "$receiver_clock" \
                --baseline "$sink_snapshot_before" \
                --final "$sink_snapshot_after" \
                --intervals "$case_dir/receiver-intervals.csv" \
                --queues "$case_dir/queue-samples.csv" \
                --queue-window "$case_dir/receiver.measurement.window" \
                --receiver-results "$sink_csv" \
                --metrics-before "$case_dir/workers.before" \
                --metrics-after "$case_dir/workers.after" \
                --stream-before "$case_dir/stream.$name.before" \
                --stream-after "$case_dir/stream.$name.after" \
                --destination-report "$case_dir/destination-quality.csv" \
                --interval-report "$case_dir/interval-throughput.csv" \
                --destinations "$srt_destinations" \
                --programs "$programs" \
                --prepared-source "$source" \
                --source-duration-s 30 \
                --reference-bps "$quality_reference_bps" \
                --min-delivery-ratio "$CAPACITY_QUALITY_MIN_DELIVERY_RATIO" \
                --interval-floor "$CAPACITY_QUALITY_INTERVAL_FLOOR" \
                --max-low-s "$CAPACITY_QUALITY_MAX_LOW_SECONDS" \
                --max-interval-s 2 \
                --queue-pressure "$CAPACITY_QUALITY_QUEUE_PRESSURE" \
                --pressure-samples "$CAPACITY_QUALITY_PRESSURE_SAMPLES" \
                --blocked-samples "$CAPACITY_QUALITY_BLOCKED_SAMPLES" \
                > "$quality_report_file" || return 1
            cat "$quality_report_file"
            echo "   destination_quality_csv=$case_dir/destination-quality.csv"
            echo "   interval_throughput_csv=$case_dir/interval-throughput.csv"
            quality_status="$(awk -F= '$1 == "quality_pass" { print $2; exit }' \
                "$quality_report_file")"
            case "$quality_status" in
                yes|no) ;;
                *) echo "quality analyzer returned no status" >&2; return 1 ;;
            esac
            if [ "$quality_reference_bps" = 0 ]; then
                capacity_store_reference CAPACITY_QUALITY_REFERENCE_BPS \
                    quality "SRT" "$quality_status" "$(awk -F= \
                    '$1 == "quality_reference_payload_bps" { print $2; exit }' \
                    "$quality_report_file")" || return 1
            fi
            [ "$quality_status" = yes ] || quality_failed=1
        fi
    fi
    if [ "$rtmp_destinations" -gt 0 ]; then
        if [ "$quality_mode" = yes ]; then
            rtmp_reference_bps="${CAPACITY_QUALITY_REFERENCE_RTMP_BPS:-0}"
            rtmp_report_file="$case_dir/rtmp-quality.txt"
            python3 "$ROOT/tests/bench/rtmp_capacity_quality.py" \
                --before-prefix "$case_dir/rtmp-receiver.before" \
                --after-prefix "$case_dir/rtmp-receiver.after" \
                --queue-before-prefix "$case_dir/workers.before" \
                --queue-after-prefix "$case_dir/workers.after" \
                --programs "$programs" \
                --destinations "$rtmp_destinations" \
                --destination-offset "$srt_destinations" \
                --measurement-s "$measure_seconds" \
                --intervals "$case_dir/rtmp-receiver-intervals.csv" \
                --interval-floor "$CAPACITY_QUALITY_INTERVAL_FLOOR" \
                --max-low-s "$CAPACITY_QUALITY_MAX_LOW_SECONDS" \
                --reference-bps "$rtmp_reference_bps" \
                --prepared-media "$case_dir/prepared-media.json" \
                --min-delivery-ratio "$CAPACITY_QUALITY_MIN_DELIVERY_RATIO" \
                --report "$case_dir/rtmp-quality.csv" \
                > "$rtmp_report_file" || return 1
            cat "$rtmp_report_file"
            echo "   rtmp_destination_quality_csv=$case_dir/rtmp-quality.csv"
            quality_status="$(awk -F= '$1 == "quality_pass" { print $2; exit }' \
                "$rtmp_report_file")"
            case "$quality_status" in
                yes|no) ;;
                *) echo "RTMP quality analyzer returned no status" >&2; return 1 ;;
            esac
            if [ "$rtmp_reference_bps" = 0 ]; then
                capacity_store_reference CAPACITY_QUALITY_REFERENCE_RTMP_BPS \
                    rtmp_quality "RTMP" "$quality_status" "$(awk -F= \
                    '$1 == "quality_reference_payload_bps" { print $2; exit }' \
                    "$rtmp_report_file")" || return 1
            fi
            [ "$quality_status" = yes ] || quality_failed=1
        else
            capacity_rtmp_payload_report "$case_dir/rtmp-receiver.before" \
                "$case_dir/rtmp-receiver.after" "$programs" "$rtmp_destinations" \
                "$srt_destinations" > "$case_dir/rtmp-receiver-report.txt" \
                || return 1
            echo "   receiver-delivered RTMP payload bytes (per destination):"
            cat "$case_dir/rtmp-receiver-report.txt"
        fi
    fi
    if [ "$hls_readers" -gt 0 ]; then
        receiver_fetch "$hls_report_file" || return 1
        python3 "$ROOT/tests/bench/hls_capacity_readers.py" judge \
            --report "$hls_report_file" \
            --prepared-media "$case_dir/prepared-media.json" \
            --produced-segments "$case_dir/hls-production.json" \
            --measurement-window "$case_dir/cpu.before" "$case_dir/cpu.after" \
            --receiver-window "$case_dir/hls-readers.measurement.window" \
            --clock-domain "$receiver_clock" \
            --reference-bps "${CAPACITY_QUALITY_REFERENCE_HLS_BPS:-0}" \
            --min-delivery-ratio "$CAPACITY_QUALITY_MIN_DELIVERY_RATIO" \
            >>"$hls_log" || return 1
        [ -s "$hls_report_file" ] \
            || { cat "$hls_log" >&2; echo "HLS reader quality report is missing" >&2; return 1; }
        cat "$hls_log"
        echo "   hls_destination_quality_csv=$hls_report_file"
        quality_status="$(awk -F= '$1 == "quality_pass" { print $2; exit }' \
            "$hls_log")"
        case "$quality_status" in
            yes|no) ;;
            *) echo "HLS quality analyzer returned no status" >&2; return 1 ;;
        esac
        hls_reference_bps="${CAPACITY_QUALITY_REFERENCE_HLS_BPS:-0}"
        if [ "$hls_reference_bps" = 0 ]; then
            capacity_store_reference CAPACITY_QUALITY_REFERENCE_HLS_BPS \
                hls_quality "HLS" "$quality_status" "$(awk -F= \
                '$1 == "reference_bps" { print $2; exit }' "$hls_log")" \
                || return 1
        fi
        [ "$quality_status" = yes ] || quality_failed=1
    fi
    if [ "$hls_push_destinations" -gt 0 ]; then
        hls_push_quality_report="$case_dir/hls-push-quality.txt"
        hls_push_reference_bps="${CAPACITY_QUALITY_REFERENCE_HLS_PUSH_BPS:-0}"
        python3 "$ROOT/tests/bench/hls_push_capacity.py" report \
            --before-prefix "$case_dir/workers.before" \
            --after-prefix "$case_dir/workers.after" \
            --stream "${names[0]}" \
            --destination-offset "$((srt_destinations + rtmp_destinations))" \
            --destinations "$hls_push_destinations" \
            --programs "$programs" \
            --sink-before "$case_dir/hls-push.before.json" \
            --sink-after "$case_dir/hls-push.after.json" \
            --reference-bps "$hls_push_reference_bps" \
            --prepared-media "$case_dir/prepared-media.json" \
            --produced-segments "$case_dir/hls-production.json" \
            --measurement-window "$case_dir/cpu.before" "$case_dir/cpu.after" \
            --clock-domain "$receiver_clock" \
            --min-delivery-ratio "$CAPACITY_QUALITY_MIN_DELIVERY_RATIO" \
            --report "$case_dir/hls-push-quality.csv" \
            >"$hls_push_quality_report" || return 1
        cat "$hls_push_quality_report"
        echo "   hls_push_destination_quality_csv=$case_dir/hls-push-quality.csv"
        quality_status="$(awk -F= '$1 == "quality_pass" { print $2; exit }' \
            "$hls_push_quality_report")"
        case "$quality_status" in
            yes|no) ;;
            *) echo "HLS push quality analyzer returned no status" >&2; return 1 ;;
        esac
        if [ "$hls_push_reference_bps" = 0 ]; then
            capacity_store_reference CAPACITY_QUALITY_REFERENCE_HLS_PUSH_BPS \
                hls_push_quality "HLS push" "$quality_status" "$(awk -F= \
                '$1 == "quality_reference_payload_bps" { print $2; exit }' \
                "$hls_push_quality_report")" || return 1
        fi
        [ "$quality_status" = yes ] || quality_failed=1
    fi

    if [ "$srt_destinations" -gt 0 ]; then
        echo "   SRT sender-shard counters and queue snapshots:"
        capacity_srt_metrics_report "$case_dir/workers.before" \
            "$case_dir/workers.after" > "$case_dir/srt-shards.txt" \
            || return 1
        cat "$case_dir/srt-shards.txt"
        if [ -n "$stall_id" ]; then
            slow_drops="$(awk '
                {
                    for (i = 1; i <= NF; i++) {
                        if ($i ~ /^output_drops_delta=/) {
                            split($i, field, "=")
                            total += field[2]
                        }
                    }
                }
                END { print total + 0 }
            ' "$case_dir/srt-shards.txt")"
            [ "$slow_drops" -gt 0 ] \
                || { echo "slow SRT reader caused no destination-queue drops" \
                         >&2; return 1; }
            echo "   slow-reader destination queue drops=$slow_drops"
        fi
        echo "   sender shard CPU from /proc thread comm srt-egress-*:"
        report_cpu "$W_BEFORE" "$W_AFTER" "$W_DUR" \
            | awk '$2 ~ /^srt-egress-/ {
                       printf "      worker=%s thread=%s cpu=%.1f%%\n", $1, $2, $3
                       worker[$1] += $3
                       total += $3
                       count++
                   }
                   END {
                       if (!count) print "      no srt-egress-* thread rows"
                       for (slot in worker) {
                           printf "      worker=%s aggregate_egress_shard_cpu=%.1f%%\n",
                                  slot, worker[slot]
                       }
                       printf "      aggregate_egress_shard_cpu=%.1f%%\n", total
                   }'
        echo "   libsrt SRT:SndQ CPU:"
        report_cpu "$W_BEFORE" "$W_AFTER" "$W_DUR" \
            | awk '$2 == "SRT:SndQ" {
                       printf "      worker=%s cpu=%.1f%%\n", $1, $3
                       worker[$1] += $3
                       total += $3
                       count++
                   }
                   END {
                       if (!count) print "      no SRT:SndQ thread rows"
                       for (slot in worker) {
                           printf "      worker=%s aggregate_libsrt_sndq_cpu=%.1f%%\n",
                                  slot, worker[slot]
                       }
                       printf "      aggregate_libsrt_sndq_cpu=%.1f%%\n", total
                   }'
        echo "   shared SRT receiver thread CPU:"
        report_cpu "$W_BEFORE" "$W_AFTER" "$W_DUR" \
            | awk -v pid="pid$sink_pid" '
                $1 == pid {
                    printf "      pid=%s thread=%s cpu=%.1f%%\n", pid, $2, $3
                    total += $3
                    count++
                }
                END {
                    if (!count) print "      no receiver thread rows"
                    else printf "      aggregate_receiver_cpu=%.1f%%\n", total
                }'
    fi
    if [ "$hls_readers" -gt 0 ]; then
        echo "   HLS reader process CPU:"
        report_cpu "$W_BEFORE" "$W_AFTER" "$W_DUR" \
            | awk -v pid="pid$hls_pid" '
                $1 == pid {
                    printf "      pid=%s thread=%s cpu=%.1f%%\n", pid, $2, $3
                    total += $3
                    count++
                }
                END {
                    if (!count) print "      no HLS reader thread rows"
                    else printf "      aggregate_hls_reader_cpu=%.1f%%\n", total
                }'
    fi
    if [ -n "$hls_push_sink_pid" ]; then
        echo "   HLS push sink process CPU:"
        report_cpu "$W_BEFORE" "$W_AFTER" "$W_DUR" \
            | awk -v pid="pid$hls_push_sink_pid" '
                $1 == pid {
                    printf "      pid=%s thread=%s cpu=%.1f%%\n", pid, $2, $3
                    total += $3
                    count++
                }
                END {
                    if (!count) print "      no HLS push sink process rows"
                    else printf "      aggregate_hls_push_sink_cpu=%.1f%%\n", total
                }'
    fi
    echo "   worker process RSS/PSS from smaps_rollup:"
    capacity_memory_report "$case_dir/memory.before" "$case_dir/memory.after"


    echo "   worker visit and scheduling metrics:"
    worker_cpu_total=0
    for worker_pid in $(worker_pids); do
        worker_slot="$(slot_name "$worker_pid")"
        worker_before="$case_dir/workers.before.$worker_pid"
        worker_after="$case_dir/workers.after.$worker_pid"
        cpu_pct="$(capacity_worker_cpu "$W_BEFORE" "$W_AFTER" "$W_DUR" \
            "$worker_slot")"
        worker_cpu_total="$(awk -v a="$worker_cpu_total" -v b="$cpu_pct" \
            'BEGIN { printf "%.1f", a + b }')"
        budget_before="$(capacity_metric "$worker_before" \
            nginx_media_worker_budget_reposts_total)"
        budget_after="$(capacity_metric "$worker_after" \
            nginx_media_worker_budget_reposts_total)"
        visits_before="$(capacity_metric "$worker_before" \
            nginx_media_worker_periodic_visits_total)"
        visits_after="$(capacity_metric "$worker_after" \
            nginx_media_worker_periodic_visits_total)"
        late_before="$(capacity_metric "$worker_before" \
            nginx_media_worker_late_ticks_total)"
        late_after="$(capacity_metric "$worker_after" \
            nginx_media_worker_late_ticks_total)"
        max_service="$(capacity_metric "$worker_after" \
            nginx_media_worker_max_service_ms)"
        event_delay="$(capacity_metric "$worker_after" \
            nginx_media_worker_event_loop_max_delay_ms)"
        echo "      $worker_slot pid=$worker_pid cpu=${cpu_pct}%"
        echo "         visit_max=${max_service:-0}ms event_loop_max_delay=${event_delay:-0}ms"
        echo "         periodic_visits_delta=$(( ${visits_after:-0} - ${visits_before:-0} ))"
        echo "         budget_reposts_delta=$(( ${budget_after:-0} - ${budget_before:-0} ))"
        echo "         late_ticks_delta=$(( ${late_after:-0} - ${late_before:-0} ))"
    done
    echo "      aggregate_worker_cpu=${worker_cpu_total}% of one core"
    if [ -n "$RTMP_SINK_WORKER_PID" ]; then
        echo "      RTMP sink CPU=$(report_cpu "$W_BEFORE" "$W_AFTER" "$W_DUR" \
            | awk '$1 ~ /^wrtmp-sink-/ { t += $3 } END { printf "%.1f", t }')% of one core ($RTMP_SINK_COUNT separate receiver workers)"
    fi

    echo "   NGINX socket skmem (ss -m):"
    for worker_pid in $(worker_pids); do
        worker_slot="$(slot_name "$worker_pid")"
        socket_before="$(awk -v pid="$worker_pid" '$1 == pid { print $7; exit }' \
            "$case_dir/before")"
        socket_after="$(awk -v pid="$worker_pid" '$1 == pid { print $7; exit }' \
            "$case_dir/after")"
        [ -n "$socket_before" ] || socket_before=0
        [ -n "$socket_after" ] || socket_after=0
        socket_row="$(awk -v pid="$worker_pid" '$1 == pid { print $6; exit }' \
            "$case_dir/after")"
        [ -n "$socket_row" ] || socket_row=0
        echo "      $worker_slot sockets=$socket_row skmem_bytes=$socket_after delta_bytes=$(( socket_after - socket_before ))"
    done
    sock_tcp_before="$(capacity_sockstat_value "$case_dir/before.sockstat" TCP: mem)"
    sock_tcp_after="$(capacity_sockstat_value "$case_dir/after.sockstat" TCP: mem)"
    sock_udp_before="$(capacity_sockstat_value "$case_dir/before.sockstat" UDP: mem)"
    sock_udp_after="$(capacity_sockstat_value "$case_dir/after.sockstat" UDP: mem)"
    tcp_inuse_before="$(capacity_sockstat_value "$case_dir/before.sockstat" TCP: inuse)"
    tcp_inuse_after="$(capacity_sockstat_value "$case_dir/after.sockstat" TCP: inuse)"
    udp_inuse_before="$(capacity_sockstat_value "$case_dir/before.sockstat" UDP: inuse)"
    udp_inuse_after="$(capacity_sockstat_value "$case_dir/after.sockstat" UDP: inuse)"
    echo "   host /proc/net/sockstat (global, not process-attributed):"
    echo "      TCP mem_pages=${sock_tcp_before:-0}->${sock_tcp_after:-0}"
    echo "      UDP mem_pages=${sock_udp_before:-0}->${sock_udp_after:-0}"
    echo "      TCP inuse=${tcp_inuse_before:-0}->${tcp_inuse_after:-0}"
    echo "      UDP inuse=${udp_inuse_before:-0}->${udp_inuse_after:-0}"

    local outcome=measured
    if [ "$quality_mode" = yes ]; then
        outcome=pass
        [ "$quality_failed" -eq 0 ] || outcome=quality-failure
    fi
    local -a preflight_meta=()
    [ -z "$preflight_note" ] \
        || preflight_meta+=( preflight_verdict="$preflight_note" )
    capacity_write_diagnostics "$case_dir" "$outcome" \
        destinations="$destinations" programs="$programs" rate="$rate" \
        protocol="$protocol" srt="$srt_destinations" \
        rtmp="$rtmp_destinations" hls_readers="$hls_readers" \
        hls_push="$hls_push_destinations" hls="$hls_enabled" \
        workers="$workers" measurement_s="$measure_seconds" \
        measurement_provenance=controller-stream-counter-collection-brackets \
        requested_s="$seconds" ${preflight_meta[@]+"${preflight_meta[@]}"}

    kill_pubs
    for receiver_pid in "${SINKS[@]}"; do kill_one "$receiver_pid"; done
    SINKS=()
    stop_instance
    stop_rtmp_sink_instance
    if [ "$quality_mode" = yes ] && [ "$quality_failed" -ne 0 ]; then
        return 2
    fi
}

# Fetch receiver-side artifacts back when the receivers run on another host.
# The receivers write into the case directory; over a shared filesystem (the
# default, and the namespace topology) they are already here.  For a split
# run, CAPACITY_RECEIVER_COLLECT is a command that copies them back, run
# after the path probe and before the quality reports are read.
receiver_collect() {   # <case dir>
    if [ -n "$CAPACITY_RECEIVER_CONFIG" ]; then
        receiver_transport collect "$1"
        return $?
    fi
    [ -n "$CAPACITY_RECEIVER_COLLECT" ] || return 0
    sh -c "$CAPACITY_RECEIVER_COLLECT" _ "$1" \
        || { echo "could not collect receiver artifacts for $1" >&2; return 1; }
}

# Whether a file the receivers write exists yet.  Over a shared filesystem
# it is already here; with the receivers on another host,
# CAPACITY_RECEIVER_FILE_TEST is a shell snippet that tests it there, e.g.
#   CAPACITY_RECEIVER_FILE_TEST='ssh -o BatchMode=yes receiver test -f "$1"'
# The receivers publish a ready file by creating it, and an empty one is
# still a ready receiver: existence, never size.
receiver_file_ready() {   # <path>
    if [ -n "$CAPACITY_RECEIVER_CONFIG" ]; then
        receiver_transport exists "$1" 2>/dev/null
        return $?
    fi
    [ -n "$CAPACITY_RECEIVER_FILE_TEST" ] \
        || { [ -f "$1" ]; return $?; }
    sh -c "$CAPACITY_RECEIVER_FILE_TEST" _ "$1" 2>/dev/null
}

# Create a directory where the receivers run.  A shared filesystem has it
# already; with the receivers on another host, CAPACITY_RECEIVER_MKDIR is a
# shell snippet that creates the path it is given as $1.
receiver_mkdir() {   # <path>
    if [ -n "$CAPACITY_RECEIVER_CONFIG" ]; then
        receiver_transport mkdir "$1"
        return $?
    fi
    [ -n "$CAPACITY_RECEIVER_MKDIR" ] || return 0
    sh -c "$CAPACITY_RECEIVER_MKDIR" _ "$1" \
        || { echo "could not create $1 on the receiver host" >&2; return 1; }
}

# Fetch one receiver-written file back.  Unset means it is already here, so
# the local and namespace topologies pay nothing for this.
receiver_fetch() {   # <path>
    if [ -n "$CAPACITY_RECEIVER_CONFIG" ]; then
        receiver_transport fetch "$1"
        return $?
    fi
    [ -n "$CAPACITY_RECEIVER_FETCH" ] || return 0
    sh -c "$CAPACITY_RECEIVER_FETCH" _ "$1" \
        || { echo "could not fetch $1 from the receiver host" >&2; return 1; }
}

# What a rung costs per delivered Gbit/s, measured by the rungs that ran
# before it.  A core count cannot say how much CPU a Gbit/s needs, so the
# CPU half of the judgement is calibrated from the last rung that passed
# with a delivery number - never from a model, and never silently: the
# figure is written next to the preflight it was used for.
capacity_preflight_calibration() {   # <case dir>
    local case_dir="$1" bundle

    [ -n "$CAPACITY_PREFLIGHT_SENDER_CPU_PER_GBPS" ] \
        && [ -n "$CAPACITY_PREFLIGHT_RECEIVER_CPU_PER_GBPS" ] && return 0
    # A CPU per delivered Gbit/s is a property of the workload, so the
    # calibration only reads bundles from the same mix: carrying pure SRT's
    # cost into a pure RTMP ladder would judge one workload by another's.
    local mix_label="${case_dir##*/}"
    mix_label="${mix_label#quality-}"
    mix_label="${mix_label%-*}"
    bundle="$(ls -1t "$RUN"/capacity/quality-$mix_label-*/diagnostics.json \
              2>/dev/null | while read -r candidate; do
                    [ "$candidate" = "$case_dir/diagnostics.json" ] && continue
                    grep -q '"outcome": "pass"' "$candidate" && { echo "$candidate"; break; }
                done)"
    [ -n "$bundle" ] || return 0
    local values
    values="$(python3 - "$bundle" <<'PY'
import json, sys
bundle = json.load(open(sys.argv[1]))
eff = bundle.get("efficiency") or {}
def value(name):
    field = eff.get(name) or {}
    return field.get("value") if field.get("status") == "ok" else None
print(value("sender_cpu_per_gbps") or "", value("receiver_cpu_per_gbps") or "")
PY
)"
    set -- $values
    [ -n "${1:-}" ] && [ -z "$CAPACITY_PREFLIGHT_SENDER_CPU_PER_GBPS" ] \
        && CAPACITY_PREFLIGHT_SENDER_CPU_PER_GBPS="$1"
    [ -n "${2:-}" ] && [ -z "$CAPACITY_PREFLIGHT_RECEIVER_CPU_PER_GBPS" ] \
        && CAPACITY_PREFLIGHT_RECEIVER_CPU_PER_GBPS="$2"
    [ -z "$CAPACITY_PREFLIGHT_SENDER_CPU_PER_GBPS" ] \
        || echo "   preflight: calibrated from $(basename "$(dirname "$bundle")")" \
                "(sender ${CAPACITY_PREFLIGHT_SENDER_CPU_PER_GBPS}%core/Gbit/s," \
                "receiver ${CAPACITY_PREFLIGHT_RECEIVER_CPU_PER_GBPS:-?}%core/Gbit/s)"
    return 0
}

# Preflight: fingerprint the sender, the receivers and the path between
# them, and decide whether this rung can be measured at all before spending
# its window on it.  A host or a path that cannot carry the offered load is
# recorded as infrastructure-limited with the measurement that says so -
# never as a capacity result about nginx, and never as a sender failure.
capacity_preflight_rung() {   # <case dir> <destinations> <rate Mbit/s>
    local case_dir="$1" destinations="$2" rate="$3"
    local seconds="$CAPACITY_PREFLIGHT_SECONDS"
    local threads="$CAPACITY_PREFLIGHT_THREADS"
    local probe_port=$(( BASE + 40 ))
    local rate_bps
    local -a judge_args=()

    case "$CAPACITY_PREFLIGHT" in
        no) return 0 ;;
        auto)
            [ "$destinations" -ge "$CAPACITY_PREFLIGHT_MIN_DESTINATIONS" ] \
                || return 0
            ;;
        yes) ;;
        *) echo "CAPACITY_PREFLIGHT must be auto, yes or no" >&2; return 1 ;;
    esac

    command -v python3 >/dev/null \
        || { echo "python3 is required for the preflight" >&2; return 1; }
    mkdir -p "$case_dir"
    echo "   preflight: sender, receiver and path fingerprint for $destinations destinations"
    # Each fingerprint runs where its role runs, so `permitted_cpus` is that
    # role's affinity - nginx's, the receivers', not this shell's.  The judge
    # is told the configured sets as well, since a fingerprint taken through
    # ssh sees the ssh session's affinity.
    $(pin "$CAPACITY_NGINX_CPUS") \
        python3 "$ROOT/tests/bench/capacity_preflight.py" host --role sender \
        --binary "$NGINX" --json "$case_dir/preflight.sender.json" \
        >"$case_dir/preflight.sender.log" 2>&1 \
        || { echo "preflight: sender fingerprint failed" >&2; return 1; }
    receiver_run python3 "$ROOT/tests/bench/capacity_preflight.py" \
        host --role receiver --binary "$(receiver_path "$RUN/srt_fanout_sink")" \
        --json "$case_dir/preflight.receiver.json" \
        >"$case_dir/preflight.receiver.log" 2>&1 \
        || { echo "preflight: receiver fingerprint failed" >&2; return 1; }
    receiver_remove "$case_dir/preflight.rx.json" || return 1
    rm -f "$case_dir/preflight.tx.json"
    receiver_start "$case_dir/probe.identity.json" "$case_dir/preflight.rx.log" \
        python3 "$ROOT/tests/bench/capacity_preflight.py" probe \
        --listen --port "$probe_port" --seconds "$seconds" --threads "$threads" \
        --json "$case_dir/preflight.rx.json" || return 1
    local rx_pid="$RECEIVER_PID"
    sleep 0.5
    python3 "$ROOT/tests/bench/capacity_preflight.py" probe \
        --peer "$CAPACITY_RECEIVER_ADDR" --port "$probe_port" \
        --seconds "$(( seconds - 1 ))" --threads "$threads" \
        --json "$case_dir/preflight.tx.json" \
        >"$case_dir/preflight.tx.log" 2>&1 \
        || { receiver_wait "$rx_pid" 2>/dev/null; echo "preflight: sender probe failed" >&2; return 1; }
    receiver_wait "$rx_pid" 2>/dev/null \
        || { echo "preflight: receiver probe failed" >&2; return 1; }
    receiver_fetch "$case_dir/preflight.receiver.json" || return 1
    receiver_fetch "$case_dir/preflight.rx.json" || return 1
    receiver_collect "$case_dir" || return 1
    rate_bps="$(awk -v m="$rate" 'BEGIN { printf "%.0f", m * 1000000 }')"
    judge_args=( --destinations "$destinations" --bitrate-bps "$rate_bps"
                 --sender "$case_dir/preflight.sender.json"
                 --network "$case_dir/preflight.rx.json"
                 --probe-sender "$case_dir/preflight.tx.json"
                 --json "$case_dir/preflight.json" )
    judge_args+=( --receiver "$case_dir/preflight.receiver.json" )
    [ -z "$CAPACITY_NGINX_CPUS" ] \
        || judge_args+=( --sender-cpus "$CAPACITY_NGINX_CPUS" )
    [ -z "$CAPACITY_RECEIVER_CPUS" ] \
        || judge_args+=( --receiver-cpus "$CAPACITY_RECEIVER_CPUS" )
    capacity_preflight_calibration "$case_dir"
    # The CPUs the run is pinned to: foreign work on those is the run's
    # limit, foreign work elsewhere is not.
    judge_cpus="${CAPACITY_NGINX_CPUS:-}"
    # A receiver host's CPU numbers are its own, so they are only checked
    # against this host's /proc/stat when the receivers run on this host -
    # which a namespace receiver does, whatever address it answers on, and an
    # ssh receiver does not.
    case "${CAPACITY_RECEIVER_CONFIG:+remote}${CAPACITY_RECEIVER_EXEC:-}" in
        remote*|ssh*|*" ssh "*) ;;
        *)
            [ -z "$CAPACITY_RECEIVER_CPUS" ] \
                || judge_cpus="${judge_cpus:+$judge_cpus,}$CAPACITY_RECEIVER_CPUS"
            ;;
    esac
    [ -z "$judge_cpus" ] || judge_args+=( --benchmark-cpus "$judge_cpus" )
    # Test seam: the per-CPU busy sample can be injected so the ladder's
    # response to a foreign load is verifiable without waiting for one.
    [ -z "${CAPACITY_PREFLIGHT_BUSY_JSON:-}" ] \
        || judge_args+=( --benchmark-cpu-busy-json "$CAPACITY_PREFLIGHT_BUSY_JSON" )
    [ -z "$CAPACITY_PREFLIGHT_SENDER_CPU_PER_GBPS" ] \
        || judge_args+=( --sender-cpu-per-gbps \
                         "$CAPACITY_PREFLIGHT_SENDER_CPU_PER_GBPS" )
    [ -z "$CAPACITY_PREFLIGHT_RECEIVER_CPU_PER_GBPS" ] \
        || judge_args+=( --receiver-cpu-per-gbps \
                         "$CAPACITY_PREFLIGHT_RECEIVER_CPU_PER_GBPS" )
    python3 "$ROOT/tests/bench/capacity_preflight.py" judge "${judge_args[@]}" \
        | sed 's/^/   /'
    local judge_status="${PIPESTATUS[0]}"
    return "$judge_status"
}

# diagnostics.json for one rung; outcome is pass, quality-failure,
# setup-failure (quality never measured), infrastructure-limited (the host,
# the path or the receivers could not carry the offered load) or measured
# (no quality gate)
capacity_write_diagnostics() {   # <case dir> <outcome> [key=value ...]
    local case_dir="$1" outcome="$2"
    local -a meta=()

    shift 2
    for kv in "$@"; do meta+=( --meta "$kv" ); done
    if [ -f "$RUN/active-capacity-case" ] \
        && [ "$(cat "$RUN/active-capacity-case")" = "$case_dir" ]; then
        mkdir -p "$case_dir/runtime-logs"
        [ ! -d "$RUN/logs" ] || cp -a "$RUN/logs" "$case_dir/runtime-logs/sender"
        local sink_dir
        for sink_dir in "$RTMP_SINK_RUN"-*; do
            [ -f "$sink_dir/active-case" ] \
                && [ "$(cat "$sink_dir/active-case")" = "$case_dir" ] || continue
            if [ -n "$CAPACITY_RECEIVER_CONFIG" ]; then
                receiver_file_ready "$sink_dir/logs/error.log" \
                    && receiver_fetch "$sink_dir/logs/error.log" \
                    || echo "receiver error log unavailable: $sink_dir" >&2
            fi
            cp -a "$sink_dir" "$case_dir/runtime-logs/$(basename "$sink_dir")"
        done
    fi
    # The host's fingerprint travels with every rung, not only with the rungs
    # the preflight judged: a capacity number is unreadable without the CPU,
    # the cgroup, the NIC and the transport library it was taken on.  Half a
    # second, best effort, never a reason to fail a rung.
    [ -s "$case_dir/host-fingerprint.json" ] \
        || python3 "$ROOT/tests/bench/capacity_preflight.py" host \
               --role sender --binary "$NGINX" \
               --json "$case_dir/host-fingerprint.json" \
               >"$case_dir/host-fingerprint.log" 2>&1 \
        || echo "   host fingerprint could not be taken for $case_dir" >&2
    python3 "$ROOT/tests/bench/capacity_diagnostics.py" build "$case_dir" \
        --meta outcome="$outcome" --meta mix="$CAPACITY_CURRENT_MIX" \
        --meta srt_senders="$CAPACITY_FIXED_SRT_WORKERS" \
        --meta hls_push_uploaders="$CAPACITY_FIXED_HLS_PUSH_WORKERS" \
        --meta srt_backend="$(capacity_srt_library)" \
        --meta nginx_cpus="${CAPACITY_NGINX_CPUS:-unpinned}" \
        --meta receiver_cpus="${CAPACITY_RECEIVER_CPUS:-unpinned}" \
        --meta receiver_topology="$([ -n "$CAPACITY_RECEIVER_CONFIG" ] && echo ssh || { [ -n "$CAPACITY_RECEIVER_EXEC" ] && echo namespace || echo loopback; })" \
        --meta receiver_address="$CAPACITY_RECEIVER_ADDR" \
        "${meta[@]}" --print-summary \
        || echo "   diagnostics bundle could not be written for $case_dir" >&2
}

# A one-destination rung calibrates the reference its whole ladder is judged
# against.  The rate is stored only if it is a finite positive number and the
# rung that produced it passed its own quality checks: a failed rung's rate
# (a stalled receiver, a lossy path) would otherwise become the yardstick that
# every higher rung is measured by, and a zero would make every ratio vanish.
# A rate that is not a number is an error; a failed rung leaves the reference
# unset, so the next rung has nothing to be judged against and is refused.
capacity_positive_rate() {   # <rate>
    [[ "$1" =~ ^[0-9]+([.][0-9]+)?$ ]] \
        && awk -v b="$1" 'BEGIN { exit !(b > 0) }'
}

capacity_store_reference() {   # <variable> <log tag> <label> <quality_pass> <rate>
    local variable="$1" tag="$2" label="$3" quality_pass="$4" rate="$5"

    capacity_positive_rate "$rate" \
        || { echo "$label quality analyzer returned an invalid reference rate" \
                  >&2; return 1; }
    if [ "$quality_pass" != yes ]; then
        echo "   $label calibration rung failed its quality checks;" \
             "its rate $rate is not stored as the reference" >&2
        return 0
    fi
    printf -v "$variable" '%s' "$rate"
    echo "   calibrated_${tag}_reference_bps=$rate"
}

# which SRT library the binary under test carries: robotweax/srt links as a
# static archive and reports libsrt's API version, so ldd alone cannot tell
capacity_srt_library() {
    if grep -qa 'robotweax' "$NGINX" 2>/dev/null; then
        echo robotweax-srt
    else
        ldd "$NGINX" 2>/dev/null | awk '/libsrt/ { print $1; exit }'
    fi
}

phase_capacity() {
    local programs rate destinations

    echo
    echo "== offered-load capacity curve (fixed worker count)"
    echo "   program and bitrate cases use one shared SRT receiver per case."
    echo "   The destination ladder runs every exact rung over SRT and RTMP;"
    echo "   RTMP source uses one worker and a separate no-HLS receiver."
    echo "   Publishers and outputs warm up before the timed baseline."

    for programs in $CAPACITY_PROGRAM_STEPS; do
        capacity_case "programs-$programs" "$programs" \
            "$CAPACITY_PROGRAM_RATE" "$CAPACITY_PROGRAM_DESTS" \
            "$CAPACITY_WINDOW"
        case "$?" in
            0|4) ;;
            *) return 1 ;;
        esac
    done

    for rate in $CAPACITY_BITRATE_STEPS; do
        capacity_case "bitrate-$rate" "$CAPACITY_BITRATE_PROGRAMS" "$rate" \
            "$CAPACITY_BITRATE_DESTS" "$CAPACITY_WINDOW" || return 1
    done

    for destinations in $CAPACITY_DEST_STEPS; do
        capacity_case "destinations-$destinations-srt" \
            1 "$CAPACITY_DEST_RATE" "$destinations" \
            "$CAPACITY_WINDOW" srt || return 1
        capacity_case "destinations-$destinations-rtmp" \
            1 "$CAPACITY_DEST_RATE" "$destinations" \
            "$CAPACITY_WINDOW" rtmp || return 1
    done

    echo "   slow-reader: rate=$CAPACITY_SLOW_RATE window=${CAPACITY_SLOW_SECONDS}s"
    capacity_case "slow-reader-isolation" 1 "$CAPACITY_SLOW_RATE" 4 \
        "$CAPACITY_SLOW_SECONDS" srt d0000
    case "$?" in 0|4) ;; *) return 1 ;; esac
    capacity_case "saturated-multiprogram" 4 6M 250 \
        "$CAPACITY_SATURATED_SECONDS" srt
    case "$?" in 0|4) ;; *) return 1 ;; esac
    capacity_case "sustained" "$CAPACITY_SUSTAINED_PROGRAMS" \
        "$CAPACITY_SUSTAINED_RATE" "$CAPACITY_SUSTAINED_DESTS" \
        "$CAPACITY_SUSTAINED_SECONDS"
}

phase_capacity_saturated() {
    capacity_case "saturated-multiprogram" 4 6M 250 \
        "$CAPACITY_SATURATED_SECONDS" srt
}

phase_capacity_slow_reader() {
    echo "   slow-reader: rate=$CAPACITY_SLOW_RATE window=${CAPACITY_SLOW_SECONDS}s"
    capacity_case "slow-reader-isolation" 1 "$CAPACITY_SLOW_RATE" 4 \
        "$CAPACITY_SLOW_SECONDS" srt d0000
}

phase_capacity_sustained() {
    capacity_case "sustained" "$CAPACITY_SUSTAINED_PROGRAMS" \
        "$CAPACITY_SUSTAINED_RATE" "$CAPACITY_SUSTAINED_DESTS" \
        "$CAPACITY_SUSTAINED_SECONDS"
}

phase_capacity_srt_ladder() {
    local destinations

    echo
    echo "== single-program SRT destination ladder"
    for destinations in $CAPACITY_DEST_STEPS; do
        capacity_case "destinations-$destinations-srt" \
            1 "$CAPACITY_DEST_RATE" "$destinations" \
            "$CAPACITY_WINDOW" srt || return 1
    done
}

capacity_quality_ladder() {   # <mix> <primary protocol> <SRT share> [HLS push share]
    local mix="$1" protocol="$2" srt_share="$3" hls_push_share="${4:-0}"
    local destinations previous=0 status failures=0 first_failure="" failed_rungs=""
    local consecutive=0 skipped=""
    local srt_count primary_count rtmp_count hls_count hls_push_count
    local actual_srt_share actual_rtmp_share actual_hls_push_share
    local CAPACITY_QUALITY_REFERENCE_BPS=0 CAPACITY_QUALITY_REFERENCE_RTMP_BPS=0
    local CAPACITY_QUALITY_REFERENCE_HLS_BPS=0 CAPACITY_QUALITY_REFERENCE_HLS_PUSH_BPS=0

    CAPACITY_CURRENT_MIX="$mix"
    # References belong to this mix, not to another workload's earlier rung.
    # Mixed SRT outputs get their own one-destination source-rate calibration.
    if [ "$protocol" != srt ] && [ "$srt_share" -gt 0 ] \
        && [ "${CAPACITY_QUALITY_REFERENCE_BPS:-0}" = 0 ]; then
        echo
        echo "== calibrating the SRT reference for $mix (one SRT destination)"
        CAPACITY_CURRENT_MIX="$mix-srt-reference"
        capacity_case "quality-$mix-srt-reference" 1 \
            "$CAPACITY_QUALITY_RATE" 1 "$CAPACITY_QUALITY_SECONDS" srt "" yes \
            || { echo "mix=$mix srt reference calibration failed" >&2
                 return 3; }
        CAPACITY_CURRENT_MIX="$mix"
    fi
    echo
    echo "== $mix ${CAPACITY_QUALITY_RATE} receiver-quality ladder"
    echo "   duration=${CAPACITY_QUALITY_SECONDS}s per rung; reference=one destination per protocol"
    echo "   SRT counts use nearest-integer share rounding; actual counts shown per rung."
    echo "   pass: per-destination delivery >=${CAPACITY_QUALITY_MIN_DELIVERY_RATIO} of its protocol reference"
    if [ "$protocol" = srt ]; then
        echo "   SRT quality also requires interval floor=${CAPACITY_QUALITY_INTERVAL_FLOOR},"
        echo "   lag limit=${CAPACITY_QUALITY_MAX_LOW_SECONDS}s, queue pressure limit="
        echo "   ${CAPACITY_QUALITY_QUEUE_PRESSURE} for ${CAPACITY_QUALITY_PRESSURE_SAMPLES} samples,"
        echo "   and zero MPEG-TS errors/application drops."
    fi
    for destinations in $CAPACITY_QUALITY_STEPS; do
        [[ "$destinations" =~ ^[1-9][0-9]*$ ]] \
            && [ "$destinations" -le 1000 ] \
            && [ "$destinations" -gt "$previous" ] \
            || { echo "quality ladder must be strictly increasing within 1..1000" \
                     >&2; return 1; }
        # The ladder begins at the smallest rung at which every protocol in
        # the mix has a destination: one for a pure workload and for the
        # published mixes (whose 5% SRT share rounds to zero there), four for
        # a 50/25/25 mix, where one destination would leave no room for RTMP
        # or HLS push at all.  The per-protocol baselines come from that rung.
        if [ "$previous" -eq 0 ]; then
            minimum="$(capacity_mix_minimum_rung "$protocol" "$srt_share" "$hls_push_share")"
            if [ "$destinations" -lt "$minimum" ]; then
                echo "quality ladder must begin at or above the smallest rung this mix can form: $minimum" >&2
                return 1
            fi
        fi
        previous="$destinations"
        if [ "$CAPACITY_QUALITY_STOP_AFTER_FAILURES" -gt 0 ] \
            && [ "$consecutive" -ge "$CAPACITY_QUALITY_STOP_AFTER_FAILURES" ]; then
            skipped+="${skipped:+ }$destinations"
            continue
        fi
        if [ "$protocol" = srt ]; then
            srt_count="$destinations"
        else
            srt_count=$(( (destinations * srt_share + 50) / 100 ))
        fi
        primary_count=$(( destinations - srt_count ))
        rtmp_count=0
        hls_count=0
        hls_push_count=0
        case "$protocol" in
            rtmp) rtmp_count="$primary_count" ;;
            hls) hls_count="$primary_count" ;;
            hls-push) hls_push_count="$primary_count" ;;
            rtmp-hls-push)
                hls_push_count=$(( (destinations * hls_push_share + 50) / 100 ))
                rtmp_count=$(( primary_count - hls_push_count ))
                ;;
        esac
        actual_srt_share="$(awk -v s="$srt_count" -v d="$destinations" \
            'BEGIN { printf "%.2f", 100 * s / d }')"
        actual_rtmp_share="$(awk -v s="$rtmp_count" -v d="$destinations" \
            'BEGIN { printf "%.2f", 100 * s / d }')"
        actual_hls_push_share="$(awk -v s="$hls_push_count" -v d="$destinations" \
            'BEGIN { printf "%.2f", 100 * s / d }')"
        echo "quality_rung_start mix=$mix destinations=$destinations srt=$srt_count rtmp=$rtmp_count hls=$hls_count hls_push=$hls_push_count actual_shares_srt=${actual_srt_share}%_rtmp=${actual_rtmp_share}%_hls_push=${actual_hls_push_share}%"
        # The case itself runs the preflight (on the whole offer, programs
        # included) and returns 4 when the host cannot carry it; the CPU cost
        # it judges against is calibrated from the rung that ran before.
        capacity_preflight_calibration \
            "$RUN/capacity/quality-$mix-$destinations"
        if capacity_case "quality-$mix-$destinations" "$CAPACITY_QUALITY_PROGRAMS" \
            "$CAPACITY_QUALITY_RATE" "$destinations" \
            "$CAPACITY_QUALITY_SECONDS" "$protocol" "" yes \
            "$srt_share" "$hls_push_share"
        then
            echo "quality_rung_result mix=$mix destinations=$destinations srt=$srt_count rtmp=$rtmp_count hls=$hls_count hls_push=$hls_push_count result=pass"
            consecutive=0
        else
            status="$?"
            if [ "$status" -eq 4 ]; then
                # The host could not carry the offer: not a result about
                # nginx, so the ladder stops and the higher rungs are
                # reported as unmeasured rather than as failures.
                echo "quality_rung_result mix=$mix destinations=$destinations result=infrastructure-limited"
                echo "mix=$mix infrastructure_limited_rung=$destinations"
                skipped+="${skipped:+ }$destinations"
                for remaining in $CAPACITY_QUALITY_STEPS; do
                    [ "$remaining" -gt "$destinations" ] \
                        && skipped+=" $remaining"
                done
                break
            fi
            if [ "$status" -ne 2 ]; then
                mkdir -p "$RUN/capacity/quality-$mix-$destinations"
                capacity_write_diagnostics \
                    "$RUN/capacity/quality-$mix-$destinations" setup-failure \
                    destinations="$destinations" srt="$srt_count" \
                    rtmp="$rtmp_count" hls_readers="$hls_count" \
                    hls_push="$hls_push_count" status="$status"
                kill_pubs
                for receiver_pid in ${SINKS[@]+"${SINKS[@]}"}; do
                    kill_one "$receiver_pid"
                done
                SINKS=()
                stop_instance
                stop_rtmp_sink_instance
                echo "quality_rung_result mix=$mix destinations=$destinations result=setup-error status=$status"
                echo "mix=$mix first_failing_destination_rung=${first_failure:-unmeasured}"
                echo "mix=$mix setup_failure_rung=$destinations (higher rungs unmeasured)"
                echo "quality_ladder_aborted_at=$destinations"
                return 3
            fi
            echo "quality_rung_result mix=$mix destinations=$destinations srt=$srt_count rtmp=$rtmp_count hls=$hls_count hls_push=$hls_push_count result=fail"
            failures=$(( failures + 1 ))
            consecutive=$(( consecutive + 1 ))
            [ -n "$first_failure" ] || first_failure="$destinations"
            [ -z "$failed_rungs" ] || failed_rungs+=" "
            failed_rungs+="$destinations"
        fi
    done
    [ -z "$skipped" ] \
        || echo "mix=$mix unmeasured_rungs=$skipped (after $CAPACITY_QUALITY_STOP_AFTER_FAILURES consecutive failures)"
    if [ "$failures" -gt 0 ]; then
        echo "mix=$mix first_failing_destination_rung=$first_failure"
        echo "mix=$mix quality_failed_rungs=$failed_rungs"
        return 2
    fi
    echo "mix=$mix first_failing_destination_rung=none"
    echo "mix=$mix quality_failed_rungs=none"
}

phase_capacity_quality_ladder() {
    local entry mix protocol srt_share hls_push_share category status failures=0 failed_mixes=""
    local requested found
    local -a executed_mixes=() requested_mixes=() selected_mix_specs=()
    local -a mix_specs=()
    local mixes_file="$ROOT/tests/bench/capacity-mixes.conf"

    # The workloads are listed once, in capacity-mixes.conf, which the CI
    # driver reads too: one set of mixes for the manifest and the execution.
    mapfile -t mix_specs < <(grep -v -e '^[[:space:]]*#' -e '^[[:space:]]*$' \
                                  "$mixes_file")
    [ "${#mix_specs[@]}" -gt 0 ] \
        || { echo "no capacity quality mixes in $mixes_file" >&2; return 1; }

    [ -n "$CAPACITY_QUALITY_STEPS" ] \
        || { echo "CAPACITY_QUALITY_STEPS must not be empty" >&2; return 1; }
    if [ "$CAPACITY_QUALITY_MIXES" != all ]; then
        read -r -a requested_mixes <<< "$CAPACITY_QUALITY_MIXES"
        [ "${#requested_mixes[@]}" -gt 0 ] \
            || { echo "CAPACITY_QUALITY_MIXES must not be empty" >&2; return 1; }
        for requested in "${requested_mixes[@]}"; do
            case "$requested" in
                *[!A-Za-z0-9-]*)
                    echo "unknown capacity quality mix: $requested" >&2
                    return 1
                    ;;
            esac
            found=0
            for entry in "${mix_specs[@]}"; do
                if [ "${entry%%:*}" = "$requested" ]; then
                    selected_mix_specs+=( "$entry" )
                    found=1
                    break
                fi
            done
            [ "$found" -eq 1 ] \
                || { echo "unknown capacity quality mix: $requested" >&2; return 1; }
        done
        mix_specs=( "${selected_mix_specs[@]}" )
    fi

    # What this run executes, in order, stated by the harness itself: the CI
    # driver's expected-run manifest is checked against this line, so a list
    # the two disagree on fails the completeness gate instead of being
    # silently shorter or longer than the manifest.
    for entry in "${mix_specs[@]}"; do
        executed_mixes+=( "${entry%%:*}" )
    done
    echo
    echo "== ${#mix_specs[@]} ${CAPACITY_QUALITY_RATE} delivery-quality ladders"
    echo "   each rung uses one program; per-protocol one-destination baselines calibrate before scaling."
    echo "quality_mixes=${executed_mixes[*]}"
    echo "quality_recipe seconds=$CAPACITY_QUALITY_SECONDS rate=$CAPACITY_QUALITY_RATE steps=${CAPACITY_QUALITY_STEPS// /,} stop_after_failures=$CAPACITY_QUALITY_STOP_AFTER_FAILURES min_delivery_ratio=$CAPACITY_QUALITY_MIN_DELIVERY_RATIO interval_floor=$CAPACITY_QUALITY_INTERVAL_FLOOR max_low_seconds=$CAPACITY_QUALITY_MAX_LOW_SECONDS srt_workers=$CAPACITY_FIXED_SRT_WORKERS hls_push_workers=$CAPACITY_FIXED_HLS_PUSH_WORKERS srt_hls=$CAPACITY_SRT_HLS"
    for entry in "${mix_specs[@]}"; do
        IFS=: read -r mix protocol srt_share hls_push_share category <<< "$entry"
        if capacity_quality_ladder "$mix" "$protocol" "$srt_share" "$hls_push_share"; then
            :
        else
            status="$?"
            # a setup failure ends that mix's ladder but not the others
            if [ "$status" -ne 2 ] && [ "$status" -ne 3 ]; then
                python3 "$ROOT/tests/bench/capacity_diagnostics.py" matrix \
                    "$RUN" || true
                return "$status"
            fi
            failures=$(( failures + 1 ))
            [ -n "$failed_mixes" ] || failed_mixes="$mix"
            [[ " $failed_mixes " == *" $mix "* ]] \
                || failed_mixes+=" $mix"
        fi
    done
    python3 "$ROOT/tests/bench/capacity_diagnostics.py" matrix "$RUN" || true
    if [ "$failures" -gt 0 ]; then
        echo "quality_ladders_with_failures=$failed_mixes"
        return 1
    fi
    echo "quality_ladders_with_failures=none"
}

# --- run --------------------------------------------------------------------

rm -rf "$RUN"
mkdir -p "$RUN/conf" "$RUN/logs" "$RUN/media"

for p in $(pgrep -f "nginx: master process .* -p $RUN" 2>/dev/null || true); do
    echo "   stopping a leftover master $p from this RUN"
    for c in $(pgrep -P "$p" 2>/dev/null); do kill -KILL "$c" 2>/dev/null; done
    kill -KILL "$p" 2>/dev/null
done

echo "== host"
echo "   $(uname -srm), $(nproc) cpus"
echo "   net.core.rmem_max $(sysctl -n net.core.rmem_max 2>/dev/null || echo '?')"
echo "   nginx $(basename "$NGINX") built $(stat -c %y "$NGINX" | cut -d. -f1)"
echo

needs_lo_source=0
for phase in $PHASES; do
    case "$phase" in
        capacity-quality-ladder) ;;
        *) needs_lo_source=1; break ;;
    esac
done
if [ "$needs_lo_source" -eq 1 ]; then
    make_source "$RUN/media/lo.ts" "$LO_BITRATE"
fi

for phase in $PHASES; do
    case "$phase" in
        floor)    phase_floor ;;
        ingest)
            phase_ingest_high
            phase_ingest_publishers
            phase_ingest_endpoints
            phase_ingest_one_port
            ;;
        egress)
            phase_egress_hls
            phase_egress_live
            ;;
        misplace) phase_misplace ;;
        topology) phase_topology ;;
        capacity) phase_capacity || exit 1 ;;
        capacity-srt-ladder) phase_capacity_srt_ladder || exit 1 ;;
        capacity-quality-ladder) phase_capacity_quality_ladder || exit 1 ;;
        capacity-saturated) phase_capacity_saturated || exit 1 ;;
        capacity-slow-reader) phase_capacity_slow_reader || exit 1 ;;
        capacity-sustained) phase_capacity_sustained || exit 1 ;;
    esac
done

trap - EXIT
cleanup

echo
echo "== conditions"
echo "   source:     pre-encoded 720p25 mpegts, publishers use -c copy"
echo "   endpoints:  one media_srt_listen per worker, worker i binds entry i"
echo "   api:        listen ... reuseport; mutations retried until the owner"
echo "               answers, metrics read on the owner's own connection"
echo "   throughput: chunks/s and bytes/s are the workers' own drained totals"
echo "   cpu:        per thread, percent of one core, over the measured window"
if [[ " $PHASES " == *" capacity "* \
   || " $PHASES " == *" capacity-srt-ladder "* \
   || " $PHASES " == *" capacity-quality-ladder "* \
   || " $PHASES " == *" capacity-saturated "* \
   || " $PHASES " == *" capacity-slow-reader "* \
   || " $PHASES " == *" capacity-sustained "* ]]; then
    echo "   receivers:  separate SRT/RTMP sinks, HLS readers and HLS PUT sink"
    echo "   receiver CPU: sampled for external SRT, RTMP and HLS sink workers"
fi
echo "   labels:     SRT:* from comm; this module's threads from a stack" \
     "backtrace ($([ "$LABELLED" = 1 ] && echo 'attached and labelled' \
                                || echo 'NOT AVAILABLE: comm names only'))"
echo "   host:       single host, no netem, $(nproc) cpus"
echo "== ingest/egress fanout done"
