#!/usr/bin/env python3
"""Measure per-destination SRT delivery rate, MPEG-TS continuity, and queues."""

import argparse
import csv
import glob
import http.client
import json
import math
import os
import re
import signal
import sys
import time
from collections import defaultdict
from threading import Event
from pathlib import Path

PACKET_DROP_METRICS = {
    "nginx_media_srt_egress_shard_feed_queue_dropped_total",
    "nginx_media_srt_egress_shard_output_dropped_total",
}
QUEUE_METRICS = {
    "nginx_media_srt_egress_shard_destinations",
    "nginx_media_srt_egress_shard_feed_queue_units",
    "nginx_media_srt_egress_shard_feed_queue_bytes",
    "nginx_media_srt_egress_shard_feed_queue_dropped_total",
    "nginx_media_srt_egress_shard_output_queue_units",
    "nginx_media_srt_egress_shard_output_queue_bytes",
    "nginx_media_srt_egress_shard_output_dropped_total",
    "nginx_media_srt_egress_shard_sent_bytes_total",
    "nginx_media_srt_egress_shard_blocked_sends_total",
    "nginx_media_srt_egress_shard_retransmitted_packets_total",
}
LABEL_RE = re.compile(r'([a-zA-Z_][a-zA-Z0-9_]*)="((?:\\.|[^"])*)"')
SAMPLE_RE = re.compile(
    r"^([a-zA-Z_:][a-zA-Z0-9_:]*)(?:\{(.*?)\})?\s+"
    r"([-+]?(?:[0-9]+\.?[0-9]*|\.[0-9]+)(?:[eE][-+]?[0-9]+)?)"
    r"(?:\s+\S+)?\s*$"
)


def read_receiver_snapshot(path):
    with open(path, newline="", encoding="utf-8") as source:
        reader = csv.DictReader(source)
        required = {"destination_id", "bytes_received", "snapshot_ns"}
        if reader.fieldnames is None or not required.issubset(reader.fieldnames):
            raise ValueError(f"receiver snapshot has an invalid schema: {path}")
        values = {}
        stamp = None
        for row in reader:
            destination = row["destination_id"]
            try:
                received = int(row["bytes_received"])
                row_stamp = int(row["snapshot_ns"])
            except (TypeError, ValueError):
                raise ValueError(f"invalid snapshot values for {destination}")
            if received < 0 or row_stamp <= 0 or destination in values:
                raise ValueError(f"invalid or duplicate receiver row: {destination}")
            if stamp is not None and row_stamp != stamp:
                raise ValueError("receiver snapshot has inconsistent timestamps")
            stamp = row_stamp
            values[destination] = received
    if not values or stamp is None:
        raise ValueError(f"receiver snapshot is empty: {path}")
    return stamp, values


def wait_snapshot(path, after_ns, stop_event, timeout=5.0):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline and not stop_event.is_set():
        try:
            stamp, values = read_receiver_snapshot(path)
            if stamp > after_ns:
                return stamp, values
        except (OSError, ValueError):
            pass
        stop_event.wait(0.01)
    if stop_event.is_set():
        return None
    raise RuntimeError(f"receiver did not write a fresh snapshot: {path}")


def sample_receivers(args):
    stop_event, pause_event, wake = Event(), Event(), Event()

    def stop(*_):
        stop_event.set()
        wake.set()

    def pause(*_):
        pause_event.set()
        wake.set()

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    signal.signal(signal.SIGUSR2, pause)
    with open(args.output, "w", newline="", encoding="utf-8") as output:
        writer = csv.DictWriter(
            output,
            fieldnames=("destination_id", "start_ns", "end_ns",
                        "bytes_received", "total_bytes"),
        )
        writer.writeheader()
        output.flush()
        if args.ready_file:
            Path(args.ready_file).touch()
        deadline = time.monotonic() + 60
        while not Path(args.baseline).is_file():
            if stop_event.wait(0.01):
                return 0
            if time.monotonic() >= deadline:
                raise RuntimeError("controller did not provide the SRT baseline")
        previous_ns, previous = read_receiver_snapshot(args.baseline)
        while not stop_event.is_set() and not pause_event.is_set():
            # Cadence is anchored to the receiver's last snapshot, not to
            # process startup after an SSH handshake and baseline transfer.
            delay = max(0.0, previous_ns / 1e9 + args.interval - time.monotonic())
            if wake.wait(delay):
                break
            try:
                os.unlink(args.snapshot)
            except FileNotFoundError:
                pass
            try:
                os.kill(args.receiver_pid, signal.SIGUSR1)
            except ProcessLookupError:
                raise RuntimeError("SRT receiver exited during interval sampling")
            result = wait_snapshot(args.snapshot, previous_ns, stop_event)
            if result is None:
                break
            current_ns, current = result
            if set(current) != set(previous):
                raise RuntimeError("receiver destination set changed during measurement")
            if current_ns <= previous_ns:
                raise RuntimeError("receiver snapshot timestamp did not advance")
            for destination in sorted(current):
                delta = current[destination] - previous[destination]
                if delta < 0:
                    raise RuntimeError(f"receiver counter decreased for {destination}")
                writer.writerow({
                    "destination_id": destination,
                    "start_ns": previous_ns,
                    "end_ns": current_ns,
                    "bytes_received": delta,
                    "total_bytes": current[destination],
                })
            output.flush()
            previous_ns, previous = current_ns, current
        if pause_event.is_set() and args.ready_file:
            # An outstanding SIGUSR1 has completed before this acknowledgment.
            # The controller can now toggle measurement without snapshot races.
            Path(args.ready_file + ".paused").touch()
    return 0


def parse_metrics(blob):
    worker_pid = None
    values = defaultdict(dict)
    for line in blob.splitlines():
        match = SAMPLE_RE.match(line)
        if match is None:
            if any(line.startswith(name) for name in QUEUE_METRICS):
                raise ValueError("malformed required sender metric")
            continue
        name, label_text, raw_value = match.groups()
        labels = dict(LABEL_RE.findall(label_text or ""))
        if name in QUEUE_METRICS:
            pairs = LABEL_RE.findall(label_text or "")
            if (len(pairs) != len(labels)
                    or LABEL_RE.sub("", label_text or "").strip(" ,\t")):
                raise ValueError(f"malformed required sender metric labels: {name}")
        try:
            value = float(raw_value)
        except ValueError:
            continue
        if not math.isfinite(value):
            continue
        if name == "nginx_media_worker_info" and "pid" in labels and value == 1:
            worker_pid = labels["pid"]
        if name in QUEUE_METRICS:
            if ("worker" not in labels or "shard" not in labels
                    or not math.isfinite(value) or value < 0 or not value.is_integer()):
                raise ValueError(f"invalid required sender metric {name}")
            key = (labels["worker"], labels["shard"])
            if name in values[key]:
                raise ValueError(f"duplicate required sender metric {name} for {key}")
            values[key][name] = value
    return worker_pid, values


def fetch_worker_round(port, expected_pids):
    received = {}
    attempts = max(100, len(expected_pids) * 50)
    for _ in range(attempts):
        connection = http.client.HTTPConnection("127.0.0.1", port, timeout=2.0)
        try:
            connection.request("GET", "/media/api/v1/metrics",
                              headers={"Connection": "close"})
            response = connection.getresponse()
            if response.status != 200:
                response.read()
                continue
            blob = response.read().decode("utf-8", errors="replace")
            worker_pid, shard_values = parse_metrics(blob)
            if worker_pid not in expected_pids:
                continue
            received.setdefault(worker_pid,
                                (time.monotonic_ns(), shard_values))
            if len(received) == len(expected_pids):
                return received
        except (OSError, http.client.HTTPException):
            pass
        finally:
            connection.close()
    missing = sorted(expected_pids - set(received), key=int)
    raise RuntimeError(f"could not sample worker metrics for PIDs {missing}")


def sample_queues(args):
    expected = set(args.worker_pids)
    if not expected:
        raise ValueError("queue sampler requires worker PIDs")
    stop_event = Event()
    signal.signal(signal.SIGTERM, lambda _signo, _frame: stop_event.set())
    signal.signal(signal.SIGINT, lambda _signo, _frame: stop_event.set())
    round_id = 0
    with open(args.output, "w", newline="", encoding="utf-8") as output:
        fields = ("round_id", "sample_ns", "worker_pid", "worker", "shard",
                  "destinations", "feed_queue_units", "feed_queue_bytes",
                  "feed_drops", "output_queue_units", "output_queue_bytes",
                  "output_drops", "sent_bytes", "blocked_sends",
                  "retransmitted_packets")
        writer = csv.DictWriter(output, fieldnames=fields)
        writer.writeheader()
        output.flush()
        if args.ready_file:
            Path(args.ready_file).touch()
        deadline = time.monotonic() + 60
        while not Path(args.baseline_ready).is_file():
            if stop_event.wait(0.01):
                return 0
            if time.monotonic() >= deadline:
                raise RuntimeError("controller did not release the SRT queue baseline")
        while not stop_event.is_set():
            samples = fetch_worker_round(args.port, expected)
            for pid in sorted(samples, key=int):
                sample_ns, shard_values = samples[pid]
                for (worker, shard), values in sorted(shard_values.items()):
                    if not QUEUE_METRICS.issubset(values):
                        raise ValueError(f"{worker}/{shard}: missing required sender metrics")
                    writer.writerow({
                        "round_id": round_id,
                        "sample_ns": sample_ns,
                        "worker_pid": pid,
                        "worker": worker,
                        "shard": shard,
                        "destinations": values["nginx_media_srt_egress_shard_destinations"],
                        "feed_queue_units": values["nginx_media_srt_egress_shard_feed_queue_units"],
                        "feed_queue_bytes": values["nginx_media_srt_egress_shard_feed_queue_bytes"],
                        "feed_drops": values["nginx_media_srt_egress_shard_feed_queue_dropped_total"],
                        "output_queue_units": values["nginx_media_srt_egress_shard_output_queue_units"],
                        "output_queue_bytes": values["nginx_media_srt_egress_shard_output_queue_bytes"],
                        "output_drops": values["nginx_media_srt_egress_shard_output_dropped_total"],
                        "sent_bytes": values["nginx_media_srt_egress_shard_sent_bytes_total"],
                        "blocked_sends": values["nginx_media_srt_egress_shard_blocked_sends_total"],
                        "retransmitted_packets": values["nginx_media_srt_egress_shard_retransmitted_packets_total"],
                    })
            output.flush()
            round_id += 1
            if stop_event.wait(args.interval):
                break
    return 0


def read_metric_files(prefix):
    values = defaultdict(dict)
    paths = sorted(glob.glob(prefix + ".*"))
    if not paths:
        raise ValueError(f"no worker metrics files match {prefix}.*")
    for path in paths:
        with open(path, encoding="utf-8") as source:
            _, parsed = parse_metrics(source.read())
        for key, metrics in parsed.items():
            if key in values:
                raise ValueError(f"duplicate sender shard in snapshot: {key}")
            values[key] = metrics
    return values


def read_stream_metric(path, metric):
    total = 0.0
    found = False
    with open(path, encoding="utf-8") as source:
        for line in source:
            match = SAMPLE_RE.match(line)
            if match is None or match.group(1) != metric:
                continue
            try:
                value = float(match.group(3))
            except ValueError:
                continue
            if not math.isfinite(value) or value < 0 or not value.is_integer():
                raise ValueError(f"invalid required {metric} in {path}")
            total += value
            found = True
    if not found:
        raise ValueError(f"missing required {metric} in {path}")
    return total


def jain(values):
    total = sum(values)
    squares = sum(value * value for value in values)
    return total * total / (len(values) * squares) if values and squares else 0.0


def expected_ids(programs, destinations):
    """The destination IDs a rung creates: one program numbers them d0000..,
    several programs prefix each with its own p0000- (the harness's
    capacity_destination_id)."""
    if programs <= 1:
        return {f"d{index:04d}" for index in range(destinations)}
    return {f"p{program:04d}-d{index:04d}"
            for program in range(programs)
            for index in range(destinations)}


def quality_report(args):
    failures = []
    baseline_ns, baseline = read_receiver_snapshot(args.baseline)
    final_ns, final = read_receiver_snapshot(args.final)
    expected = expected_ids(args.programs, args.destinations)
    if set(baseline) != expected or set(final) != expected:
        raise ValueError("receiver snapshot IDs do not match the quality rung")
    if final_ns <= baseline_ns:
        raise ValueError("receiver measurement timestamps did not advance")
    duration_s = (final_ns - baseline_ns) / 1e9
    if duration_s <= 0:
        raise ValueError("receiver measurement duration is invalid")

    interval_rows = defaultdict(list)
    with open(args.intervals, newline="", encoding="utf-8") as source:
        reader = csv.DictReader(source)
        required = {"destination_id", "start_ns", "end_ns", "bytes_received", "total_bytes"}
        if reader.fieldnames is None or not required.issubset(reader.fieldnames):
            raise ValueError("receiver interval CSV has an invalid schema")
        for row in reader:
            destination = row["destination_id"]
            try:
                values = (int(row["start_ns"]), int(row["end_ns"]),
                          int(row["bytes_received"]), int(row["total_bytes"]))
            except (TypeError, ValueError):
                raise ValueError(f"invalid receiver interval for {destination}")
            if (destination not in expected or values[0] < 0
                    or values[1] <= values[0] or values[2] < 0 or values[3] < 0):
                raise ValueError(f"invalid receiver interval row for {destination}")
            interval_rows[destination].append(values)
    if set(interval_rows) != expected:
        raise ValueError("receiver interval IDs do not match the quality rung")

    receiver_results = {}
    with open(args.receiver_results, newline="", encoding="utf-8") as source:
        reader = csv.DictReader(source)
        required = {"destination_id", "ts_packets", "ts_sync_errors",
                    "ts_continuity_errors", "ts_tei_errors", "stalled",
                    "transport_error"}
        if reader.fieldnames is None or not required.issubset(reader.fieldnames):
            raise ValueError("receiver results CSV lacks quality counters")
        for row in reader:
            destination = row["destination_id"]
            if row["stalled"] is None:
                raise ValueError(f"missing receiver stalled status for {destination}")
            if destination in receiver_results:
                raise ValueError(f"duplicate receiver result for {destination}")
            try:
                receiver_results[destination] = {
                    key: int(row[key]) for key in
                    ("ts_packets", "ts_sync_errors", "ts_continuity_errors",
                     "ts_tei_errors", "transport_error")
                } | {"stalled": row["stalled"].lower() in {"1", "true", "yes"}}
            except (TypeError, ValueError):
                raise ValueError(f"invalid TS counters for {destination}")
            if (row["stalled"].lower() not in {"0", "false", "no", "1", "true", "yes"}
                    or any(value < 0 for key, value in receiver_results[destination].items()
                           if key != "stalled")):
                raise ValueError(f"invalid receiver quality counters for {destination}")
    if set(receiver_results) != expected:
        raise ValueError("receiver results IDs do not match the quality rung")

    rows = []
    all_rates = []
    reference_bps = args.reference_bps
    if reference_bps <= 0:
        if args.destinations != 1:
            raise ValueError("one-destination quality case is required to calibrate rate")
        reference_bps = (final[next(iter(expected))] - baseline[next(iter(expected))]) * 8 / duration_s
        if not math.isfinite(reference_bps) or reference_bps <= 0:
            raise ValueError("one-destination receiver delivered no calibration payload")
    if not math.isfinite(reference_bps) or reference_bps <= 0:
        raise ValueError(f"delivery reference {reference_bps!r} is not a finite "
                         f"positive rate")
    prepared_source_bps = (
        os.path.getsize(args.prepared_source) * 8 / args.source_duration_s
    )
    if not math.isfinite(prepared_source_bps) or prepared_source_bps <= 0:
        raise ValueError("prepared MPEG-TS source is empty")
    reference_vs_source_ratio = reference_bps / prepared_source_bps
    if reference_vs_source_ratio < args.min_delivery_ratio:
        failures.append(
            f"one-destination reference rate {reference_vs_source_ratio:.4f} "
            f"of prepared MPEG-TS bitrate is below {args.min_delivery_ratio:.4f}"
        )

    interval_file = open(args.interval_report, "w", newline="", encoding="utf-8")
    interval_writer = csv.writer(interval_file)
    interval_writer.writerow(("destination_id", "kind", "start_ns", "end_ns",
                              "duration_s", "bytes_received", "rate_bps",
                              "reference_ratio"))
    for destination in sorted(expected):
        total_bytes = final[destination] - baseline[destination]
        if total_bytes < 0:
            raise ValueError(f"receiver byte counter decreased for {destination}")
        rate_bps = total_bytes * 8 / duration_s
        ratio = rate_bps / reference_bps
        intervals = interval_rows[destination]
        previous_end = baseline_ns
        previous_total = baseline[destination]
        low_start = None
        low_end = None
        min_interval_ratio = None
        largest_interval_s = 0.0
        interval_bytes = 0
        for start_ns, end_ns, byte_count, cumulative in intervals:
            span_s = (end_ns - start_ns) / 1e9
            largest_interval_s = max(largest_interval_s, span_s)
            if (start_ns != previous_end or start_ns < baseline_ns
                    or end_ns > final_ns):
                raise ValueError(f"{destination}: interval sampling gap, overlap or out-of-window sample")
            if cumulative < previous_total or cumulative - previous_total != byte_count:
                raise ValueError(f"{destination}: interval counters do not reconcile")
            if span_s > args.max_interval_s:
                raise ValueError(f"{destination}: sample interval {span_s:.2f}s exceeds limit")
            interval_ratio = (byte_count * 8 / span_s) / reference_bps
            min_interval_ratio = interval_ratio if min_interval_ratio is None else min(min_interval_ratio, interval_ratio)
            interval_writer.writerow((destination, "sample", start_ns, end_ns,
                                      f"{span_s:.6f}", byte_count,
                                      f"{byte_count * 8 / span_s:.2f}",
                                      f"{interval_ratio:.6f}"))
            interval_bytes += byte_count
            if interval_ratio < args.interval_floor:
                if low_start is None:
                    low_start = start_ns
                low_end = end_ns
                if (low_end - low_start) / 1e9 > args.max_low_s:
                    failures.append(f"{destination}: under-rate persisted {(low_end-low_start)/1e9:.2f}s")
            else:
                low_start = low_end = None
            previous_end = end_ns
            previous_total = cumulative
        last_end = intervals[-1][1] if intervals else baseline_ns
        residual_bytes = final[destination] - previous_total
        if residual_bytes < 0:
            raise ValueError(f"{destination}: interval counter exceeds final receiver counter")
        if final_ns > last_end:
            residual_s = (final_ns - last_end) / 1e9
            largest_interval_s = max(largest_interval_s, residual_s)
            if residual_s > args.max_interval_s:
                raise ValueError(f"{destination}: final sample gap {residual_s:.2f}s exceeds limit")
            residual_ratio = (residual_bytes * 8 / residual_s) / reference_bps
            min_interval_ratio = residual_ratio if min_interval_ratio is None else min(min_interval_ratio, residual_ratio)
            interval_writer.writerow((destination, "final-residual", last_end, final_ns,
                                      f"{residual_s:.6f}", residual_bytes,
                                      f"{residual_bytes * 8 / residual_s:.2f}",
                                      f"{residual_ratio:.6f}"))
            if residual_ratio < args.interval_floor:
                if low_start is None:
                    low_start = last_end
                low_end = final_ns
                if (low_end - low_start) / 1e9 > args.max_low_s:
                    failures.append(f"{destination}: final under-rate persisted {(low_end-low_start)/1e9:.2f}s")
        elif final_ns < last_end:
            raise ValueError(f"{destination}: interval sample extends past final snapshot")
        if interval_bytes + residual_bytes != total_bytes or (final_ns == last_end and residual_bytes):
            raise ValueError(f"{destination}: interval bytes do not reconcile with final counter")
        if ratio < args.min_delivery_ratio:
            failures.append(f"{destination}: average delivery ratio {ratio:.4f} below {args.min_delivery_ratio:.4f}")
        ts = receiver_results[destination]
        if ts["stalled"]:
            failures.append(f"{destination}: receiver marked stalled")
        if ts["transport_error"]:
            failures.append(f"{destination}: SRT transport error")
        if ts["ts_packets"] <= 0:
            failures.append(f"{destination}: no MPEG-TS packets parsed")
        if any(ts[key] != 0 for key in ("ts_sync_errors", "ts_continuity_errors", "ts_tei_errors")):
            failures.append(f"{destination}: MPEG-TS continuity/sync/TEI errors "
                            f"{ts['ts_sync_errors']}/{ts['ts_continuity_errors']}/{ts['ts_tei_errors']}")
        rows.append((destination, total_bytes, rate_bps, ratio,
                     min_interval_ratio or 0.0, largest_interval_s, ts))
        all_rates.append(rate_bps)
    interval_file.close()

    before = read_metric_files(args.metrics_before)
    after = read_metric_files(args.metrics_after)
    queue_drops = {name: 0.0 for name in PACKET_DROP_METRICS}
    keys = {key for key, values in before.items()
            if values.get("nginx_media_srt_egress_shard_destinations", 0) > 0}
    after_keys = {key for key, values in after.items()
                  if values.get("nginx_media_srt_egress_shard_destinations", 0) > 0}
    if keys != after_keys or not keys:
        raise ValueError("active sender shard set changed or is missing")
    for snapshot in (before, after):
        if sum(snapshot[key]["nginx_media_srt_egress_shard_destinations"]
               for key in keys) != len(expected):
            raise ValueError("sender shard destination counts do not match the rung")
        for key in keys:
            if not QUEUE_METRICS.issubset(snapshot[key]):
                raise ValueError(f"{key}: missing required sender metrics")
            if not all(math.isfinite(value) and value >= 0 and value.is_integer()
                       for value in snapshot[key].values()):
                raise ValueError(f"{key}: invalid required sender counter")
    for key in keys:
        for metric in PACKET_DROP_METRICS:
            old = before[key][metric]
            new = after[key][metric]
            if new < old:
                raise ValueError(f"{key[0]}/{key[1]}: {metric} counter regressed")
            queue_drops[metric] += max(0.0, new - old)
    if any(queue_drops.values()):
        failures.append("sender feed/output application drop counters increased")

    metric = "nginx_media_stream_feed_overruns_total"
    old = read_stream_metric(args.stream_before, metric)
    new = read_stream_metric(args.stream_after, metric)
    if new < old:
        raise ValueError(f"{metric} counter regressed")
    elif new > old:
        failures.append(f"{metric} increased by {new - old:g}")
    stream_overruns = max(0.0, new - old)

    metric = "nginx_media_stream_feed_evictions_total"
    old = read_stream_metric(args.stream_before, metric)
    new = read_stream_metric(args.stream_after, metric)
    if new < old:
        raise ValueError(f"{metric} counter regressed")
    stream_evictions = max(0.0, new - old)
    queue_start_ns, queue_end_ns = baseline_ns, final_ns
    if args.queue_window and os.path.isfile(args.queue_window):
        with open(args.queue_window, encoding="utf-8") as source:
            mapped = json.load(source)
        if (mapped["clock_domain"] != "controller-monotonic"
                or not 0 < mapped["start_ns"] < mapped["end_ns"]):
            raise ValueError("invalid controller mapping for queue coverage")
        if (mapped["native_start_ns"] != baseline_ns or mapped["native_end_ns"] != final_ns):
            raise ValueError("queue mapping disagrees with native receiver snapshots")
        queue_start_ns, queue_end_ns = mapped["start_ns"], mapped["end_ns"]
    elif args.clock_domain != "controller-monotonic":
        raise ValueError("remote receiver requires controller mapping for sender queue coverage")
    queue_rows = defaultdict(dict)
    with open(args.queues, newline="", encoding="utf-8") as source:
        reader = csv.DictReader(source)
        required = {"round_id", "sample_ns", "worker_pid", "worker", "shard",
                    "destinations", "feed_queue_units", "feed_queue_bytes",
                    "feed_drops", "output_queue_units", "output_queue_bytes",
                    "output_drops", "sent_bytes", "blocked_sends", "retransmitted_packets"}
        if reader.fieldnames is None or not required.issubset(reader.fieldnames):
            raise ValueError("queue sample CSV has an invalid schema")
        for row in reader:
            try:
                round_id = int(row["round_id"])
                sample_ns = int(row["sample_ns"])
                data = {name: float(row[name]) for name in (
                    "destinations", "feed_queue_units", "feed_queue_bytes", "feed_drops",
                    "output_queue_units", "output_queue_bytes", "output_drops",
                    "sent_bytes", "blocked_sends", "retransmitted_packets")}
            except (TypeError, ValueError):
                raise ValueError("invalid queue sample row")
            if (round_id < 0 or sample_ns <= 0
                    or not all(math.isfinite(number) and number >= 0
                               and number.is_integer() for number in data.values())):
                raise ValueError("invalid queue sample row")
            key = (row["worker"], row["shard"])
            if key in queue_rows[round_id]:
                raise ValueError("duplicate queue sample row")
            queue_rows[round_id][key] = (sample_ns, data)
    rounds = sorted(queue_rows)
    if len(rounds) < 3 or rounds != list(range(len(rounds))):
        raise ValueError("incomplete queue sampling rounds; at least 3 required")
    for round_id in rounds:
        active = {key for key, (_, data) in queue_rows[round_id].items()
                  if data["destinations"] > 0}
        if active != keys:
            raise ValueError(f"queue round {round_id}: missing or unknown active sender shard")
        if sum(queue_rows[round_id][key][1]["destinations"] for key in keys) != len(expected):
            raise ValueError(f"queue round {round_id}: incomplete destination counts")
    for key in keys:
        first_ns = queue_rows[rounds[0]][key][0]
        last_ns = queue_rows[rounds[-1]][key][0]
        if (abs(first_ns - queue_start_ns) / 1e9 > args.max_interval_s
                or abs(queue_end_ns - last_ns) / 1e9 > args.max_interval_s):
            raise ValueError(f"{key}: queue samples do not cover the measurement window")

    peak_feed = 0.0
    peak_output = 0.0
    pressure_streak = defaultdict(int)
    blocked_streak = defaultdict(int)
    prior_values = {}
    for round_id in rounds:
        current = queue_rows[round_id]
        for shard, (sample_ns, data) in current.items():
            if data["destinations"] <= 0:
                continue
            old = prior_values.get(shard)
            consecutive = False
            if old is not None:
                old_round, old_ns, old_data = old
                gap_s = (sample_ns - old_ns) / 1e9
                if round_id != old_round + 1 or gap_s <= 0 or gap_s > args.max_interval_s:
                    raise ValueError(f"{shard}: queue sampling gap or nonpositive interval")
                consecutive = (
                    round_id == old_round + 1
                    and gap_s <= args.max_interval_s
                )
            if not consecutive:
                pressure_streak[(shard, "feed")] = 0
                pressure_streak[(shard, "output")] = 0
                blocked_streak[shard] = 0

            feed_util = max(data["feed_queue_units"] / 64,
                            data["feed_queue_bytes"] / (8 * 1024 * 1024))
            output_capacity = data["destinations"] * 256
            output_bytes_capacity = data["destinations"] * 8 * 1024 * 1024
            output_util = max(data["output_queue_units"] / output_capacity,
                              data["output_queue_bytes"] / output_bytes_capacity)
            peak_feed = max(peak_feed, feed_util)
            peak_output = max(peak_output, output_util)
            for kind, utilization in (("feed", feed_util), ("output", output_util)):
                if utilization >= args.queue_pressure:
                    pressure_streak[(shard, kind)] += 1
                    if pressure_streak[(shard, kind)] == args.pressure_samples:
                        failures.append(f"{shard[0]}/{shard[1]}: sustained {kind} queue pressure "
                                        f"{utilization:.3f} for {pressure_streak[(shard, kind)]} samples")
                else:
                    pressure_streak[(shard, kind)] = 0
            if consecutive:
                if data["blocked_sends"] > old_data["blocked_sends"]:
                    blocked_streak[shard] += 1
                else:
                    blocked_streak[shard] = 0
                if blocked_streak[shard] == args.blocked_samples:
                    failures.append(f"{shard[0]}/{shard[1]}: blocked sends increased for "
                                    f"{blocked_streak[shard]} consecutive samples")
            prior_values[shard] = (round_id, sample_ns, data)

    with open(args.destination_report, "w", newline="", encoding="utf-8") as output:
        writer = csv.writer(output)
        writer.writerow(("destination_id", "delivered_bytes", "average_bps",
                         "average_delivery_ratio", "minimum_interval_ratio",
                         "largest_interval_s", "ts_packets", "ts_sync_errors",
                         "ts_continuity_errors", "ts_tei_errors", "transport_error"))
        for destination, received, rate, ratio, low_ratio, max_interval, ts in rows:
            writer.writerow((destination, received, f"{rate:.2f}", f"{ratio:.5f}",
                             f"{low_ratio:.5f}", f"{max_interval:.3f}", ts["ts_packets"],
                             ts["ts_sync_errors"], ts["ts_continuity_errors"],
                             ts["ts_tei_errors"], ts["transport_error"]))

    print("quality_measurement_valid=yes")
    print(f"quality_pass={'no' if failures else 'yes'}")
    print(f"quality_reference_payload_bps={reference_bps:.2f}")
    print(f"quality_reference_payload_mbps={reference_bps / 1_000_000:.4f}")
    print(f"quality_prepared_source_payload_bps={prepared_source_bps:.2f}")
    print(f"quality_reference_vs_prepared_ratio={reference_vs_source_ratio:.5f}")
    print(f"quality_measurement_s={duration_s:.3f}")
    print(f"quality_window_start_ns={baseline_ns}")
    print(f"quality_window_end_ns={final_ns}")
    print(f"quality_clock_domain={args.clock_domain}")
    print("quality_start_uncertainty_ns=0")
    print("quality_end_uncertainty_ns=0")
    print(f"quality_offered_payload_bps={prepared_source_bps:.2f}")
    print("quality_offered_rate_provenance=prepared MPEG-TS bytes / source preparation duration")
    print(f"quality_total_receiver_bytes={sum(row[1] for row in rows)}")
    print(f"quality_average_delivery_ratio_min={min(row[3] for row in rows):.5f}")
    print(f"quality_interval_delivery_ratio_min={min(row[4] for row in rows):.5f}")
    print(f"quality_destination_fairness_jain={jain(all_rates):.5f} (supplementary)")
    print(f"quality_sender_feed_drops={queue_drops['nginx_media_srt_egress_shard_feed_queue_dropped_total']:g}")
    # A strict qualification, separate from the 0.95 compatibility gate the
    # ladder uses: every destination at full rate within a documented
    # tolerance, with nothing dropped, nothing corrupted and no short-interval
    # interruption.  A run can pass the gate and fail this - that is the point
    # of publishing both.
    strict_ratio_min = min(row[3] for row in rows)
    strict_interval_min = min(row[4] for row in rows)
    # TEI is corruption wherever it is counted: the gate treats a nonzero
    # count as an MPEG-TS error, so the strict verdict must not clear it.
    ts_errors = sum(ts["ts_sync_errors"] + ts["ts_continuity_errors"]
                    + ts.get("ts_tei_errors", 0)
                    for _, _, _, _, _, _, ts in rows)
    strict_ok = (strict_ratio_min >= args.strict_ratio
                 and strict_interval_min >= args.strict_interval_floor
                 and ts_errors == 0
                 and queue_drops['nginx_media_srt_egress_shard_feed_queue_dropped_total'] == 0
                 and queue_drops['nginx_media_srt_egress_shard_output_dropped_total'] == 0)
    print(f"quality_strict_full_rate={'yes' if strict_ok else 'no'}")
    print(f"quality_strict_ratio_min={strict_ratio_min:.5f}")
    print(f"quality_strict_ratio_tolerance={args.strict_ratio:.5f}")
    print(f"quality_strict_interval_floor={args.strict_interval_floor:.5f}")
    print(f"quality_strict_interval_min={strict_interval_min:.5f}")
    print(f"quality_strict_ts_errors={ts_errors}")
    print(f"quality_sender_output_drops={queue_drops['nginx_media_srt_egress_shard_output_dropped_total']:g}")
    print(f"quality_stream_feed_overruns={stream_overruns:g}")
    print(f"quality_stream_feed_retention_evictions={stream_evictions:g}")
    print(f"quality_peak_feed_queue_utilization={peak_feed:.4f}")
    print(f"quality_peak_output_queue_utilization={peak_output:.4f}")
    print(f"quality_complete_queue_samples={len(rounds)}")
    unique_failures = list(dict.fromkeys(failures))
    print(f"quality_failure_count={len(unique_failures)}")
    for failure in unique_failures[:25]:
        print(f"quality_failure={failure}")
    if len(unique_failures) > 25:
        print(f"quality_failure_more={len(unique_failures) - 25}")
    return 0


def finite_float(value):
    parsed = float(value)
    if not math.isfinite(parsed):
        raise argparse.ArgumentTypeError("must be finite")
    return parsed


def positive_finite_float(value):
    parsed = finite_float(value)
    if parsed <= 0:
        raise argparse.ArgumentTypeError("must be positive")
    return parsed


def main():
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="command", required=True)
    receivers = subparsers.add_parser("sample-receivers")
    receivers.add_argument("receiver_pid", type=int)
    receivers.add_argument("snapshot")
    receivers.add_argument("baseline")
    receivers.add_argument("output")
    receivers.add_argument("--interval", type=finite_float, default=1.0)
    receivers.add_argument("--ready-file")
    receivers.set_defaults(run=sample_receivers)
    queues = subparsers.add_parser("sample-queues")
    queues.add_argument("port", type=int)
    queues.add_argument("output")
    queues.add_argument("worker_pids", nargs="+")
    queues.add_argument("--interval", type=finite_float, default=1.0)
    queues.add_argument("--ready-file")
    queues.add_argument("--baseline-ready", required=True)
    queues.set_defaults(run=sample_queues)
    report = subparsers.add_parser("report")
    report.add_argument("--baseline", required=True)
    report.add_argument("--final", required=True)
    report.add_argument("--intervals", required=True)
    report.add_argument("--queues", required=True)
    report.add_argument("--queue-window")
    report.add_argument("--receiver-results", required=True)
    report.add_argument("--metrics-before", required=True)
    report.add_argument("--metrics-after", required=True)
    report.add_argument("--stream-before", required=True)
    report.add_argument("--stream-after", required=True)
    report.add_argument("--destination-report", required=True)
    report.add_argument("--interval-report", required=True)
    report.add_argument("--destinations", type=int, required=True)
    report.add_argument("--programs", type=int, default=1,
                        help="programs the rung ran; each owns its own set of "
                             "destinations, numbered pNNNN-dNNNN")
    report.add_argument("--prepared-source", required=True)
    report.add_argument("--clock-domain", required=True,
                        choices=("controller-monotonic", "receiver-monotonic"))
    report.add_argument("--source-duration-s", type=positive_finite_float,
                        default=30.0)
    report.add_argument("--reference-bps", type=finite_float, default=0.0)
    report.add_argument("--min-delivery-ratio", type=finite_float, default=0.95)
    # the strict qualification's documented tolerance: full rate means within
    # 0.1% of the reference, and no interval below 90% of it
    report.add_argument("--strict-ratio", type=finite_float, default=0.999)
    report.add_argument("--strict-interval-floor", type=finite_float,
                        default=0.90)
    report.add_argument("--interval-floor", type=finite_float, default=0.80)
    report.add_argument("--max-low-s", type=finite_float, default=2.0)
    report.add_argument("--max-interval-s", type=positive_finite_float,
                        default=2.0)
    report.add_argument("--queue-pressure", type=finite_float, default=0.90)
    report.add_argument("--pressure-samples", type=int, default=3)
    report.add_argument("--blocked-samples", type=int, default=3)
    report.set_defaults(run=quality_report)
    args = parser.parse_args()
    if getattr(args, "interval", 1.0) <= 0:
        parser.error("sampling interval must be positive")
    try:
        return args.run(args)
    except (OSError, RuntimeError, ValueError) as error:
        if args.command == "report":
            print("quality_measurement_valid=no")
            print("quality_pass=no")
            print("quality_strict_full_rate=no")
            print(f"quality_setup_failure={error}")
        print(f"srt_capacity_quality: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
