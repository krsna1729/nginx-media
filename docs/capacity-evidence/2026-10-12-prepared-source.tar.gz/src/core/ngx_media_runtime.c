#include "ngx_media_runtime.h"
#include "ngx_media_destination.h"
#include "ngx_media_executor.h"
#include "ngx_media_transform.h"
#include "ngx_media_file.h"
#include "ngx_media_graph.h"
#include "ngx_media_hls_ingest.h"
#include "ngx_media_hls_pull.h"
#include "ngx_media_hls_push.h"
#include "ngx_media_egress_manager.h"
#include "ngx_media_rtmp_destination.h"

#include <ngx_event.h>
#include <ngx_event_posted.h>

#include "ngx_media_hls_segmenter.h"
#include "ngx_media_record.h"
#include "ngx_media_route.h"
#include "ngx_media_selector.h"
#include "ngx_media_source.h"
#include "ngx_media_ts_demux.h"

#include <time.h>
/*
 * Per-stream outputs.  The program feed is drained on every runtime visit,
 * muxed into one burst and handed to HLS and to the PROGRAM recording; the
 * ISO tap muxes a named source before the selector and the RAW tap records
 * transport bytes before normalization (goal doc 20).
 */
typedef struct ngx_media_runtime_outputs_s ngx_media_runtime_outputs_t;
struct ngx_media_runtime_outputs_s {
    ngx_uint_t             used;
    ngx_media_stream_t    *stream;
    ngx_media_cursor_t     cursor;
    ngx_media_ts_mux_t     mux;
    ngx_media_ts_burst_t   burst;
    unsigned               burst_open:1;
    ngx_media_trackset_t  *tracks;
    ngx_media_hls_t        hls;
    unsigned               hls_ready:1;
    ngx_media_record_t     program;
    unsigned               program_ready:1;
    ngx_media_ts_mux_t     iso_mux;
    ngx_media_ts_burst_t   iso_burst;
    ngx_media_trackset_t  *iso_tracks;
    unsigned               iso_open:1;
    ngx_media_record_t     iso;
    unsigned               iso_ready:1;

    /* One external transform feeds one shared prepared package feed. */
    ngx_media_executor_t   executor;
    ngx_media_ts_demux_t   transform_demux;
    ngx_media_prepared_feed_t prepared_feed;
    ngx_media_cursor_t     prepared_cursor;
    ngx_media_ts_mux_t     package_mux;
    ngx_media_ts_burst_t   package_burst;
    ngx_media_trackset_t  *package_tracks;
    unsigned               package_burst_open:1;
    unsigned               transform_ready:1;
    unsigned               executor_events_ready:1;

    ngx_connection_t      *executor_input_connection;
    ngx_connection_t      *executor_output_connection;
    ngx_connection_t      *executor_error_connection;
    ngx_connection_t      *executor_pid_connection;

    uint64_t               generation;
    uint64_t               frames;
    uint64_t               bursts;

    /* when the destinations' segmentation limits were last applied */
    ngx_msec_t             limits_at;
    uint64_t               limits_revision;
    ngx_uint_t             limits_target;
    ngx_uint_t             limits_max;
    ngx_uint_t             limits_window;

    ngx_media_runtime_outputs_t *next;
};
typedef struct ngx_media_runtime_prepare_s ngx_media_runtime_prepare_t;
struct ngx_media_runtime_prepare_s {
    ngx_uint_t                 used;
    ngx_media_stream_t        *stream;
    ngx_media_cursor_t         cursor;
    ngx_media_rtmp_prepare_t   prepare;
    ngx_media_trackset_t      *tracks;
    ngx_media_runtime_prepare_t *next;
};

static ngx_media_runtime_outputs_t  *ngx_media_runtime_outputs;
static ngx_media_runtime_prepare_t  *ngx_media_runtime_prepares;
static ngx_uint_t                    ngx_media_runtime_outputs_count;

typedef struct {
    ngx_uint_t  frames;
    size_t      bytes;
    ngx_msec_t  started;
    ngx_uint_t  exhausted;
} ngx_media_runtime_budget_t;

static ngx_msec_t
ngx_media_runtime_clock_msec(void)
{
#if defined(CLOCK_MONOTONIC)
    struct timespec  ts;

    if (clock_gettime(CLOCK_MONOTONIC, &ts) == 0) {
        return (ngx_msec_t) ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
    }
#endif

    return ngx_current_msec;
}

static ngx_uint_t
ngx_media_runtime_budget_ready(ngx_media_runtime_budget_t *budget)
{
    if (budget == NULL) {
        return 0;
    }

    if (budget->frames >= NGX_MEDIA_RUNTIME_VISIT_MAX_FRAMES
        || budget->bytes >= NGX_MEDIA_RUNTIME_VISIT_MAX_BYTES
        || (budget->frames > 0
            && ngx_media_runtime_clock_msec() - budget->started
               >= NGX_MEDIA_RUNTIME_VISIT_MAX_MS))
    {
        budget->exhausted = 1;
        return 0;
    }

    return 1;
}

static void
ngx_media_runtime_budget_account(ngx_media_runtime_budget_t *budget,
    ngx_media_frame_t *frames, ngx_uint_t count)
{
    ngx_uint_t  i;

    if (budget == NULL) {
        return;
    }

    budget->frames += count;

    for (i = 0; i < count; i++) {
        if (frames[i].payload != NULL) {
            budget->bytes += frames[i].payload->len;
        }
    }
}


static ngx_media_record_t   ngx_media_runtime_raw;
static ngx_uint_t           ngx_media_runtime_raw_started;

static ngx_media_owner_dir_t     *ngx_media_runtime_owners;

/* sources that live in another worker and are fed through the routing layer */
#define NGX_MEDIA_RUNTIME_MAX_ROUTED 32

#define NGX_MEDIA_RUNTIME_MAX_TRACK_CONFIG  (64 * 1024)

typedef struct {
    ngx_uint_t              used;
    ngx_uint_t              peer;

    /*
     * The stream identity the sender addressed.  It was uint32_t here while
     * the IPC header, the owner directory and the routing table all key on
     * the full 64-bit hash, so a routed source was looked up under a
     * truncated identity that could resolve to another stream's slot.
     */
    uint64_t                hash;
    uint64_t                incarnation;
    /* the publisher connection this slot serves; see ngx_media_ipc.h */
    uint64_t                session;
    /* the routed OPEN created the source, so the last CLOSE deletes it */
    unsigned                created:1;
    /* the sender's frame numbering, to see what never arrived */
    unsigned                sequenced:1;
    uint64_t                next_sequence;
    ngx_media_stream_t     *stream;
    ngx_media_source_t     *source;
    /* reassembly of one publisher's chunked frames, one per routed endpoint */
    ngx_media_ipc_frame_t   frame;
} ngx_media_runtime_routed_t;

static ngx_media_runtime_routed_t ngx_media_runtime_routed[
    NGX_MEDIA_RUNTIME_MAX_ROUTED];
static uint64_t                   ngx_media_runtime_routed_frames;
static uint64_t                   ngx_media_runtime_routed_msgs;
static uint64_t                   ngx_media_runtime_routed_nopayload;
static ngx_media_runtime_stats_t  ngx_media_runtime_stats;
static ngx_media_runtime_sink_pt  ngx_media_runtime_sink;
static void                      *ngx_media_runtime_sink_ctx;
static uint64_t                   ngx_media_runtime_prepared_next_id = 1;

static ngx_event_t          ngx_media_runtime_timer;
static ngx_event_t          ngx_media_runtime_wakeup_event;
static ngx_uint_t           ngx_media_runtime_in_tick;
static ngx_uint_t           ngx_media_runtime_timer_visit;
static ngx_uint_t           ngx_media_runtime_armed;
static ngx_msec_t           ngx_media_runtime_last_idle_log;
/* Accepted transport sessions also retain their worker during graceful drain. */
static ngx_uint_t           ngx_media_runtime_sessions;

static ngx_str_t            ngx_media_runtime_none = ngx_string("none");

extern ngx_module_t  ngx_media_core_module;

static ngx_media_policy_t *
ngx_media_runtime_policy(void)
{
    ngx_media_policy_t  *policy;

    policy = (ngx_media_policy_t *)
                 ((ngx_cycle_t *) ngx_cycle)
                     ->conf_ctx[ngx_media_core_module.index];

    if (policy == NULL) {
        policy = ngx_media_policy_get((ngx_cycle_t *) ngx_cycle);
    }

    return policy;
}

/* --- outputs ------------------------------------------------------------- */

static void
ngx_media_runtime_outputs_stop(ngx_media_runtime_outputs_t *out);
static ngx_int_t ngx_media_runtime_transform_demux_init(
    ngx_media_runtime_outputs_t *out, ngx_log_t *log);
static ngx_int_t ngx_media_runtime_transform_init(
    ngx_media_runtime_outputs_t *out, const ngx_media_executor_conf_t *conf,
    ngx_log_t *log);
static void ngx_media_runtime_transform_output(void *ctx, const u_char *data,
    size_t len, uint64_t epoch);
static void ngx_media_runtime_transform_event(void *ctx,
    const ngx_media_executor_event_t *event);
static void ngx_media_runtime_executor_io(void *ctx, ngx_uint_t active);
static void ngx_media_runtime_executor_output_handler(ngx_event_t *ev);
static void ngx_media_runtime_executor_error_handler(ngx_event_t *ev);
static void ngx_media_runtime_executor_input_handler(ngx_event_t *ev);
static void ngx_media_runtime_executor_pid_handler(ngx_event_t *ev);
static void ngx_media_runtime_executor_update_input(
    ngx_media_runtime_outputs_t *out);
static void
ngx_media_runtime_executor_close_connection(ngx_connection_t **connection,
    ngx_uint_t write)
{
    ngx_connection_t  *c;

    if (connection == NULL || *connection == NULL) {
        return;
    }

    c = *connection;

    if (write) {
        if (c->write->active) {
            (void) ngx_del_event(c->write, NGX_WRITE_EVENT, 0);
        }

    } else {
        if (c->read->active) {
            (void) ngx_del_event(c->read, NGX_READ_EVENT, 0);
        }
    }

    c->fd = (ngx_socket_t) -1;
    ngx_free_connection(c);
    *connection = NULL;
}
static void
ngx_media_runtime_executor_unwire(ngx_media_runtime_outputs_t *out)
{
    if (out == NULL) {
        return;
    }

    out->executor_events_ready = 0;
    ngx_media_runtime_executor_close_connection(
        &out->executor_input_connection, 1);
    ngx_media_runtime_executor_close_connection(
        &out->executor_output_connection, 0);
    ngx_media_runtime_executor_close_connection(
        &out->executor_error_connection, 0);
    ngx_media_runtime_executor_close_connection(
        &out->executor_pid_connection, 0);
}


static void
ngx_media_runtime_executor_io(void *ctx, ngx_uint_t active)
{
    ngx_media_runtime_outputs_t  *out = ctx;
    ngx_connection_t             *c;
    ngx_log_t                     *log;

    if (out == NULL) {
        return;
    }

    if (!active) {
        ngx_media_runtime_executor_unwire(out);
        return;
    }

    log = ngx_cycle->log;
    ngx_media_runtime_executor_unwire(out);

    c = ngx_get_connection(out->executor.output_fd, log);
    if (c == NULL) {
        goto failed;
    }
    out->executor_output_connection = c;
    c->data = out;
    c->read->handler = ngx_media_runtime_executor_output_handler;
    c->read->log = log;

    if (ngx_add_event(c->read, NGX_READ_EVENT, 0) != NGX_OK) {
        goto failed;
    }

    c = ngx_get_connection(out->executor.error_fd, log);
    if (c == NULL) {
        goto failed;
    }
    out->executor_error_connection = c;
    c->data = out;
    c->read->handler = ngx_media_runtime_executor_error_handler;
    c->read->log = log;

    if (ngx_add_event(c->read, NGX_READ_EVENT, 0) != NGX_OK) {
        goto failed;
    }

    c = ngx_get_connection(out->executor.input_fd, log);
    if (c == NULL) {
        goto failed;
    }
    out->executor_input_connection = c;
    c->data = out;
    c->write->handler = ngx_media_runtime_executor_input_handler;
    c->write->log = log;

    if (out->executor.pid_fd >= 0) {
        c = ngx_get_connection(out->executor.pid_fd, log);
        if (c == NULL) {
            goto failed;
        }
        out->executor_pid_connection = c;
        c->data = out;
        c->read->handler = ngx_media_runtime_executor_pid_handler;
        c->read->log = log;

        if (ngx_add_event(c->read, NGX_READ_EVENT, 0) != NGX_OK) {
            goto failed;
        }
    }

    out->executor_events_ready = 1;
    ngx_log_error(NGX_LOG_NOTICE, log, 0,
                  "media: transform executor event wiring ready for %V/%V "
                  "pidfd=%ui",
                  &out->stream->application, &out->stream->name,
                  (ngx_uint_t) (out->executor.pid_fd >= 0));
    ngx_media_runtime_executor_update_input(out);
    return;

failed:
    ngx_log_error(NGX_LOG_WARN, log, 0,
                  "media: transform executor event wiring failed for %V/%V; "
                  "using runtime fallback",
                  &out->stream->application, &out->stream->name);
    ngx_media_runtime_executor_unwire(out);
}

static void
ngx_media_runtime_executor_update_input(ngx_media_runtime_outputs_t *out)
{
    ngx_connection_t  *c;
    ngx_uint_t         want;

    if (out == NULL || !out->executor_events_ready
        || out->executor_input_connection == NULL)
    {
        return;
    }

    c = out->executor_input_connection;
    want = (ngx_media_executor_state(&out->executor)
            == NGX_MEDIA_EXECUTOR_RUNNING
            && ngx_media_executor_pending(&out->executor) > 0);

    if (want && !c->write->active) {
        if (ngx_add_event(c->write, NGX_WRITE_EVENT, 0) != NGX_OK) {
            ngx_media_runtime_executor_unwire(out);
        }

    } else if (!want && c->write->active) {
        (void) ngx_del_event(c->write, NGX_WRITE_EVENT, 0);
    }
}

static void
ngx_media_runtime_executor_output_handler(ngx_event_t *ev)
{
    ngx_connection_t            *c;
    ngx_media_runtime_outputs_t *out;

    c = ev != NULL ? ev->data : NULL;
    out = c != NULL ? c->data : NULL;
    if (out == NULL) {
        return;
    }

    ngx_media_executor_io(&out->executor, ngx_current_msec, ev->log);
    ngx_media_runtime_executor_update_input(out);
    ngx_media_runtime_wakeup();
}

static void
ngx_media_runtime_executor_error_handler(ngx_event_t *ev)
{
    ngx_connection_t            *c;
    ngx_media_runtime_outputs_t *out;

    c = ev != NULL ? ev->data : NULL;
    out = c != NULL ? c->data : NULL;
    if (out == NULL) {
        return;
    }

    ngx_media_executor_io(&out->executor, ngx_current_msec, ev->log);
    ngx_media_runtime_executor_update_input(out);
    ngx_media_runtime_wakeup();
}

static void
ngx_media_runtime_executor_input_handler(ngx_event_t *ev)
{
    ngx_connection_t            *c;
    ngx_media_runtime_outputs_t *out;

    c = ev != NULL ? ev->data : NULL;
    out = c != NULL ? c->data : NULL;
    if (out == NULL) {
        return;
    }

    ngx_media_executor_io(&out->executor, ngx_current_msec, ev->log);
    ngx_media_runtime_executor_update_input(out);
    ngx_media_runtime_wakeup();
}

static void
ngx_media_runtime_executor_pid_handler(ngx_event_t *ev)
{
    ngx_connection_t            *c;
    ngx_media_runtime_outputs_t *out;

    c = ev != NULL ? ev->data : NULL;
    out = c != NULL ? c->data : NULL;
    if (out == NULL) {
        return;
    }

    ngx_media_executor_io(&out->executor, ngx_current_msec, ev->log);
    ngx_media_runtime_executor_update_input(out);
    ngx_media_runtime_wakeup();
}

static void ngx_media_runtime_transform_tracks(void *ctx,
    const ngx_media_trackset_t *tracks);
static void ngx_media_runtime_transform_frame(void *ctx,
    const ngx_media_frame_t *frame);
static void ngx_media_runtime_package_flush(
    ngx_media_runtime_outputs_t *out);
static void ngx_media_runtime_package_drain(
    ngx_media_runtime_outputs_t *out, ngx_log_t *log,
    ngx_media_runtime_budget_t *budget);
static ngx_uint_t ngx_media_runtime_burst_keyframe(
    const ngx_media_ts_burst_t *burst);
static ngx_int_t
ngx_media_runtime_transform_demux_init(ngx_media_runtime_outputs_t *out,
    ngx_log_t *log)
{
    ngx_media_ts_demux_conf_t  conf;
    ngx_media_ts_sink_t        sink;

    ngx_memzero(&conf, sizeof(conf));
    conf.max_tracks = NGX_MEDIA_TS_DEFAULT_TRACKS;
    conf.max_au_bytes = NGX_MEDIA_TS_DEFAULT_AU_BYTES;

    ngx_memzero(&sink, sizeof(sink));
    sink.tracks = ngx_media_runtime_transform_tracks;
    sink.frame = ngx_media_runtime_transform_frame;

    return ngx_media_ts_demux_init(&out->transform_demux, &conf, &sink, out,
                                   log);
}

static ngx_int_t
ngx_media_runtime_transform_init(ngx_media_runtime_outputs_t *out,
    const ngx_media_executor_conf_t *conf, ngx_log_t *log)
{
    ngx_media_feed_conf_t  feed_conf;
    uint64_t               id;

    ngx_memzero(&feed_conf, sizeof(feed_conf));
    feed_conf.max_units = 2048;
    feed_conf.max_bytes = 32 * 1024 * 1024;
    feed_conf.max_age = 10000;

    id = ngx_media_runtime_prepared_next_id++;
    if (id == 0) {
        id = ngx_media_runtime_prepared_next_id++;
    }

    if (ngx_media_prepared_feed_init(&out->prepared_feed, id, 1,
                                     &feed_conf, log)
        != NGX_OK)
    {
        return NGX_ERROR;
    }

    ngx_media_feed_cursor_init(&out->prepared_feed.feed,
                               &out->prepared_cursor);

    if (ngx_media_ts_mux_init(&out->package_mux, NULL, log) != NGX_OK
        || ngx_media_runtime_transform_demux_init(out, log) != NGX_OK)
    {
        ngx_media_prepared_feed_destroy(&out->prepared_feed);
        ngx_media_ts_mux_destroy(&out->package_mux);
        return NGX_ERROR;
    }

    if (ngx_media_executor_init(&out->executor, conf,
                                ngx_media_runtime_transform_output,
                                ngx_media_runtime_transform_event,
                                out, log)
        != NGX_OK)
    {
        ngx_media_ts_demux_destroy(&out->transform_demux);
        ngx_media_prepared_feed_destroy(&out->prepared_feed);
        ngx_media_ts_mux_destroy(&out->package_mux);
        return NGX_ERROR;
    }
    ngx_media_executor_set_io_callback(&out->executor,
                                      ngx_media_runtime_executor_io);

    out->transform_ready = 1;

    if (ngx_media_executor_start(&out->executor, ngx_current_msec, log)
        != NGX_OK)
    {
        out->transform_ready = 0;
        ngx_media_executor_stop(&out->executor, log);
        ngx_media_ts_demux_destroy(&out->transform_demux);
        ngx_media_prepared_feed_destroy(&out->prepared_feed);
        ngx_media_ts_mux_destroy(&out->package_mux);
        return NGX_ERROR;
    }

    return NGX_OK;
}

static void
ngx_media_runtime_transform_output(void *ctx, const u_char *data, size_t len,
    uint64_t epoch)
{
    ngx_media_runtime_outputs_t *out = ctx;

    if (out == NULL || !out->transform_ready || data == NULL || len == 0
        || epoch != ngx_media_executor_epoch(&out->executor))
    {
        return;
    }

    (void) ngx_media_ts_demux_feed(&out->transform_demux, data, len);
}

static void
ngx_media_runtime_transform_event(void *ctx,
    const ngx_media_executor_event_t *event)
{
    ngx_media_runtime_outputs_t  *out = ctx;
    if (out == NULL || event == NULL) {
        return;
    }

    if (event->type == NGX_MEDIA_EXECUTOR_EVENT_STARTED
        || event->type == NGX_MEDIA_EXECUTOR_EVENT_RESTARTED)
    {
        ngx_log_error(NGX_LOG_NOTICE, ngx_cycle->log, 0,
                      "media: transform executor %s for %V/%V epoch %uL",
                      event->type == NGX_MEDIA_EXECUTOR_EVENT_STARTED
                      ? "started" : "restarted",
                      &out->stream->application, &out->stream->name,
                      event->epoch);
    }

    if (event->type == NGX_MEDIA_EXECUTOR_EVENT_FAILED) {
        ngx_log_error(NGX_LOG_WARN, ngx_cycle->log, 0,
                      "media: transform executor failed for %V/%V",
                      &out->stream->application, &out->stream->name);
    }

    if (event->type != NGX_MEDIA_EXECUTOR_EVENT_EPOCH) {
        return;
    }

    out->package_tracks = NULL;
    out->prepared_feed.epoch = event->epoch;
    ngx_media_feed_discontinuity(&out->prepared_feed.feed);

    if (out->hls_ready) {
        (void) ngx_media_hls_discontinuity(&out->hls);
    }

    ngx_media_ts_demux_destroy(&out->transform_demux);
    (void) ngx_media_runtime_transform_demux_init(out, ngx_cycle->log);
}

static void
ngx_media_runtime_transform_tracks(void *ctx,
    const ngx_media_trackset_t *tracks)
{
    ngx_media_runtime_outputs_t *out = ctx;

    if (out != NULL) {
        out->package_tracks = (ngx_media_trackset_t *) tracks;
    }
}

static void
ngx_media_runtime_transform_frame(void *ctx, const ngx_media_frame_t *frame)
{
    ngx_media_runtime_outputs_t *out = ctx;

    if (out == NULL || frame == NULL) {
        return;
    }

    (void) ngx_media_prepared_feed_publish(&out->prepared_feed, frame,
                                           ngx_current_msec);
}

static void
ngx_media_runtime_package_flush(ngx_media_runtime_outputs_t *out)
{
    size_t len;

    if (!out->package_burst_open) {
        return;
    }

    if (ngx_media_ts_mux_burst_end(&out->package_mux, &out->package_burst)
        == NGX_OK)
    {
        len = ngx_media_ts_burst_size(&out->package_burst);

        if (len > 0) {
            if (out->hls_ready) {
                (void) ngx_media_hls_add_burst(&out->hls,
                                               &out->package_burst);
            }

            if (out->program_ready) {
                (void) ngx_media_record_append(&out->program,
                                               out->package_burst.backing,
                                               0, len);
            }

            if (ngx_media_runtime_sink != NULL) {
                ngx_media_runtime_sink(ngx_media_runtime_sink_ctx,
                                       out->stream,
                                       out->package_burst.backing, len,
                                       ngx_media_runtime_burst_keyframe(
                                           &out->package_burst));
            }
        }
    }

    ngx_media_ts_mux_burst_destroy(&out->package_burst);
    out->package_burst_open = 0;
}

static void
ngx_media_runtime_package_drain(ngx_media_runtime_outputs_t *out,
    ngx_log_t *log, ngx_media_runtime_budget_t *budget)
{
    ngx_media_frame_t  frames[64];
    ngx_uint_t          count, i, status, max_units;
    size_t              max_bytes;

    for (;;) {
        if (!ngx_media_runtime_budget_ready(budget)) {
            break;
        }

        max_units = 64;
        max_bytes = 512 * 1024;

        if (budget != NULL) {
            if (max_units > NGX_MEDIA_RUNTIME_VISIT_MAX_FRAMES
                              - budget->frames)
            {
                max_units = NGX_MEDIA_RUNTIME_VISIT_MAX_FRAMES
                            - budget->frames;
            }

            if (max_bytes > NGX_MEDIA_RUNTIME_VISIT_MAX_BYTES
                              - budget->bytes)
            {
                max_bytes = NGX_MEDIA_RUNTIME_VISIT_MAX_BYTES
                            - budget->bytes;
            }
        }

        if (max_units == 0 || max_bytes == 0) {
            if (budget != NULL) {
                budget->exhausted = 1;
            }
            break;
        }

        status = ngx_media_feed_read(&out->prepared_feed.feed,
                                     &out->prepared_cursor, max_units,
                                     max_bytes, ngx_current_msec, frames,
                                     &count);

        if (status == NGX_MEDIA_FEED_GENERATION_MISMATCH
            || status == NGX_MEDIA_FEED_OVERRUN)
        {
            if (out->hls_ready) {
                (void) ngx_media_hls_discontinuity(&out->hls);
            }

            (void) ngx_media_feed_resync(&out->prepared_feed.feed,
                                         &out->prepared_cursor,
                                         NGX_MEDIA_FEED_RESYNC_KEYFRAME);
            continue;
        }

        if (status != NGX_MEDIA_FEED_BATCH) {
            break;
        }

        ngx_media_runtime_budget_account(budget, frames, count);

        if (out->package_tracks != NULL
            && ngx_media_ts_mux_set_tracks(&out->package_mux,
                                           out->package_tracks) == NGX_OK)
        {
            /* Track contracts are immutable for this demux epoch. */
        }

        if (!out->package_burst_open
            && ngx_media_ts_mux_burst_init(&out->package_mux,
                                           &out->package_burst,
                                           256 * 1024) != NGX_OK)
        {
            ngx_media_feed_release(frames, count);
            return;
        }

        out->package_burst_open = 1;

        for (i = 0; i < count; i++) {
            if (ngx_media_ts_mux_write_frame(&out->package_mux,
                                             &out->package_burst,
                                             &frames[i], 0) == NGX_AGAIN)
            {
                ngx_media_runtime_package_flush(out);

                if (ngx_media_ts_mux_burst_init(&out->package_mux,
                                                &out->package_burst,
                                                256 * 1024) != NGX_OK)
                {
                    continue;
                }

                out->package_burst_open = 1;
                (void) ngx_media_ts_mux_write_frame(&out->package_mux,
                                                    &out->package_burst,
                                                    &frames[i], 0);
            }
        }

        ngx_media_feed_release(frames, count);
        ngx_media_runtime_package_flush(out);
    }

    (void) log;
}

static ngx_media_runtime_outputs_t *
ngx_media_runtime_outputs_get(ngx_media_stream_t *stream, ngx_log_t *log)
{
    ngx_media_policy_t              *policy = ngx_media_runtime_policy();
    ngx_media_runtime_outputs_t     *out;
    ngx_media_hls_conf_t             hls_conf;
    ngx_media_record_conf_t          rec_conf;

    if (stream == NULL) {
        return NULL;
    }

    for (out = ngx_media_runtime_outputs; out != NULL; out = out->next) {
        if (out->used && out->stream == stream) {
            return out;
        }
    }

    out = ngx_alloc(sizeof(ngx_media_runtime_outputs_t), log);
    if (out == NULL) {
        return NULL;
    }
    ngx_memzero(out, sizeof(ngx_media_runtime_outputs_t));

    out->used = 1;
    out->stream = stream;
    out->generation = stream->generation;

    ngx_media_feed_cursor_init(&stream->program_feed, &out->cursor);

    if (ngx_media_ts_mux_init(&out->mux, NULL, log) != NGX_OK) {
        ngx_free(out);
        return NULL;
    }

    if (policy == NULL) {
        goto active;
    }

    if (policy->hls_path.len > 0) {
        ngx_str_t  *dir = ngx_media_hls_program_dir(stream->pool,
            &policy->hls_path, &stream->application, &stream->name);

        if (dir == NULL) {
            ngx_media_runtime_outputs_stop(out);
            ngx_free(out);
            return NULL;
        }

        ngx_media_hls_conf_default(&hls_conf);

        hls_conf.path = *dir;
        hls_conf.target_duration = NGX_MEDIA_RUNTIME_HLS_TARGET;
        hls_conf.min_duration = NGX_MEDIA_RUNTIME_HLS_MIN;
        hls_conf.max_duration = NGX_MEDIA_RUNTIME_HLS_MAX;
        hls_conf.max_segments = NGX_MEDIA_RUNTIME_HLS_WINDOW;

        if (ngx_media_hls_init(&out->hls, &hls_conf, log) != NGX_OK) {
            ngx_media_runtime_outputs_stop(out);
            ngx_free(out);
            return NULL;
        }

        out->hls_ready = 1;
        out->limits_target = NGX_MEDIA_RUNTIME_HLS_TARGET;
        out->limits_max = NGX_MEDIA_RUNTIME_HLS_MAX;
        out->limits_window = NGX_MEDIA_RUNTIME_HLS_WINDOW;

        ngx_log_error(NGX_LOG_NOTICE, log, 0,
                      "media: hls output started for %V/%V in %V",
                      &stream->application, &stream->name, dir);
    }

    if (policy->record_program_path.len > 0) {
        ngx_media_record_conf_default(&rec_conf);

        rec_conf.path = policy->record_program_path;
        rec_conf.tap = NGX_MEDIA_RECORD_PROGRAM;

        if (ngx_media_record_init(&out->program, &rec_conf, log) != NGX_OK) {
            ngx_media_runtime_outputs_stop(out);
            ngx_free(out);
            return NULL;
        }

        out->program_ready = 1;

        ngx_log_error(NGX_LOG_NOTICE, log, 0,
                      "media: program recording started for %V/%V",
                      &stream->application, &stream->name);
    }

    if (policy->record_iso_path.len > 0) {
        ngx_media_record_conf_default(&rec_conf);

        rec_conf.path = policy->record_iso_path;
        rec_conf.tap = NGX_MEDIA_RECORD_ISO;

        if (ngx_media_ts_mux_init(&out->iso_mux, NULL, log) != NGX_OK
            || ngx_media_record_init(&out->iso, &rec_conf, log) != NGX_OK)
        {
            ngx_media_runtime_outputs_stop(out);
            ngx_free(out);
            return NULL;
        }

        out->iso_ready = 1;

        ngx_log_error(NGX_LOG_NOTICE, log, 0,
                      "media: iso recording started for %V/%V source %V",
                      &stream->application, &stream->name,
                      &policy->record_iso_source);
    }

    if (stream->media_mode == NGX_MEDIA_STREAM_MEDIA_PROFILE
        && policy->transform_executor.executable.len > 0
        && ngx_media_runtime_transform_init(out,
                                            &policy->transform_executor,
                                            log)
           != NGX_OK)
    {
        ngx_media_runtime_outputs_stop(out);
        ngx_free(out);
        return NULL;
    }

active:
    out->next = ngx_media_runtime_outputs;
    ngx_media_runtime_outputs = out;
    ngx_media_runtime_outputs_count++;
    return out;
}

/*
 * A destination profile's segment duration drives the stream's segmenter.
 * Segmentation is shared by every consumer of a program - the local origin
 * and every push destination read the same segments - so the strictest
 * destination sets it: the shortest requested duration becomes the target
 * and the keyframe threshold, and the forced cut stays at twice that (never
 * above the default ceiling).  Removing the destination restores the
 * defaults.  Applied at most once a second; a change takes effect at the
 * next segment boundary.  The playlist window is per destination and is
 * applied where each destination's playlist is uploaded.
 */
static void
ngx_media_runtime_hls_limits(ngx_media_runtime_outputs_t *out,
    ngx_msec_t now)
{
    ngx_media_destination_t  *destination;
    ngx_queue_t              *q;
    ngx_uint_t                target = 0, max = 0;
    ngx_uint_t                window = NGX_MEDIA_RUNTIME_HLS_WINDOW;

    /*
     * On every change to the stream's desired state - a destination added,
     * removed or toggled - so a destination's first segment is already cut
     * to its rules, and once a second besides.
     */
    if (!out->hls_ready
        || (out->limits_revision == out->stream->revision
            && out->limits_at != 0 && now - out->limits_at < 1000))
    {
        return;
    }

    out->limits_at = now;
    out->limits_revision = out->stream->revision;

    /*
     * The strictest of the stream's HLS push destinations: the shortest
     * segment any of them asks for, the tightest ceiling any of them states,
     * and the longest window any of them lists.  Each destination then gets
     * its own window from the playlist rewrite; the segments are shared.
     */
    for (q = ngx_queue_head(&out->stream->destinations);
         q != ngx_queue_sentinel(&out->stream->destinations);
         q = ngx_queue_next(q))
    {
        destination = ngx_queue_data(q, ngx_media_destination_t, queue);

        if (destination->type != NGX_MEDIA_DEST_HLS_PUSH
            || !destination->enabled)
        {
            continue;
        }

        if (destination->segment_duration_ms > 0
            && (target == 0 || destination->segment_duration_ms < target))
        {
            target = destination->segment_duration_ms;
        }

        if (destination->segment_max_ms > 0
            && (max == 0 || destination->segment_max_ms < max))
        {
            max = destination->segment_max_ms;
        }

        if (destination->playlist_window > window) {
            window = destination->playlist_window;
        }
    }

    if (target == 0) {
        target = NGX_MEDIA_RUNTIME_HLS_TARGET;
    }

    if (max == 0) {
        max = (target == NGX_MEDIA_RUNTIME_HLS_TARGET)
              ? NGX_MEDIA_RUNTIME_HLS_MAX : target * 2;
    }

    if (max < target) {
        max = target;
    }

    if (window > NGX_MEDIA_HLS_SEGMENTS_MAX) {
        window = NGX_MEDIA_HLS_SEGMENTS_MAX;
    }

    if (target == out->limits_target && max == out->limits_max
        && window == out->limits_window)
    {
        return;
    }

    out->hls.conf.target_duration = target;
    out->hls.conf.min_duration = target;
    out->hls.conf.max_duration = max;
    out->hls.conf.max_segments = window;
    out->limits_target = target;
    out->limits_max = max;
    out->limits_window = window;

    ngx_log_error(NGX_LOG_NOTICE, ngx_cycle->log, 0,
                  "media: hls segmentation for %V/%V is now %ui-%ui ms, "
                  "window %ui, for its destinations",
                  &out->stream->application, &out->stream->name,
                  target, max, window);
}

static ngx_media_runtime_outputs_t *
ngx_media_runtime_outputs_find(ngx_media_stream_t *stream)
{
    ngx_media_runtime_outputs_t  *out;

    for (out = ngx_media_runtime_outputs; out != NULL; out = out->next) {
        if (out->used && out->stream == stream) {
            return out;
        }
    }

    return NULL;
}

ngx_int_t
ngx_media_runtime_package(ngx_media_stream_t *stream, ngx_log_t *log)
{
    return ngx_media_runtime_outputs_get(stream, log) != NULL
           ? NGX_OK : NGX_ERROR;
}

ngx_int_t
ngx_media_runtime_admit(ngx_media_stream_t *stream, ngx_log_t *log)
{
    ngx_media_policy_t          *policy;
    ngx_media_runtime_outputs_t *out;

    if (stream == NULL) {
        return NGX_ERROR;
    }

    policy = ngx_media_runtime_policy();
    if (stream->media_mode == NGX_MEDIA_STREAM_MEDIA_PROFILE
        && (policy == NULL || policy->transform_executor.executable.len == 0))
    {
        ngx_log_error(NGX_LOG_ERR, log, 0,
                      "media: profile transform is not configured for %V/%V",
                      &stream->application, &stream->name);
        return NGX_ERROR;
    }


    if (policy == NULL
        || (policy->hls_path.len == 0
            && policy->record_program_path.len == 0
            && policy->record_iso_path.len == 0
            && policy->transform_executor.executable.len == 0))
    {
        return NGX_OK;
    }

    out = ngx_media_runtime_outputs_get(stream, log);

    if (out == NULL) {
        ngx_log_error(NGX_LOG_ERR, log, 0,
                      "media: no runtime output capacity for %V/%V",
                      &stream->application, &stream->name);
        return NGX_ERROR;
    }

    return NGX_OK;
}

void
ngx_media_runtime_set_sink(ngx_media_runtime_sink_pt cb, void *ctx)
{
    ngx_media_runtime_sink = cb;
    ngx_media_runtime_sink_ctx = ctx;
}

/* does this burst carry a video sync point a receiver may resume at? */
static ngx_uint_t
ngx_media_runtime_burst_keyframe(const ngx_media_ts_burst_t *burst)
{
    ngx_uint_t  i;

    for (i = 0; i < burst->nslices; i++) {

        if (burst->slices[i].media_type == NGX_MEDIA_TYPE_VIDEO
            && burst->slices[i].keyframe)
        {
            return 1;
        }
    }

    return 0;
}

static void
ngx_media_runtime_outputs_flush(ngx_media_runtime_outputs_t *out)
{
    size_t  len;

    if (!out->burst_open) {
        return;
    }
    if (out->transform_ready) {
        if (ngx_media_ts_mux_burst_end(&out->mux, &out->burst) == NGX_OK) {
            len = ngx_media_ts_burst_size(&out->burst);

            if (len > 0
                && ngx_media_executor_feed(&out->executor,
                                           out->burst.backing, 0, len)
                   != NGX_OK)
            {
                ngx_log_error(NGX_LOG_WARN, ngx_cycle->log, 0,
                              "media: transform input journal is full for "
                              "%V/%V",
                              &out->stream->application, &out->stream->name);
            }
        }
        ngx_media_runtime_executor_update_input(out);

        out->bursts++;
        ngx_media_ts_mux_burst_destroy(&out->burst);
        out->burst_open = 0;
        return;
    }


    if (ngx_media_ts_mux_burst_end(&out->mux, &out->burst) == NGX_OK) {
        len = ngx_media_ts_burst_size(&out->burst);

        if (len > 0) {

            if (out->hls_ready) {
                (void) ngx_media_hls_add_burst(&out->hls, &out->burst);
            }

            if (out->program_ready) {
                (void) ngx_media_record_append(&out->program,
                                               out->burst.backing, 0, len);
            }

            if (ngx_media_runtime_sink != NULL) {
                ngx_media_runtime_sink(ngx_media_runtime_sink_ctx,
                                       out->stream, out->burst.backing, len,
                                       ngx_media_runtime_burst_keyframe(
                                           &out->burst));
            }
        }

        out->bursts++;
    }

    ngx_media_ts_mux_burst_destroy(&out->burst);
    out->burst_open = 0;
}

static void
ngx_media_runtime_iso_flush(ngx_media_runtime_outputs_t *out)
{
    size_t  len;

    if (!out->iso_open) {

        return;
    }

    if (ngx_media_ts_mux_burst_end(&out->iso_mux, &out->iso_burst) == NGX_OK) {
        len = ngx_media_ts_burst_size(&out->iso_burst);

        if (len > 0 && out->iso_ready) {
            (void) ngx_media_record_append(&out->iso, out->iso_burst.backing,
                                           0, len);
        }
    }

    ngx_media_ts_mux_burst_destroy(&out->iso_burst);
    out->iso_open = 0;
}

static void
ngx_media_runtime_outputs_drain(ngx_media_runtime_outputs_t *out,
    ngx_log_t *log, ngx_media_runtime_budget_t *budget)
{
    ngx_media_frame_t   frames[64];
    ngx_media_stream_t  *stream = out->stream;
    ngx_uint_t           count, i, status, max_units;
    size_t               max_bytes;

    if (out->generation != stream->generation) {
        out->generation = stream->generation;

        if (out->transform_ready) {
            ngx_media_executor_stop(&out->executor, log);

            if (ngx_media_executor_start(&out->executor, ngx_current_msec,
                                         log)
                != NGX_OK)
            {
                ngx_log_error(NGX_LOG_WARN, log, 0,
                              "media: transform executor epoch restart "
                              "deferred for %V/%V",
                              &stream->application, &stream->name);
            }

        } else if (out->hls_ready) {
            (void) ngx_media_hls_discontinuity(&out->hls);
        }
    }


    for ( ;; ) {
        if (!ngx_media_runtime_budget_ready(budget)) {
            break;
        }

        max_units = 64;
        max_bytes = 512 * 1024;

        if (budget != NULL) {
            if (max_units > NGX_MEDIA_RUNTIME_VISIT_MAX_FRAMES
                              - budget->frames)
            {
                max_units = NGX_MEDIA_RUNTIME_VISIT_MAX_FRAMES
                            - budget->frames;
            }

            if (max_bytes > NGX_MEDIA_RUNTIME_VISIT_MAX_BYTES
                              - budget->bytes)
            {
                max_bytes = NGX_MEDIA_RUNTIME_VISIT_MAX_BYTES
                            - budget->bytes;
            }
        }

        if (max_units == 0 || max_bytes == 0) {
            if (budget != NULL) {
                budget->exhausted = 1;
            }
            break;
        }

        status = ngx_media_feed_read(&stream->program_feed, &out->cursor,
                                     max_units, max_bytes, ngx_current_msec,
                                     frames, &count);

        if (status == NGX_MEDIA_FEED_GENERATION_MISMATCH) {
            /* a switch is a discontinuity for every consumer */
            if (out->hls_ready) {
                (void) ngx_media_hls_discontinuity(&out->hls);
            }

            (void) ngx_media_feed_resync(&stream->program_feed, &out->cursor,
                                         NGX_MEDIA_FEED_RESYNC_KEYFRAME);
            continue;
        }

        if (status == NGX_MEDIA_FEED_OVERRUN) {
            (void) ngx_media_feed_resync(&stream->program_feed, &out->cursor,
                                         NGX_MEDIA_FEED_RESYNC_KEYFRAME);

            continue;
        }

        if (status != NGX_MEDIA_FEED_BATCH) {
            break;
        }
        ngx_media_runtime_budget_account(budget, frames, count);

        if (stream->active != NULL && stream->active->tracks != NULL
            && out->tracks != stream->active->tracks)
        {
            if (ngx_media_ts_mux_set_tracks(&out->mux,
                                            stream->active->tracks) == NGX_OK)
            {
                out->tracks = stream->active->tracks;
            }
        }

        if (!out->burst_open
            && ngx_media_ts_mux_burst_init(&out->mux, &out->burst,
                                           256 * 1024) != NGX_OK)
        {
            ngx_media_feed_release(frames, count);
            return;
        }

        out->burst_open = 1;

        for (i = 0; i < count; i++) {

            if (ngx_media_ts_mux_write_frame(&out->mux, &out->burst,
                                             &frames[i], 0) == NGX_AGAIN)
            {
                ngx_media_runtime_outputs_flush(out);

                if (ngx_media_ts_mux_burst_init(&out->mux, &out->burst,
                                                256 * 1024) != NGX_OK)
                {
                    continue;
                }

                out->burst_open = 1;

                (void) ngx_media_ts_mux_write_frame(&out->mux, &out->burst,
                                                    &frames[i], 0);
            }

            out->frames++;
        }

        ngx_media_feed_release(frames, count);

        ngx_media_runtime_outputs_flush(out);
    }
    if (out->transform_ready) {
        ngx_media_executor_maintenance(&out->executor, ngx_current_msec, log);

        if (!out->executor_events_ready) {
            ngx_media_executor_io(&out->executor, ngx_current_msec, log);
        }
        ngx_media_runtime_package_drain(out, log, budget);
    }

}

void
ngx_media_runtime_iso_source(ngx_media_stream_t *stream,
    ngx_media_source_t *source, const ngx_media_frame_t *frame)
{
    ngx_media_policy_t              *policy = ngx_media_runtime_policy();
    ngx_media_runtime_outputs_t     *out;

    if (policy == NULL || policy->record_iso_path.len == 0 || stream == NULL
        || source == NULL)
    {
        return;
    }

    if (policy->record_iso_source.len != source->id.len
        || ngx_memcmp(policy->record_iso_source.data, source->id.data,
                      source->id.len) != 0)
    {
        return;
    }

    out = ngx_media_runtime_outputs_get(stream, ngx_cycle->log);

    if (out == NULL || !out->iso_ready) {
        return;
    }

    if (source->tracks != NULL && out->iso_tracks != source->tracks) {

        if (ngx_media_ts_mux_set_tracks(&out->iso_mux, source->tracks)
            == NGX_OK)
        {
            out->iso_tracks = source->tracks;
        }
    }

    if (!out->iso_open) {

        if (ngx_media_ts_mux_burst_init(&out->iso_mux, &out->iso_burst,
                                        64 * 1024) != NGX_OK)
        {
            return;
        }

        out->iso_open = 1;
    }

    if (ngx_media_ts_mux_write_frame(&out->iso_mux, &out->iso_burst, frame,
                                     0) == NGX_AGAIN)
    {
        ngx_media_runtime_iso_flush(out);

        if (ngx_media_ts_mux_burst_init(&out->iso_mux, &out->iso_burst,
                                        64 * 1024) != NGX_OK)
        {
            return;
        }

        out->iso_open = 1;

        (void) ngx_media_ts_mux_write_frame(&out->iso_mux, &out->iso_burst,
                                            frame, 0);
    }

    if (ngx_media_ts_burst_size(&out->iso_burst) > 48 * 1024) {
        ngx_media_runtime_iso_flush(out);
    }
}

ngx_uint_t
ngx_media_runtime_raw_ready(void)
{
    return ngx_media_runtime_raw_started;
}

ngx_int_t
ngx_media_runtime_raw_bytes(const u_char *data, size_t len)
{
    if (!ngx_media_runtime_raw_started) {
        return NGX_DECLINED;
    }

    return ngx_media_record_append_bytes(&ngx_media_runtime_raw, data, len);
}

static void
ngx_media_runtime_outputs_stop(ngx_media_runtime_outputs_t *out)
{
    if (!out->used) {
        return;
    }

    ngx_media_runtime_outputs_flush(out);
    ngx_media_runtime_iso_flush(out);
    if (out->transform_ready) {
        ngx_media_runtime_package_flush(out);
        ngx_media_executor_stop(&out->executor, ngx_cycle->log);
        ngx_media_ts_demux_destroy(&out->transform_demux);
        ngx_media_prepared_feed_destroy(&out->prepared_feed);
        ngx_media_ts_mux_destroy(&out->package_mux);
        out->transform_ready = 0;
    }


    if (out->hls_ready) {
        (void) ngx_media_hls_finish(&out->hls);
    }

    if (out->program_ready) {
        ngx_media_record_stop(&out->program);
    }

    if (out->iso_ready) {
        ngx_media_record_stop(&out->iso);
    }

    ngx_media_hls_destroy(&out->hls);
    ngx_media_ts_mux_destroy(&out->mux);
    ngx_media_ts_mux_destroy(&out->iso_mux);

    ngx_memzero(out, sizeof(ngx_media_runtime_outputs_t));
}

/* --- owner side of the routing escape hatch ------------------------------ */

static void
ngx_media_runtime_routed_close(ngx_media_runtime_routed_t *slot)
{
    ngx_media_stream_t  *stream = slot->stream;
    ngx_media_source_t  *source = slot->source;

    if (source->stream != stream) {
        /* The control plane already deleted the source. */
    } else if (slot->created) {
        ngx_media_stream_source_remove(stream, source);
        (void) ngx_media_graph_source_delete(stream, &source->id,
                                             stream->revision);
    } else {
        /* Provisioned state and its key survive publisher disconnect. */
        ngx_media_health_transport(&source->health, 0, ngx_current_msec);
    }

    ngx_media_ipc_frame_reset(&slot->frame);
    ngx_memzero(slot, sizeof(*slot));
}

void
ngx_media_runtime_session_acquire(void)
{
    ngx_media_runtime_sessions++;
}

void
ngx_media_runtime_session_release(void)
{
    ngx_media_runtime_sessions--;
}

static ngx_uint_t
ngx_media_runtime_drain_active(void)
{
    ngx_uint_t  i;

    if (ngx_media_runtime_sessions != 0) {
        return 1;
    }

    for (i = 0; i < NGX_MEDIA_RUNTIME_MAX_ROUTED; i++) {
        if (ngx_media_runtime_routed[i].used) {
            return 1;
        }
    }

    return 0;
}

/*
 * Frames that arrive from another worker are fed into the local program as if
 * the publisher were local: the owner creates the stream and source from the
 * OPEN message and publishes every frame through the normal path.
 */
static ngx_int_t
ngx_media_runtime_route_sink(void *ctx, ngx_uint_t peer, uint64_t hash,
    const ngx_media_ipc_header_t *header, ngx_media_buf_t *payload)
{
    ngx_media_registry_t  *registry;
    ngx_media_stream_t    *stream;
    ngx_media_source_t    *source;
    ngx_uint_t             created;
    ngx_str_t              application, name, source_id;
    u_char                *p, *slash;
    ngx_media_feed_conf_t  feed_conf;

    (void) ctx;

    if (header == NULL) {
        ngx_uint_t  i;

        for (i = 0; i < NGX_MEDIA_RUNTIME_MAX_ROUTED; i++) {
            if (ngx_media_runtime_routed[i].used
                && ngx_media_runtime_routed[i].peer == peer)
            {
                ngx_media_runtime_routed_close(&ngx_media_runtime_routed[i]);
            }
        }
        return NGX_OK;
    }


    /*
     * A graph operation is desired state, not media: it belongs to this
     * worker's registry and needs no program of its own.  Applying it here
     * keeps the control plane on the same transport as the routing escape
     * hatch, with the same encoder, framing and bounds.
     */
    if (header->type == NGX_MEDIA_IPC_MSG_GRAPH) {
        return ngx_media_graph_apply(header, payload);
    }

    registry = ngx_media_registry_get((ngx_cycle_t *) ngx_cycle);

    if (registry == NULL) {
        return NGX_ERROR;
    }


    if (header->type == NGX_MEDIA_IPC_MSG_OPEN) {

        if (header->incarnation == 0
            || payload == NULL || ngx_media_buf_size(payload) < 3)
        {
            return NGX_ERROR;
        }

        p = ngx_media_buf_data(payload);

        slash = ngx_strlchr(p, p + ngx_media_buf_size(payload), '/');

        if (slash == NULL) {
            return NGX_ERROR;
        }

        application.data = p;
        application.len = (size_t) (slash - p);

        name.data = slash + 1;

        slash = ngx_strlchr(name.data,
                            p + ngx_media_buf_size(payload), '/');

        if (slash == NULL) {
            return NGX_ERROR;
        }

        name.len = (size_t) (slash - name.data);

        source_id.data = slash + 1;
        source_id.len = ngx_media_buf_size(payload)
                        - application.len - name.len - 2;

        /*
         * The datagram itself is bounded, but its fields are copied into
         * long-lived pool objects below.  Keep the identity fields at the same
         * bound as graph operations; otherwise a peer could turn one OPEN
         * into a nearly-64 KiB stream/source allocation on every reconnect.
         */
        if (application.len == 0 || name.len == 0 || source_id.len == 0
            || application.len > NGX_MEDIA_GRAPH_MAX_NAME
            || name.len > NGX_MEDIA_GRAPH_MAX_NAME
            || source_id.len > NGX_MEDIA_GRAPH_MAX_NAME)
        {
            return NGX_ERROR;
        }

        feed_conf.max_units = 2048;
        feed_conf.max_bytes = 32 * 1024 * 1024;
        feed_conf.max_age = 10000;

        stream = ngx_media_registry_stream(registry, &application, &name);

        if (stream != NULL
            && stream->incarnation != header->incarnation)
        {
            ngx_media_runtime_stats.routed_identity_mismatches++;
            return NGX_OK;
        }

        if (stream == NULL) {
            stream = ngx_media_registry_stream_create(registry, &application,
                                                      &name, &feed_conf,
                                                      ngx_cycle->log);

            if (stream != NULL) {
                stream->incarnation = header->incarnation;
            }
        }

        if (stream == NULL) {
            return NGX_ERROR;
        }

        /*
         * A provisioned source already exists here - the graph reaches every
         * worker - with the key, type and priority the operator configured.
         * A routed publisher attaches to it exactly as a publisher that
         * landed on this worker would: nothing is recreated, so nothing the
         * operator set is lost and the same key works after a reconnect.
         * Only a source the graph has not delivered yet is created here.
         */
        source = ngx_media_stream_source_find(stream, &source_id);
        created = 0;

        if (source == NULL) {
            source = ngx_media_stream_source_add(stream, &source_id,
                                                 header->source_type,
                                                 header->priority,
                                                 ngx_cycle->log);

            if (source == NULL) {
                return NGX_ERROR;
            }

            created = 1;
        }

        /*
         * What a publisher that landed on this worker would do: the stream
         * takes the deployment's selection policy, and the source's health is
         * bound to that selector, so a source that goes quiet is failed over
         * from after the configured timeouts.
         */
        {
            ngx_media_policy_t  *policy;

            policy = ngx_media_policy_get((ngx_cycle_t *) ngx_cycle);

            if (policy != NULL) {
                ngx_media_stream_set_policy(stream, policy);
            }
        }

        ngx_media_health_init(&source->health, &stream->selector,
                              ngx_current_msec);
        ngx_media_health_transport(&source->health, 1, ngx_current_msec);

        if (stream->active == NULL) {
            (void) ngx_media_stream_promote(stream, source);
        }

        /*
         * One slot per publisher connection, and one connection per source:
         * a later connection for the same source supersedes the earlier one
         * (its remaining frames and CLOSE no longer match any slot), while
         * connections for other sources of the same program are untouched.
         * A slot inherits whether the source was created by a routed OPEN
         * from the connection it supersedes, so only a source that no
         * operator provisioned is deleted when the last connection closes.
         */
        {
            ngx_uint_t  i;

            for (i = 0; i < NGX_MEDIA_RUNTIME_MAX_ROUTED; i++) {

                if (ngx_media_runtime_routed[i].used
                    && ngx_media_runtime_routed[i].source == source)
                {
                    created |= ngx_media_runtime_routed[i].created;
                    ngx_media_ipc_frame_reset(&ngx_media_runtime_routed[i].frame);
                    ngx_memzero(&ngx_media_runtime_routed[i],
                                sizeof(ngx_media_runtime_routed_t));
                }
            }
        }

        /* remember the routed source so its frames have a destination */
        {
            ngx_uint_t  i;

            for (i = 0; i < NGX_MEDIA_RUNTIME_MAX_ROUTED; i++) {

                if (!ngx_media_runtime_routed[i].used) {
                    ngx_media_runtime_routed[i].used = 1;
                    ngx_media_runtime_routed[i].peer = peer;
                    ngx_media_runtime_routed[i].created = created;
                    ngx_media_runtime_routed[i].hash = hash;
                    ngx_media_runtime_routed[i].incarnation =
                        header->incarnation;
                    ngx_media_runtime_routed[i].session = header->session;
                    ngx_media_runtime_routed[i].stream = stream;
                    ngx_media_runtime_routed[i].source = source;
                    break;
                }
            }

            if (i == NGX_MEDIA_RUNTIME_MAX_ROUTED) {
                ngx_media_runtime_stats.routed_slot_overflows++;

                if (created) {
                    ngx_media_stream_source_remove(stream, source);

                } else {
                    ngx_media_health_transport(&source->health, 0,
                                               ngx_current_msec);
                }

                return NGX_OK;
            }
        }

        /* the owner claims the stream in the shared directory */
        if (ngx_media_runtime_owners != NULL) {
            (void) ngx_media_owner_dir_claim(ngx_media_runtime_owners, hash,
                                             (ngx_uint_t) ngx_worker);
        }

        /*
         * A source this OPEN had to create is published to the other workers
         * as desired state, so a control request that landed elsewhere sees
         * the stream a publisher is feeding.  A provisioned source is already
         * in every replica and is left exactly as the operator wrote it.
         */
        if (created) {
            (void) ngx_media_graph_stream_set(stream);
            (void) ngx_media_graph_source_set(stream, source, NULL, NULL);
        }

        ngx_log_error(NGX_LOG_NOTICE, ngx_cycle->log, 0,
                      "media: routed source opened stream=%V/%V source=%V",
                      &application, &name, &source_id);

        return NGX_OK;
    }

    if (header->type == NGX_MEDIA_IPC_MSG_TRACKS) {
        ngx_media_trackset_t  set;
        const u_char         *q;
        uint32_t              count, i2;
        size_t                left;

        if (payload == NULL) {
            return NGX_ERROR;
        }

        q = ngx_media_buf_data(payload);
        left = ngx_media_buf_size(payload);

        if (left < sizeof(uint32_t)) {
            return NGX_ERROR;
        }

        ngx_memcpy(&count, q, sizeof(uint32_t));
        q += sizeof(uint32_t);
        left -= sizeof(uint32_t);

        if (count == 0 || count > 8
            || ngx_media_trackset_init(&set, count, ngx_cycle->log) != NGX_OK)
        {
            return NGX_ERROR;
        }

        for (i2 = 0; i2 < count; i2++) {
            uint32_t           fields[10];
            ngx_media_track_t  track;
            size_t             config_len;

            if (left < sizeof(fields)) {
                ngx_media_trackset_destroy(&set);
                return NGX_ERROR;
            }

            ngx_memcpy(fields, q, sizeof(fields));
            q += sizeof(fields);
            left -= sizeof(fields);
            config_len = (size_t) fields[9];

            if (config_len > left
                || config_len > NGX_MEDIA_RUNTIME_MAX_TRACK_CONFIG)
            {
                ngx_media_trackset_destroy(&set);
                return NGX_ERROR;
            }

            ngx_memzero(&track, sizeof(track));

            track.media_type = fields[0];
            track.codec = fields[1];
            track.payload_format = fields[2];
            track.sample_rate = fields[3];
            track.channels = fields[4];
            track.profile = fields[5];
            track.level = fields[6];
            track.width = fields[7];
            track.height = fields[8];

            if (config_len > 0) {
                ngx_media_buf_t  *config = ngx_media_buf_alloc(config_len);
                if (config == NULL) {
                    ngx_media_trackset_destroy(&set);
                    return NGX_ERROR;
                }

                ngx_memcpy(ngx_media_buf_data(config), q, config_len);
                (void) ngx_media_buf_freeze(config, config_len);

                track.config = config;
                (void) ngx_media_trackset_add(&set, &track);
                ngx_media_buf_unref(config);

            } else {
                (void) ngx_media_trackset_add(&set, &track);
            }

            q += config_len;
            left -= config_len;
        }

        for (i2 = 0; i2 < NGX_MEDIA_RUNTIME_MAX_ROUTED; i2++) {

            if (ngx_media_runtime_routed[i2].used
                && ngx_media_runtime_routed[i2].hash == hash
                && ngx_media_runtime_routed[i2].incarnation
                   == header->incarnation
                && ngx_media_runtime_routed[i2].session == header->session
                && ngx_media_runtime_routed[i2].source->stream
                   == ngx_media_runtime_routed[i2].stream)
            {
                (void) ngx_media_source_tracks_set(
                    ngx_media_runtime_routed[i2].source, &set, ngx_cycle->log);

                for (count = 0; count < set.count; count++) {

                    if (set.tracks[count].media_type == NGX_MEDIA_TYPE_VIDEO) {
                        ngx_media_runtime_routed[i2].source->has_video = 1;
                    }
                }

                break;
            }
        }

        if (i2 == NGX_MEDIA_RUNTIME_MAX_ROUTED) {
            for (i2 = 0; i2 < NGX_MEDIA_RUNTIME_MAX_ROUTED; i2++) {
                if (ngx_media_runtime_routed[i2].used
                    && ngx_media_runtime_routed[i2].hash == hash)
                {
                    ngx_media_runtime_stats.routed_identity_mismatches++;
                    break;
                }
            }
        }

        ngx_media_trackset_destroy(&set);

        return NGX_OK;
    }

    if (header->type == NGX_MEDIA_IPC_MSG_CLOSE) {
        ngx_uint_t  i;

        /* the connection's source is released with it */
        for (i = 0; i < NGX_MEDIA_RUNTIME_MAX_ROUTED; i++) {

            if (ngx_media_runtime_routed[i].used
                && ngx_media_runtime_routed[i].hash == hash
                && ngx_media_runtime_routed[i].incarnation
                   == header->incarnation
                && ngx_media_runtime_routed[i].session == header->session)
            {
                ngx_media_runtime_routed_close(&ngx_media_runtime_routed[i]);
                break;
            }
        }

        if (i == NGX_MEDIA_RUNTIME_MAX_ROUTED) {
            for (i = 0; i < NGX_MEDIA_RUNTIME_MAX_ROUTED; i++) {
                if (ngx_media_runtime_routed[i].used
                    && ngx_media_runtime_routed[i].hash == hash)
                {
                    ngx_media_runtime_stats.routed_identity_mismatches++;
                    break;
                }
            }
        }

        ngx_log_error(NGX_LOG_NOTICE, ngx_cycle->log, 0,
                      "media: routed source closed hash=%uL frames=%uL msgs=%uL "
                      "nopayload=%uL", header->hash,
                      ngx_media_runtime_routed_frames,
                      ngx_media_runtime_routed_msgs,
                      ngx_media_runtime_routed_nopayload);

        return NGX_OK;
    }

    /*
     * A media frame.  It goes to the *source* the OPEN message registered, not
     * to whatever is currently active: the source is still standby until its
     * first keyframe passes the gate, and the gate can only see frames that
     * were published to it.
     */
    {
        ngx_media_ipc_message_t  message;
        ngx_media_buf_t         *assembled;
        ngx_media_frame_t        frame;
        ngx_uint_t               i;
        ngx_int_t                status;
        uint64_t                 restarts;
        for (i = 0; i < NGX_MEDIA_RUNTIME_MAX_ROUTED; i++) {

            if (ngx_media_runtime_routed[i].used
                && ngx_media_runtime_routed[i].hash == hash
                && ngx_media_runtime_routed[i].incarnation
                   == header->incarnation
                && ngx_media_runtime_routed[i].session == header->session)
            {
                break;
            }
        }

        ngx_media_runtime_routed_msgs++;

        if (i == NGX_MEDIA_RUNTIME_MAX_ROUTED) {
            ngx_uint_t  j;

            for (j = 0; j < NGX_MEDIA_RUNTIME_MAX_ROUTED; j++) {
                if (ngx_media_runtime_routed[j].used
                    && ngx_media_runtime_routed[j].hash == hash)
                {
                    ngx_media_runtime_stats.routed_identity_mismatches++;
                    return NGX_OK;
                }
            }

            ngx_media_runtime_stats.routed_no_slot++;
            return NGX_OK;
        }

        if (ngx_media_runtime_routed[i].source->stream
            != ngx_media_runtime_routed[i].stream)
        {
            /* the control plane deleted the source this connection feeds */
            ngx_media_ipc_frame_reset(&ngx_media_runtime_routed[i].frame);
            ngx_memzero(&ngx_media_runtime_routed[i],
                        sizeof(ngx_media_runtime_routed_t));
            return NGX_OK;
        }

        if (payload == NULL) {
            ngx_media_runtime_routed_nopayload++;
            ngx_media_runtime_stats.routed_no_payload++;
            return NGX_OK;
        }


        /*
         * A frame larger than one datagram arrives as a run of chunks, each
         * carrying its own offset and the MORE flag.  Publishing a chunk would
         * put a truncated access unit into the program, so the run is
         * reassembled per endpoint first and only a complete frame is handed
         * on (the 4 MB ceiling is enforced by the reassembler).
         */
        message.header = *header;
        message.payload = payload;
        message.offset = 0;
        message.length = ngx_media_buf_size(payload);

        restarts = ngx_media_runtime_routed[i].frame.restarts;

        status = ngx_media_ipc_frame_feed(&ngx_media_runtime_routed[i].frame,
                                          &message);

        if (ngx_media_runtime_routed[i].frame.restarts != restarts) {
            ngx_media_runtime_stats.routed_frame_restarts++;
        }

        if (status == NGX_AGAIN || status == NGX_OK) {
            /*
             * The sender numbers every frame, sent or not.  Judged at the
             * frame's first chunk, a number the owner skipped is a frame it
             * never received.
             */
            if (header->offset == 0) {
                if (ngx_media_runtime_routed[i].sequenced
                    && header->sequence
                       > ngx_media_runtime_routed[i].next_sequence)
                {
                    ngx_media_runtime_stats.routed_sequence_gaps +=
                        header->sequence
                        - ngx_media_runtime_routed[i].next_sequence;
                }

                ngx_media_runtime_routed[i].sequenced = 1;
                ngx_media_runtime_routed[i].next_sequence =
                    header->sequence + 1;
            }
        }

        if (status == NGX_AGAIN) {
            return NGX_OK;   /* more chunks follow for this frame */
        }

        if (status != NGX_OK) {
            ngx_media_runtime_stats.routed_reassembly_errors++;
            return NGX_ERROR;   /* inconsistent run: the frame was dropped */
        }

        assembled = ngx_media_runtime_routed[i].frame.payload;

        ngx_media_frame_init(&frame);

        frame.media_type = header->media_type;
        frame.codec = header->codec;
        frame.payload_format = header->payload_format;
        frame.track_index = header->track_index;
        frame.pts = header->pts;
        frame.dts = header->dts;
        frame.keyframe = header->keyframe ? 1 : 0;
        frame.config = header->config ? 1 : 0;

        /*
         * adopt() takes over the reference it is given, and the reassembly
         * still owns its own: take a reference for the frame so resetting the
         * reassembly cannot free a buffer the program is still reading.
         */
        ngx_media_frame_adopt(&frame, ngx_media_buf_ref(assembled));

        ngx_media_ipc_frame_reset(&ngx_media_runtime_routed[i].frame);

        source = ngx_media_runtime_routed[i].source;
        stream = ngx_media_runtime_routed[i].stream;

        ngx_media_health_media(&source->health, frame.dts, ngx_current_msec);

        if (ngx_media_stream_publish(stream, source, &frame,
                                     ngx_current_msec) != NGX_OK)
        {
            ngx_media_runtime_stats.routed_publish_errors++;
        }

        ngx_media_frame_release(&frame);

        if ((++ngx_media_runtime_routed_frames % 200) == 0) {
            ngx_log_error(NGX_LOG_NOTICE, ngx_cycle->log, 0,
                          "media: %uL routed frames, program=%uL active=%V",
                          ngx_media_runtime_routed_frames, stream->program_frames,
                          stream->active != NULL ? &stream->active->id
                                                 : &ngx_media_runtime_none);
        }
    }

    return NGX_OK;
}

/* --- player preparation -------------------------------------------------- */

ngx_media_rtmp_prepare_t *
ngx_media_runtime_prepare(ngx_media_stream_t *stream, ngx_log_t *log)
{
    ngx_media_runtime_prepare_t  *slot;

    if (stream == NULL) {
        return NULL;
    }

    for (slot = ngx_media_runtime_prepares; slot != NULL; slot = slot->next) {
        if (slot->used && slot->stream == stream) {
            return &slot->prepare;
        }
    }

    slot = ngx_alloc(sizeof(ngx_media_runtime_prepare_t), log);
    if (slot == NULL) {
        return NULL;
    }
    ngx_memzero(slot, sizeof(ngx_media_runtime_prepare_t));

    slot->used = 1;
    slot->stream = stream;

    ngx_media_feed_cursor_init(&stream->program_feed, &slot->cursor);
    ngx_media_rtmp_prepare_init(&slot->prepare, 2048, 32 * 1024 * 1024);

    slot->next = ngx_media_runtime_prepares;
    ngx_media_runtime_prepares = slot;

    return &slot->prepare;
}

static void
ngx_media_runtime_prepare_drain(ngx_media_stream_t *stream, ngx_log_t *log,
    ngx_media_runtime_budget_t *budget)
{
    ngx_media_runtime_prepare_t  *slot;
    ngx_media_frame_t             frames[NGX_MEDIA_RUNTIME_MAX_FRAMES_TICK];
    ngx_uint_t                    count, i, status, max_units, prepared;
    size_t                        max_bytes;

    for (slot = ngx_media_runtime_prepares; slot != NULL; slot = slot->next) {
        if (slot->used && slot->stream == stream) {
            goto found;
        }
    }

    return;

found:
    prepared = 0;

    for ( ;; ) {
        if (!ngx_media_runtime_budget_ready(budget)) {
            break;
        }

        max_units = NGX_MEDIA_RUNTIME_MAX_FRAMES_TICK;
        max_bytes = 1024 * 1024;

        if (budget != NULL) {
            if (max_units > NGX_MEDIA_RUNTIME_VISIT_MAX_FRAMES
                              - budget->frames)
            {
                max_units = NGX_MEDIA_RUNTIME_VISIT_MAX_FRAMES
                            - budget->frames;
            }

            if (max_bytes > NGX_MEDIA_RUNTIME_VISIT_MAX_BYTES
                              - budget->bytes)
            {
                max_bytes = NGX_MEDIA_RUNTIME_VISIT_MAX_BYTES
                            - budget->bytes;
            }
        }

        if (max_units == 0 || max_bytes == 0) {
            if (budget != NULL) {
                budget->exhausted = 1;
            }
            break;
        }

        status = ngx_media_feed_read(&stream->program_feed, &slot->cursor,
                                     max_units, max_bytes, ngx_current_msec,
                                     frames, &count);

        if (status == NGX_MEDIA_FEED_GENERATION_MISMATCH
            || status == NGX_MEDIA_FEED_OVERRUN)
        {
            (void) ngx_media_feed_resync(&stream->program_feed, &slot->cursor,
                                         NGX_MEDIA_FEED_RESYNC_KEYFRAME);
            slot->tracks = NULL;   /* new generation: new sequence headers */
            continue;
        }

        if (status != NGX_MEDIA_FEED_BATCH) {
            break;
        }
        ngx_media_runtime_budget_account(budget, frames, count);

        if (stream->active != NULL && stream->active->tracks != NULL
            && slot->tracks != stream->active->tracks)
        {
            if (ngx_media_rtmp_prepare_announce(&slot->prepare,
                                                stream->active->tracks) != NGX_OK)
            {
                ngx_log_error(NGX_LOG_WARN, log, 0,
                              "media: rtmp: could not announce %V/%V",
                              &stream->application, &stream->name);
            }

            slot->tracks = stream->active->tracks;
            prepared = 1;
        }

        /* bounded per visit (goal doc 34 item 13) */
        for (i = 0; i < count && i < NGX_MEDIA_RUNTIME_MAX_FRAMES_TICK; i++) {

            if (frames[i].config) {
                continue;
            }

            if (ngx_media_rtmp_prepare_frame(&slot->prepare, &frames[i])
                != NGX_OK)
            {
                break;
            }
            prepared = 1;
        }

        ngx_media_feed_release(frames, count);
}
    if (prepared) {
        ngx_media_rtmp_destination_media_ready(stream);
    }
}

/* --- timer --------------------------------------------------------------- */


void
ngx_media_runtime_claim(const ngx_str_t *application, const ngx_str_t *name)
{
    uint64_t  hash;

    if (ngx_media_runtime_owners == NULL || application == NULL
        || name == NULL)
    {
        return;
    }

    hash = ngx_media_owner_hash(application, name);

    (void) ngx_media_owner_dir_claim(ngx_media_runtime_owners, hash,
                                     (ngx_uint_t) ngx_worker);
}

void
ngx_media_runtime_release(const ngx_str_t *application, const ngx_str_t *name)
{
    uint64_t  hash;

    if (ngx_media_runtime_owners == NULL || application == NULL
        || name == NULL)
    {
        return;
    }

    hash = ngx_media_owner_hash(application, name);

    ngx_media_owner_dir_release(ngx_media_runtime_owners, hash,
                                (ngx_uint_t) ngx_worker);
}

void
ngx_media_runtime_progress(const ngx_str_t *application, const ngx_str_t *name,
    uint64_t local_generation, uint64_t local_frames,
    ngx_media_runtime_progress_t *out)
{
    ngx_media_owner_record_t  record;
    uint64_t                  hash;
    ngx_uint_t                owner;

    if (out == NULL) {
        return;
    }

    out->owner = (ngx_uint_t) ngx_worker;
    out->local = 1;
    out->generation = local_generation;
    out->frames = local_frames;

    if (ngx_media_runtime_owners == NULL || application == NULL
        || name == NULL)
    {
        return;
    }

    /*
     * The owner is derived from the full 64-bit identity.  A uint32_t copy of
     * it named a different worker as soon as hash % workers and
     * (hash & 0xffffffff) % workers differ - the API's `owner` field then
     * disagreed with the worker that drove the stream, and the owner directory
     * lookup missed a record that was published under the full hash.
     */
    hash = ngx_media_owner_hash(application, name);
    owner = ngx_media_route_owner((ngx_cycle_t *) ngx_cycle, hash);

    out->owner = owner;

    if (owner == (ngx_uint_t) ngx_worker) {
        /* this worker drives the program: its own numbers are the answer */
        return;
    }

    /*
     * A replica does not invent progress.  It reports what the owner
     * published, and when the owner is not reporting - never claimed, dead, or
     * past its heartbeat - it says so by reporting nothing rather than the
     * zeros of a program that is running somewhere else.
     */
    out->local = 0;
    out->generation = 0;
    out->frames = 0;

    if (ngx_media_owner_dir_observe(ngx_media_runtime_owners, hash, &record)
        == NGX_OK)
    {
        out->generation = record.generation;
        out->frames = record.frames;
    }
}

static ngx_msec_t                 ngx_media_runtime_last_tick;

void
ngx_media_runtime_stats_get(ngx_media_runtime_stats_t *out)
{
    if (out != NULL) {
        *out = ngx_media_runtime_stats;
    }
}

void
ngx_media_runtime_wakeup(void)
{
    if (!ngx_media_runtime_armed
        || ngx_media_runtime_in_tick
        || ngx_terminate || ngx_quit
        || (ngx_exiting && !ngx_media_runtime_drain_active()))
    {
        return;
    }

    if (ngx_media_runtime_wakeup_event.posted) {
        ngx_media_runtime_stats.wakeup_coalesced++;
        return;
    }

    ngx_post_event(&ngx_media_runtime_wakeup_event, &ngx_posted_events);
    ngx_media_runtime_stats.wakeups++;
}

static ngx_uint_t
ngx_media_runtime_visit(ngx_log_t *log)
{
    ngx_media_registry_t        *registry;
    ngx_media_registry_entry_t  *entry;
    ngx_media_selector_result_t  res;
    ngx_media_stream_t          *stream;
    ngx_media_policy_t          *policy;
    ngx_msec_t                   now;
    ngx_media_runtime_budget_t   budget;
    ngx_queue_t                 *q;
    uint64_t                     before = 0;

    if (ngx_media_runtime_in_tick) {
        return 0;
    }

    ngx_media_runtime_in_tick = 1;

    now = ngx_current_msec;
    ngx_memzero(&budget, sizeof(budget));
    budget.started = ngx_media_runtime_clock_msec();
    policy = ngx_media_runtime_policy();

    /*
     * Only timer visits measure event-loop cadence.  Posted media wakeups are
     * intentionally much more frequent and must not make a healthy timer look
     * late or turn the cadence metric into a media-rate metric.
     */
    if (ngx_media_runtime_timer_visit) {
        if (ngx_media_runtime_last_tick != 0) {
            ngx_msec_t  gap = now - ngx_media_runtime_last_tick;

            ngx_media_runtime_stats.last_gap = gap;

            if (gap > ngx_media_runtime_stats.max_gap) {
                ngx_media_runtime_stats.max_gap = gap;
            }

            if (gap > NGX_MEDIA_RUNTIME_INTERVAL
                       + NGX_MEDIA_RUNTIME_INTERVAL / 2)
            {
                ngx_media_runtime_stats.late_ticks++;
            }
        }

        ngx_media_runtime_last_tick = now;
    }

    ngx_media_runtime_stats.ticks++;
    if (ngx_media_runtime_timer_visit) {
        ngx_media_runtime_stats.periodic_visits++;
    } else {
        ngx_media_runtime_stats.media_only_visits++;
    }

    if (ngx_media_runtime_timer_visit) {
        ngx_media_graph_repair_tick(log);
        ngx_media_runtime_stats.reconnecting = 0;
    }

    registry = ngx_media_registry_get((ngx_cycle_t *) ngx_cycle);

    if (registry == NULL) {
        ngx_media_runtime_in_tick = 0;
        return 0;
    }

    if (ngx_media_runtime_timer_visit) {
        /*
         * File sources (goal doc 21) are paced by the periodic visit: one
         * bounded chunk each, so a large file cannot stall a worker and the
         * frames enter the program through the normal source gate.  This walks
         * every file source, so it must not run in a posted media visit.
         */
        ngx_media_file_advance_all(log);

        /*
         * HLS readers perform transport and demux work in their own threads
         * and signal their owning worker through a source eventfd.  The
         * periodic drain-all pass remains a bounded safety net for a source
         * event that races teardown.
         */
        ngx_media_hls_pull_drain_all();
        ngx_media_hls_ingest_drain_all();
        ngx_media_hls_pull_reap(log);
        ngx_media_hls_ingest_reap(log);

        /*
         * A deleted stream's pool is held until the last reader that
         * references it has been closed.  Reaping above makes the memory
         * freeable without making the delete wait on an origin.
         */
        ngx_media_registry_drain(registry, log);
    }

    for (q = ngx_queue_head(&registry->entries);
         q != (ngx_queue_t *) &registry->entries;
         q = q->next)
    {
        if (!ngx_media_runtime_budget_ready(&budget)) {
            break;
        }

        entry = ngx_queue_data(q, ngx_media_registry_entry_t, link);
        stream = &entry->stream;

        /* only the owner drives a program's selection and outputs */
        if (!ngx_media_route_is_owner((ngx_cycle_t *) ngx_cycle,
                                      ngx_media_owner_hash(&stream->application,
                                                           &stream->name)))
        {
            continue;
        }

        if (ngx_media_runtime_timer_visit) {
            /*
             * Refresh our claim on the stream.  Ownership is recorded in a
             * shared directory with a heartbeat, and a record whose heartbeat
             * has gone stale is reclaimable by another worker.  Heartbeats
             * therefore belong to the periodic visit, not to media rate.
             */
            if (ngx_media_runtime_owners != NULL) {
                uint64_t  hash = ngx_media_owner_hash(&stream->application,
                                                      &stream->name);

                (void) ngx_media_owner_dir_heartbeat(
                    ngx_media_runtime_owners, hash, (ngx_uint_t) ngx_worker,
                    stream->generation, stream->program_frames,
                    ngx_media_stream_source_count(stream));
            }
            before = stream->switches;
            (void) ngx_media_selector_run(stream, now, &res);

            if (now - ngx_media_runtime_last_idle_log >= 1000) {
                ngx_log_debug6(NGX_LOG_DEBUG_EVENT, log, 0,
                               "media: selector tick stream=%V/%V active=%V "
                               "active_healthy=%ui best=%ui emergency=%ui",
                               &stream->application, &stream->name,
                               stream->active != NULL ? &stream->active->id
                                                      : &ngx_media_runtime_none,
                               res.active_eligible, res.best != NULL,
                               res.emergency != NULL);
            }
        }
        {
            ngx_media_runtime_outputs_t  *out = NULL;

            /*
             * Prepared when the policy has a file consumer (HLS, recording,
             * a transform), or when a destination asked for the preparation
             * on demand - an SRT destination on a program with neither.
             */
            if (policy != NULL
                && (policy->hls_path.len > 0
                    || policy->record_program_path.len > 0
                    || policy->record_iso_path.len > 0
                    || policy->transform_executor.executable.len > 0))
            {
                out = ngx_media_runtime_outputs_get(stream, log);

            } else {
                out = ngx_media_runtime_outputs_find(stream);
            }

            if (out != NULL) {
                ngx_media_runtime_hls_limits(out, now);
                ngx_media_runtime_outputs_drain(out, log, &budget);
            }
        }

        if (stream->active != NULL && stream->active->tracks != NULL) {
            ngx_media_runtime_prepare_drain(stream, log, &budget);
        }

        if (budget.exhausted) {
            break;
        }

        if (ngx_media_runtime_timer_visit) {
            /*
             * A source whose transport is up but which is not carrying media
             * yet is reconnecting (goal doc 28).  Selector and liveness
             * accounting stay at the periodic cadence.
             */
            {
                ngx_queue_t       *sq;
                ngx_media_source_t *source;

                for (sq = ngx_queue_head(&stream->sources);
                     sq != (ngx_queue_t *) &stream->sources;
                     sq = sq->next)
                {
                    source = ngx_queue_data(sq, ngx_media_source_t, queue);

                    if (source->state == NGX_MEDIA_SOURCE_AWAITING_SYNC) {
                        ngx_media_runtime_stats.reconnecting++;
                    }
                }
            }

            if (stream->switches != before) {
                ngx_log_error(NGX_LOG_NOTICE, log, 0,
                              "media: selector switched stream=%V/%V "
                              "active=%V generation=%ui switches=%uL",
                              &stream->application, &stream->name,
                              stream->active != NULL ? &stream->active->id
                                                     : &ngx_media_runtime_none,
                              stream->generation, stream->switches);
            }
        }
    }

    {
        ngx_msec_t  service = ngx_media_runtime_clock_msec() - budget.started;

        ngx_media_runtime_stats.last_service = service;

        if (service > ngx_media_runtime_stats.max_service) {
            ngx_media_runtime_stats.max_service = service;
        }
    }

    if (now - ngx_media_runtime_last_idle_log >= 1000) {
        ngx_media_runtime_last_idle_log = now;
    }
    ngx_media_runtime_in_tick = 0;
    return budget.exhausted;
}
void
ngx_media_runtime_periodic_visit(ngx_log_t *log)
{
    ngx_uint_t  more;

    ngx_media_runtime_timer_visit = 1;
    more = ngx_media_runtime_visit(log);
    ngx_media_runtime_timer_visit = 0;
    ngx_media_egress_manager_worker_sample(
        ngx_media_runtime_stats.last_gap);
    ngx_media_hls_push_adapt();

    if (more) {
        ngx_media_runtime_stats.budget_reposts++;
        ngx_media_runtime_wakeup();
    }
}


void
ngx_media_runtime_media_visit(ngx_log_t *log)
{
    ngx_uint_t  more;

    ngx_media_runtime_timer_visit = 0;
    more = ngx_media_runtime_visit(log);

    if (more) {
        ngx_media_runtime_stats.budget_reposts++;
        ngx_media_runtime_wakeup();
    }
}



static void
ngx_media_runtime_wakeup_handler(ngx_event_t *ev)
{
    if (!ngx_media_runtime_armed
        || ngx_terminate || ngx_quit
        || (ngx_exiting && !ngx_media_runtime_drain_active()))
    {
        return;
    }

    ngx_media_runtime_media_visit(ev->log);
}

static void
ngx_media_runtime_handler(ngx_event_t *ev)
{
    if (!ngx_media_runtime_armed) {
        return;
    }

    ngx_media_runtime_periodic_visit(ev->log);

    /* A publisher and its routed old owner both retain their generation.
     * Session close, routed CLOSE or peer EOF releases that retention;
     * worker_shutdown_timeout forces socket handlers through close. */
    if (ngx_terminate || ngx_quit
        || (ngx_exiting && !ngx_media_runtime_drain_active()))
    {
        return;
    }

    ngx_add_timer(ev, NGX_MEDIA_RUNTIME_INTERVAL);
}

/*
 * The shared revision sequence, read from the owner directory.  Zero when
 * there is no directory: the caller then keeps a local number, which is what a
 * single writer wants anyway.
 */
static uint64_t
ngx_media_runtime_revision(void)
{
    return ngx_media_owner_dir_revision_next(ngx_media_runtime_owners);
}

ngx_int_t
ngx_media_runtime_init(ngx_cycle_t *cycle, ngx_log_t *log)
{
    if (ngx_media_runtime_owners != NULL) {
        return NGX_OK;
    }

    /*
     * The push backend owns a small upload pool; starting it here means a
     * destination can be added through the control API at any time.
     */
    if (ngx_media_hls_push_register(log) != NGX_OK) {
        ngx_log_error(NGX_LOG_WARN, log, 0,
                      "media: hls push pool could not be started");
    }

    ngx_media_runtime_owners = ngx_media_owner_dir_attach(cycle, log);

    if (ngx_media_runtime_owners == NULL) {
        return NGX_ERROR;
    }

    /*
     * Every desired-state mutation takes its revision from the shared
     * sequence, so a mutation on one worker and a mutation on another are
     * ordered: replicas resolve the conflict by the higher number instead of
     * each keeping whichever operation reached it last.
     */
    ngx_media_revision_provider(ngx_media_runtime_revision);

    if (ngx_media_route_worker_init(cycle, log) != NGX_OK) {
        return NGX_ERROR;
    }

    ngx_media_route_set_sink(ngx_media_runtime_route_sink, NULL);

    return NGX_OK;
}

ngx_media_owner_dir_t *
ngx_media_runtime_owner_dir(void)
{
    return ngx_media_runtime_owners;
}

ngx_uint_t
ngx_media_runtime_arm(ngx_cycle_t *cycle, ngx_log_t *log)
{
    ngx_media_policy_t  *policy;

    if (ngx_media_runtime_armed) {
        return 0;
    }

    policy = (ngx_media_policy_t *)
                 ((ngx_cycle_t *) ngx_cycle)
                     ->conf_ctx[ngx_media_core_module.index];

    if (policy == NULL) {
        policy = ngx_media_policy_get((ngx_cycle_t *) ngx_cycle);
    }

    if (policy != NULL && policy->record_raw_path.len > 0) {
        ngx_media_record_conf_t  rec_conf;

        ngx_media_record_conf_default(&rec_conf);

        rec_conf.path = policy->record_raw_path;
        rec_conf.tap = NGX_MEDIA_RECORD_RAW;

        if (ngx_media_record_init(&ngx_media_runtime_raw, &rec_conf, cycle->log)
            == NGX_OK)
        {
            ngx_media_runtime_raw_started = 1;

            ngx_log_error(NGX_LOG_NOTICE, cycle->log, 0,
                          "media: raw recording started in %V",
                          &policy->record_raw_path);
        }
    }

    ngx_memzero(&ngx_media_runtime_timer, sizeof(ngx_event_t));
    ngx_memzero(&ngx_media_runtime_wakeup_event, sizeof(ngx_event_t));

    ngx_media_runtime_timer.handler = ngx_media_runtime_handler;
    ngx_media_runtime_timer.log = log;
    ngx_media_runtime_timer.data = cycle;

    ngx_media_runtime_wakeup_event.handler = ngx_media_runtime_wakeup_handler;
    ngx_media_runtime_wakeup_event.log = log;
    ngx_media_runtime_wakeup_event.data = cycle;

    ngx_media_runtime_armed = 1;

    ngx_add_timer(&ngx_media_runtime_timer, NGX_MEDIA_RUNTIME_INTERVAL);

    return 1;
}

void
ngx_media_runtime_stop(void)
{
    if (!ngx_media_runtime_armed) {
        return;
    }

    ngx_media_runtime_armed = 0;
    ngx_media_runtime_in_tick = 0;
    ngx_media_runtime_timer_visit = 0;

    if (ngx_media_runtime_timer.timer_set) {
        ngx_del_timer(&ngx_media_runtime_timer);
    }

    if (ngx_media_runtime_wakeup_event.posted) {
        ngx_delete_posted_event(&ngx_media_runtime_wakeup_event);
    }
}

/* number of live per-stream runtime output objects */
ngx_uint_t
ngx_media_runtime_outputs_active(void)
{
    return ngx_media_runtime_outputs_count;
}

/*
 * Releases one stream's runtime objects before its feed is destroyed.  Output
 * state is flushed and freed; the shared RTMP preparation and routed slots
 * are also released here so neither readers nor queued buffers outlive stream
 * teardown.
 */
void
ngx_media_runtime_stream_release(ngx_media_stream_t *stream)
{
    ngx_media_runtime_outputs_t  **output_link, *output;
    ngx_media_runtime_prepare_t  **prepare_link, *prepare;
    ngx_uint_t                      i;

    if (stream == NULL) {
        return;
    }

    for (output_link = &ngx_media_runtime_outputs;
         *output_link != NULL; output_link = &(*output_link)->next)
    {
        if ((*output_link)->stream != stream) {
            continue;
        }

        output = *output_link;
        *output_link = output->next;
        if (ngx_media_runtime_outputs_count > 0) {
            ngx_media_runtime_outputs_count--;
        }
        ngx_media_runtime_outputs_stop(output);
        ngx_free(output);
        break;
    }

    for (prepare_link = &ngx_media_runtime_prepares;
         *prepare_link != NULL; prepare_link = &(*prepare_link)->next)
    {
        if ((*prepare_link)->stream != stream) {
            continue;
        }

        prepare = *prepare_link;
        *prepare_link = prepare->next;
        if (prepare->used) {
            ngx_media_rtmp_prepare_destroy(&prepare->prepare);
        }
        ngx_free(prepare);
        break;
    }

    /*
     * A routed slot publishes into the stream it remembers, so it cannot
     * outlive it: the next frame from that publisher would be written into a
     * feed that is going away.  The slot is dropped, and the reassembly it
     * holds is reset first because the partial frame it is carrying is its
     * own reference - dropping the slot without that leaks the buffers.
     *
     * The publisher keeps sending into a route that no longer has a slot; its
     * frames are ignored until it opens again, which is the same thing that
     * happens to any transport whose stream was deleted.
     */
    for (i = 0; i < NGX_MEDIA_RUNTIME_MAX_ROUTED; i++) {

        if (ngx_media_runtime_routed[i].used
            && ngx_media_runtime_routed[i].stream == stream)
        {
            ngx_media_ipc_frame_reset(&ngx_media_runtime_routed[i].frame);
            ngx_memzero(&ngx_media_runtime_routed[i],
                        sizeof(ngx_media_runtime_routed_t));
        }
    }
}

void
ngx_media_runtime_shutdown(ngx_log_t *log)
{
    ngx_media_runtime_outputs_t  *output;
    ngx_media_runtime_prepare_t  *prepare;

    ngx_media_hls_pull_stop_all();
    ngx_media_hls_ingest_stop_all();

    ngx_media_runtime_stop();
    ngx_media_route_worker_shutdown(log);

    while ((output = ngx_media_runtime_outputs) != NULL) {
        ngx_media_runtime_outputs = output->next;
        if (ngx_media_runtime_outputs_count > 0) {
            ngx_media_runtime_outputs_count--;
        }
        ngx_media_runtime_outputs_stop(output);
        ngx_free(output);
    }
    ngx_media_hls_push_stop();

    while ((prepare = ngx_media_runtime_prepares) != NULL) {
        ngx_media_runtime_prepares = prepare->next;
        if (prepare->used) {
            ngx_media_rtmp_prepare_destroy(&prepare->prepare);
        }
        ngx_free(prepare);
    }

    if (ngx_media_runtime_raw_started) {
        ngx_media_record_stop(&ngx_media_runtime_raw);
        ngx_media_runtime_raw_started = 0;
    }
}
